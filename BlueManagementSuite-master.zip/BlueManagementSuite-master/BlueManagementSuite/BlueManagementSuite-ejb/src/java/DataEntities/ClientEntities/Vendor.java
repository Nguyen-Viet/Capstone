/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataEntities.ClientEntities;

import java.util.ArrayList;

/**
 * A ClientADT subclass used to differentiate the other clients.
 * @version 1.1
 * @author Ese Brooks & Graham Ermter
 */
final public class Vendor extends ClientADT{
    
    /**
     *
     * @param id
     * @param name
     * @param type
     * @param email
     */
    public Vendor(int id, String name, String type, String email) {
        super(id, name, type, email);
    }
    
    /**
     *
     * @param name
     * @param type
     * @param id
     * @param email
     */
    public Vendor(String name, String type, int id, String email) {
        super(name, type, email);
    }
    
    /**
     *
     */
    public Vendor(){
        
    }
}
