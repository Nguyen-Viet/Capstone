/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataEntities.ClientEntities;

import java.sql.Date;
import java.util.ArrayList;

/**
 * An abstract class of what a Client object should look like.
 * @version 1.1
 * @author Ese Brooks & Graham Ermter
 */
public abstract class ClientADT {
    
    //Attributes
    private int id;
    private String name;
    private String type;
    private String email;
    private Date dateCreated;
    private ArrayList contactList = new ArrayList();
    
    /**
     *
     * @param id
     * @param name
     * @param type
     * @param email
     */
    public ClientADT(int id, String name, String type, String email){
        
        this.id = id;
        this.name = name;
        this.type = type;
        this.email = email;
        this.dateCreated = new Date(System.currentTimeMillis());
    }
    
    /**
     *
     * @param name
     * @param type
     * @param email
     */
    public ClientADT(String name, String type, String email){
        
        this.name = name;
        this.type = type;
        this.email = email;
        this.dateCreated = new Date(System.currentTimeMillis());
    }
    
    /**
     *
     */
    public ClientADT(){
        this.dateCreated = new Date(System.currentTimeMillis());
    }
    
    /**
     * Returns the id of a Client
     * @return id;
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the id of a Client
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Returns the date the Client was created
     * @return dateCreated
     */
    public Date getDateCreated() {
        return dateCreated;
    }

    /**
     * Sets the date the Client was created
     * @param dateCreated
     */
    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }
    
    /**
     * Returns the name of the Client
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of a Client
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }
    
    /**
     * Returns the type of the Client
     * @return type
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the type of a Client
     * @param type
     */
    public void setType(String type) {
        this.type = type;
    }
    
    /**
     * Gets the email of the client
     * @return email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the email of the client
     * @param email 
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     *
     * @return
     */
    public ArrayList getContactList() {
        return contactList;
    }

    /**
     *
     * @param contactList
     */
    public void setContactList(ArrayList contactList) {
        this.contactList = contactList;
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "ClientADT{" + "id=" + id + ", name=" + name + ", type=" + type + ", email=" + email + ", dateCreated=" + dateCreated + ", contactList=" + contactList + '}';
    }
    /**
     * Generates a String for testing client data
     * @return 
     */

    
    
}
