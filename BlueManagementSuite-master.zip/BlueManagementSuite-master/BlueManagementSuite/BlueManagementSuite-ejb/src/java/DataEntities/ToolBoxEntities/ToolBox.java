/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataEntities.ToolBoxEntities;

/**
 *
 * @author Graham Ermter
 */
public final class ToolBox extends ToolBoxADT {
    
}
