/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataEntities.ToolBoxEntities;

import DataEntities.ToolEntities.ToolADT;
import java.util.ArrayList;

/**
 *
 * @author Graham Ermter
 */
public abstract class ToolBoxADT {
    
    /**
     *
     */
    protected int id;

    /**
     *
     */
    protected String name;

    /**
     *
     */
    protected String description;

    /**
     *
     */
    protected String category;

    /**
     *
     */
    protected ArrayList<ToolADT> toolList = new ArrayList<>();

    /**
     *
     * @return
     */
    public int getId() {
        return id;
    }

    /**
     *
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     *
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     *
     * @return
     */
    public String getDescription() {
        return description;
    }

    /**
     *
     * @param description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     *
     * @return
     */
    public String getCategory() {
        return category;
    }

    /**
     *
     * @param category
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     *
     * @return
     */
    public ArrayList<ToolADT> getToolList() {
        return toolList;
    }

    /**
     *
     * @param toolList
     */
    public void setToolList(ArrayList<ToolADT> toolList) {
        this.toolList = toolList;
    }
}
