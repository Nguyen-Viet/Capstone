/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataEntities.ProjectEntities;

import DataEntities.AssemblyEntities.Assembly;
import DataEntities.AssemblyEntities.AssemblyADT;
import DataEntities.ClientEntities.ClientADT;
import DataEntities.EmployeeEntities.EmployeeADT;
import DataEntities.ToolBoxEntities.ToolBoxADT;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author Graham Ermter
 */
public final class Project {
    
    //Project Attributes
    private int id;
    private String project_type;
    private int state;
    private String project_name;
    private LocalDate date_created;
    private LocalDate start_date;
    private LocalDate expected_completion;
    private String description;
    private boolean drawing;
    private boolean permit;  
    
    //Cost Attributes
    private double client_budget;
    private double project_budget;
    private double current_cost;
    private double estimated_cost;
    private double final_cost;
    
    //Detail Attributes
    double ceiling_height;
    double site_voltage;
    boolean bond_wiring;
    boolean trenching;
    boolean hazardous_areas;
    boolean insulated_ceiling;
    boolean crawl_space;
    
    //Site Attributes
    String site_name;
    String address;
    String parking;
    String code;
    boolean garbage;
    boolean first_aid;
    boolean bathroom;
    
    //Lists
    ArrayList<ClientADT> clientList;
    ArrayList<EmployeeADT> employeeList;
    ArrayList<ToolBoxADT> toolBoxList;
    ArrayList<AssemblyADT> assemblyList;
    
    /**
     *
     */
    public Project(){
        
        clientList = new ArrayList<>();
        employeeList = new ArrayList<>();
        toolBoxList = new ArrayList<>();
        assemblyList = new ArrayList<>();
    }

    /**
     *
     * @return
     */
    public int getId() {
        return id;
    }

    /**
     *
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     *
     * @return
     */
    public String getProject_type() {
        return project_type;
    }

    /**
     *
     * @param project_type
     */
    public void setProject_type(String project_type) {
        this.project_type = project_type;
    }

    /**
     *
     * @return
     */
    public int getState() {
        return state;
    }

    /**
     *
     * @param state
     */
    public void setState(int state) {
        this.state = state;
    }

    /**
     *
     * @return
     */
    public String getProject_name() {
        return project_name;
    }

    /**
     *
     * @param project_name
     */
    public void setProject_name(String project_name) {
        this.project_name = project_name;
    }

    /**
     *
     * @return
     */
    public LocalDate getDate_created() {
        return date_created;
    }

    /**
     *
     * @param date_created
     */
    public void setDate_created(LocalDate date_created) {
        this.date_created = date_created;
    }

    /**
     *
     * @return
     */
    public LocalDate getStart_date() {
        return start_date;
    }

    /**
     *
     * @param start_date
     */
    public void setStart_date(LocalDate start_date) {
        this.start_date = start_date;
    }

    /**
     *
     * @return
     */
    public LocalDate getExpected_completion() {
        return expected_completion;
    }

    /**
     *
     * @param expected_completion
     */
    public void setExpected_completion(LocalDate expected_completion) {
        this.expected_completion = expected_completion;
    }

    /**
     *
     * @return
     */
    public String getDescription() {
        return description;
    }

    /**
     *
     * @param description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     *
     * @return
     */
    public boolean isDrawing() {
        return drawing;
    }

    /**
     *
     * @param drawing
     */
    public void setDrawing(boolean drawing) {
        this.drawing = drawing;
    }

    /**
     *
     * @return
     */
    public boolean isPermit() {
        return permit;
    }

    /**
     *
     * @param permit
     */
    public void setPermit(boolean permit) {
        this.permit = permit;
    }

    /**
     *
     * @return
     */
    public double getClient_budget() {
        return client_budget;
    }

    /**
     *
     * @param client_budget
     */
    public void setClient_budget(double client_budget) {
        this.client_budget = client_budget;
    }

    /**
     *
     * @return
     */
    public double getProject_budget() {
        return project_budget;
    }

    /**
     *
     * @param project_budget
     */
    public void setProject_budget(double project_budget) {
        this.project_budget = project_budget;
    }

    /**
     *
     * @return
     */
    public double getCurrent_cost() {
        return current_cost;
    }

    /**
     *
     * @param current_cost
     */
    public void setCurrent_cost(double current_cost) {
        this.current_cost = current_cost;
    }

    /**
     *
     * @return
     */
    public double getEstimated_cost() {
        return estimated_cost;
    }

    /**
     *
     * @param estimated_cost
     */
    public void setEstimated_cost(double estimated_cost) {
        this.estimated_cost = estimated_cost;
    }

    /**
     *
     * @return
     */
    public double getFinal_cost() {
        return final_cost;
    }

    /**
     *
     * @param final_cost
     */
    public void setFinal_cost(double final_cost) {
        this.final_cost = final_cost;
    }

    /**
     *
     * @return
     */
    public double getCeiling_height() {
        return ceiling_height;
    }

    /**
     *
     * @param ceiling_height
     */
    public void setCeiling_height(double ceiling_height) {
        this.ceiling_height = ceiling_height;
    }

    /**
     *
     * @return
     */
    public double getSite_voltage() {
        return site_voltage;
    }

    /**
     *
     * @param site_voltage
     */
    public void setSite_voltage(double site_voltage) {
        this.site_voltage = site_voltage;
    }

    /**
     *
     * @return
     */
    public boolean isBond_wiring() {
        return bond_wiring;
    }

    /**
     *
     * @param bond_wiring
     */
    public void setBond_wiring(boolean bond_wiring) {
        this.bond_wiring = bond_wiring;
    }

    /**
     *
     * @return
     */
    public boolean isTrenching() {
        return trenching;
    }

    /**
     *
     * @param trenching
     */
    public void setTrenching(boolean trenching) {
        this.trenching = trenching;
    }

    /**
     *
     * @return
     */
    public boolean isHazardous_areas() {
        return hazardous_areas;
    }

    /**
     *
     * @param hazardous_areas
     */
    public void setHazardous_areas(boolean hazardous_areas) {
        this.hazardous_areas = hazardous_areas;
    }

    /**
     *
     * @return
     */
    public boolean isInsulated_ceiling() {
        return insulated_ceiling;
    }

    /**
     *
     * @param insulated_ceiling
     */
    public void setInsulated_ceiling(boolean insulated_ceiling) {
        this.insulated_ceiling = insulated_ceiling;
    }

    /**
     *
     * @return
     */
    public boolean isCrawl_space() {
        return crawl_space;
    }

    /**
     *
     * @param crawl_space
     */
    public void setCrawl_space(boolean crawl_space) {
        this.crawl_space = crawl_space;
    }

    /**
     *
     * @return
     */
    public String getSite_name() {
        return site_name;
    }

    /**
     *
     * @param site_name
     */
    public void setSite_name(String site_name) {
        this.site_name = site_name;
    }

    /**
     *
     * @return
     */
    public String getAddress() {
        return address;
    }

    /**
     *
     * @param address
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     *
     * @return
     */
    public String getParking() {
        return parking;
    }

    /**
     *
     * @param parking
     */
    public void setParking(String parking) {
        this.parking = parking;
    }

    /**
     *
     * @return
     */
    public String getCode() {
        return code;
    }

    /**
     *
     * @param code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     *
     * @return
     */
    public boolean isGarbage() {
        return garbage;
    }

    /**
     *
     * @param garbage
     */
    public void setGarbage(boolean garbage) {
        this.garbage = garbage;
    }

    /**
     *
     * @return
     */
    public boolean isFirst_aid() {
        return first_aid;
    }

    /**
     *
     * @param first_aid
     */
    public void setFirst_aid(boolean first_aid) {
        this.first_aid = first_aid;
    }

    /**
     *
     * @return
     */
    public boolean isBathroom() {
        return bathroom;
    }

    /**
     *
     * @param bathroom
     */
    public void setBathroom(boolean bathroom) {
        this.bathroom = bathroom;
    }

    /**
     *
     * @return
     */
    public ArrayList<ClientADT> getClientList() {
        return clientList;
    }

    /**
     *
     * @param clientList
     */
    public void setClientList(ArrayList<ClientADT> clientList) {
        this.clientList = clientList;
    }

    /**
     *
     * @return
     */
    public ArrayList<EmployeeADT> getEmployeeList() {
        return employeeList;
    }

    /**
     *
     * @param employeeList
     */
    public void setEmployeeList(ArrayList<EmployeeADT> employeeList) {
        this.employeeList = employeeList;
    }

    /**
     *
     * @return
     */
    public ArrayList<ToolBoxADT> getToolBoxList() {
        return toolBoxList;
    }

    /**
     *
     * @param toolBoxList
     */
    public void setToolBoxList(ArrayList<ToolBoxADT> toolBoxList) {
        this.toolBoxList = toolBoxList;
    }

    /**
     *
     * @return
     */
    public ArrayList<AssemblyADT> getAssemblyList() {
        return assemblyList;
    }

    /**
     *
     * @param assemblyList
     */
    public void setAssemblyList(ArrayList<AssemblyADT> assemblyList) {
        this.assemblyList = assemblyList;
    }
    
    /**
     *
     * @param add
     */
    public void addAssembly(AssemblyADT add){
        
        assemblyList.add(add);
    }
    
    /**
     *
     * @param add
     */
    public void addClient(ClientADT add){
        
        clientList.add(add);
    }
    
    /**
     *
     * @param add
     */
    public void addEmployee(EmployeeADT add){
        
        employeeList.add(add);
    }
    
    /**
     *
     * @param add
     */
    public void addToolbox(ToolBoxADT add){
        
        toolBoxList.add(add);
    }
    
    /**
     *
     * @param remove
     */
    public void removeAssembly(AssemblyADT remove){
        
        assemblyList.remove(remove);
    }
    
    /**
     *
     * @param remove
     */
    public void removeaddClient(ClientADT remove){
        
        clientList.remove(remove);;
    }
    
    /**
     *
     * @param remove
     */
    public void removeEmployee(EmployeeADT remove){
        
        employeeList.remove(remove);
    }
    
    /**
     *
     * @param remove
     */
    public void removeToolbox(ToolBoxADT remove){
        
        toolBoxList.remove(remove);
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "Project{" + "id=" + id + ", project_type=" + project_type + ", state=" + state + ", project_name=" + project_name + ", start_date=" + start_date + ", expected_completion=" + expected_completion + ", description=" + description + ", drawing=" + drawing + ", permit=" + permit + ", client_budget=" + client_budget + ", project_budget=" + project_budget + ", current_cost=" + current_cost + ", estimated_cost=" + estimated_cost + ", final_cost=" + final_cost + ", ceiling_height=" + ceiling_height + ", site_voltage=" + site_voltage + ", bond_wiring=" + bond_wiring + ", trenching=" + trenching + ", hazardous_areas=" + hazardous_areas + ", insulated_ceiling=" + insulated_ceiling + ", crawl_space=" + crawl_space + ", site_name=" + site_name + ", address=" + address + ", parking=" + parking + ", code=" + code + ", garbage=" + garbage + ", first_aid=" + first_aid + ", bathroom=" + bathroom + ", clientList=" + clientList + ", employeeList=" + employeeList + ", toolBoxList=" + toolBoxList + ", assemblyList=" + assemblyList + '}';
    }
    
    
}