/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataEntities.MaterialEntities;

import DataEntities.ClientEntities.ClientADT;

/**
 *
 * @author Graham Ermter
 */
public abstract class MaterialADT {
    
    int id;
    String name;
    String description;
    int quantity;
    String category;
    double price;
    ClientADT seller;
            
    /**
     *
     * @param id
     * @param name
     * @param description
     * @param quantity
     * @param category
     * @param price
     * @param seller
     */
    public MaterialADT(int id, String name, String description, int quantity, String category, double price, ClientADT seller){
        
        this.id = id;
        this.name = name;
        this. description = description;
        this.quantity = quantity;
        this.category = category;
        this.price = price;
        this.seller = seller;
    }
    
    /**
     *
     * @param id
     * @param name
     * @param description
     * @param quantity
     * @param category
     */
    public MaterialADT(int id, String name, String description, int quantity, String category){
        
        this.id = id;
        this.name = name;
        this. description = description;
        this.quantity = quantity;
        this.category = category;
    }
    
    /**
     *
     * @param name
     * @param description
     * @param quantity
     * @param category
     * @param price
     * @param seller
     */
    public MaterialADT(String name, String description, int quantity, String category, double price, ClientADT seller){
        
        this.name = name;
        this. description = description;
        this.quantity = quantity;
        this.category = category;
        this.price = price;
        this.seller = seller;
    }
    
    /**
     *
     * @param name
     * @param description
     * @param quantity
     * @param category
     */
    public MaterialADT(String name, String description, int quantity, String category){
        
        this.name = name;
        this. description = description;
        this.quantity = quantity;
        this.category = category;
    }
    
    /**
     *
     */
    public MaterialADT(){
        
    }
    
    /**
     *
     * @return
     */
    public int getId() {
        return id;
    }

    /**
     *
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     *
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     *
     * @return
     */
    public String getDescription() {
        return description;
    }

    /**
     *
     * @param description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     *
     * @return
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     *
     * @param quantity
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    /**
     *
     * @return
     */
    public String getCategory() {
        return category;
    }

    /**
     *
     * @param category
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     *
     * @return
     */
    public double getPrice() {
        return price;
    }

    /**
     *
     * @param price
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /**
     *
     * @return
     */
    public ClientADT getSeller() {
        return seller;
    }

    /**
     *
     * @param seller
     */
    public void setSeller(ClientADT seller) {
        this.seller = seller;
    }
}
