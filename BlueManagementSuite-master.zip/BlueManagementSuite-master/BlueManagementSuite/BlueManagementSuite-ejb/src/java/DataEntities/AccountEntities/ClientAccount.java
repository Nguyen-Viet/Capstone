/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataEntities.AccountEntities;

import DataEntities.ClientEntities.ClientADT;
import java.util.ArrayList;

/**
 *
 * @author Graham Ermter
 */
public class ClientAccount extends AccountADT {

    ClientADT user;

    /**
     *
     * @param id
     * @param username
     * @param password
     * @param isLocked
     * @param actionLog
     * @param notificationList
     * @param user
     */
    public ClientAccount(int id, String username, String password, boolean isLocked, ArrayList actionLog, ArrayList notificationList, ClientADT user) {

        super(id, username, password, isLocked, actionLog, notificationList);
        this.user = user;
    }

    /**
     *
     * @param username
     * @param password
     * @param isLocked
     * @param actionLog
     * @param notificationList
     * @param user
     */
    public ClientAccount(String username, String password, boolean isLocked, ArrayList actionLog, ArrayList notificationList, ClientADT user) {

        super(username, password, isLocked, actionLog, notificationList);
        this.user = user;
    }

    /**
     *
     */
    public ClientAccount() {

    }

    /**
     *
     * @return
     */
    public ClientADT getUser() {
        return user;
    }

    /**
     *
     * @param user
     */
    public void setUser(ClientADT user) {
        this.user = user;
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "ClientAccount{" + "id=" + id + ", username=" + username + ", password=" + password + ", isLocked=" + isLocked + ", actionLog=" + actionLog + ", notificationList=" + notificationList + "ClientAccount{" + "user=" + user + '}';
    }
}