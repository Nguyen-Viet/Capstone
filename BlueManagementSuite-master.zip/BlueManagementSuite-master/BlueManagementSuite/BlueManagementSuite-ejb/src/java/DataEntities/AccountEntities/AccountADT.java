/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataEntities.AccountEntities;


import java.util.ArrayList;

/**
 *
 * @author Graham Ermter
 */
public abstract class AccountADT {
    
    /**
     *
     */
    protected int id;

    /**
     *
     */
    protected String username;

    /**
     *
     */
    protected String password;

    /**
     *
     */
    protected boolean isLocked;

    /**
     *
     */
    protected ArrayList actionLog;

    /**
     *
     */
    protected ArrayList notificationList;
    
    /**
     *
     */
    public AccountADT(){
            
    }
    
    /**
     *
     * @param id
     * @param username
     * @param password
     * @param isLocked
     * @param actionLog
     * @param notificationList
     */
    public AccountADT(int id, String username, String password, boolean isLocked, ArrayList actionLog, ArrayList notificationList) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.isLocked = isLocked;
        this.actionLog = actionLog;
        this.notificationList = notificationList;
    }
    
    /**
     *
     * @param username
     * @param password
     * @param isLocked
     * @param actionLog
     * @param notificationList
     */
    public AccountADT(String username, String password, boolean isLocked , ArrayList actionLog, ArrayList notificationList) {
        this.username = username;
        this.password = password;
        this.isLocked = isLocked;
        this.actionLog = actionLog;
        this.notificationList = notificationList;
    }

    /**
     *
     * @return
     */
    public int getId() {
        return id;
    }

    /**
     *
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     *
     * @return
     */
    public String getUsername() {
        return username;
    }

    /**
     *
     * @param username
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     *
     * @return
     */
    public String getPassword() {
        return password;
    }

    /**
     *
     * @param password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     *
     * @return
     */
    public boolean isLocked() {
        return isLocked;
    }

    /**
     *
     * @param isLocked
     */
    public void setIsLocked(boolean isLocked) {
        this.isLocked = isLocked;
    }

    /**
     *
     * @return
     */
    public ArrayList getActionLog() {
        return actionLog;
    }

    /**
     *
     * @param actionLog
     */
    public void setActionLog(ArrayList actionLog) {
        this.actionLog = actionLog;
    }   

    /**
     *
     * @return
     */
    public ArrayList getNotificationList() {
        return notificationList;
    }

    /**
     *
     * @param notificationList
     */
    public void setNotificationList(ArrayList notificationList) {
        this.notificationList = notificationList;
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "AccountADT{" + "id=" + id + ", username=" + username + ", password=" + password + ", isLocked=" + isLocked + ", actionLog=" + actionLog + ", notificationList=" + notificationList + '}';
    }
    
    
}
