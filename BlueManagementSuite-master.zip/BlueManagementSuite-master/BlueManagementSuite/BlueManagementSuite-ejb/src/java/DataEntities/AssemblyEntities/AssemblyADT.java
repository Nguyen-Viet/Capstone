/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataEntities.AssemblyEntities;

import DataEntities.MaterialEntities.MaterialADT;
import java.util.ArrayList;

/**
 *
 * @author Graham Ermter
 */
public abstract class AssemblyADT {
    
    /**
     *
     */
    protected int id;

    /**
     *
     */
    protected String name;

    /**
     *
     */
    protected String description;

    /**
     *
     */
    protected String category;

    /**
     *
     */
    protected ArrayList<MaterialADT> materialList;

    /**
     *
     * @return
     */
    public int getId() {
        return id;
    }

    /**
     *
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     *
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     *
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     *
     * @return
     */
    public String getDescription() {
        return description;
    }

    /**
     *
     * @param description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     *
     * @return
     */
    public String getCategory() {
        return category;
    }

    /**
     *
     * @param category
     */
    public void setCategory(String category) {
        this.category = category;
    }

    /**
     *
     * @return
     */
    public ArrayList<MaterialADT> getmaterialList() {
        return materialList;
    }

    /**
     *
     * @param materialList
     */
    public void setMaterialList(ArrayList<MaterialADT> materialList) {
        this.materialList = materialList;
    }
}
