/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataEntities.ToolEntities;

import DataEntities.ClientEntities.ClientADT;

/**
 *
 * @author Graham Ermter
 */
public class Tool extends ToolADT{
    
    /**
     *
     * @param id
     * @param name
     * @param description
     * @param quantity
     * @param category
     * @param price
     * @param seller
     */
    public Tool(int id, String name, String description, int quantity, String category, double price, ClientADT seller) {
        
        super(id, name, description, quantity, category, price, seller);
    }
    
    /**
     *
     * @param id
     * @param name
     * @param description
     * @param quantity
     * @param category
     */
    public Tool(int id, String name, String description, int quantity, String category) {
        
        super(id, name, description, quantity, category);
    }
    
    /**
     *
     * @param name
     * @param description
     * @param quantity
     * @param category
     * @param price
     * @param seller
     */
    public Tool(String name, String description, int quantity, String category, double price, ClientADT seller) {
        
        super(name, description, quantity, category, price, seller);
    }
      
    /**
     *
     * @param name
     * @param description
     * @param quantity
     * @param category
     */
    public Tool(String name, String description, int quantity, String category) {
        
        super(name, description, quantity, category);
    }
    
    /**
     *
     */
    public Tool(){
        
    }  
}