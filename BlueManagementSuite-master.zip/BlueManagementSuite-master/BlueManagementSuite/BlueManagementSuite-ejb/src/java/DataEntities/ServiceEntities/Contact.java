package DataEntities.ServiceEntities;

/**
 *
 * @author Ese Brooks
 */
final public class Contact {

    //Attributes
    private int id;
    private String type;
    private String firstName;
    private String surName;
    private String phoneNumber;
    private String address;
    private String city;
    private String quadrant;
    private String province;
    private String country;
    private String email;
    private String company;

    /**
     *
     */
    public Contact() {

    }

    /**
     *
     * @param id
     * @param type
     * @param firstName
     * @param surName
     * @param phoneNumber
     * @param address
     * @param city
     * @param quadrant
     * @param province
     * @param country
     * @param email
     * @param company
     */
    public Contact(int id, String type, String firstName, String surName, String phoneNumber,
            String address, String city, String quadrant, String province, String country, String email, String company) {

        this.id = id;
        this.type = type;
        this.firstName = firstName;
        this.surName = surName;
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.city = city;
        this.quadrant = quadrant;
        this.province = province;
        this.country = country;
        this.email = email;
        this.company = company;
    }

    /**
     *
     * @return
     */
    public int getId() {
        return id;
    }

    /**
     *
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     *
     * @return
     */
    public String getType() {
        return type;
    }

    /**
     *
     * @param type
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     *
     * @return
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     *
     * @param firstName
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     *
     * @return
     */
    public String getSurName() {
        return surName;
    }

    /**
     *
     * @param surName
     */
    public void setSurName(String surName) {
        this.surName = surName;
    }

    /**
     *
     * @return
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     *
     * @param phoneNumber
     */
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    /**
     *
     * @return
     */
    public String getAddress() {
        return address;
    }

    /**
     *
     * @param address
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     *
     * @return
     */
    public String getCity() {
        return city;
    }

    /**
     *
     * @param city
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     *
     * @return
     */
    public String getQuadrant() {
        return quadrant;
    }

    /**
     *
     * @param quadrant
     */
    public void setQuadrant(String quadrant) {
        this.quadrant = quadrant;
    }

    /**
     *
     * @return
     */
    public String getProvince() {
        return province;
    }

    /**
     *
     * @param province
     */
    public void setProvince(String province) {
        this.province = province;
    }

    /**
     *
     * @return
     */
    public String getCountry() {
        return country;
    }

    /**
     *
     * @param country
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     *
     * @return
     */
    public String getEmail() {
        return email;
    }

    /**
     *
     * @param email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     *
     * @return
     */
    public String getCompany() {
        return company;
    }

    /**
     *
     * @param company
     */
    public void setCompany(String company) {
        this.company = company;
    }

    /**
     *
     * @return
     */
    @Override
    public String toString() {

        String s;
        String d = ",";
        
        s = id + d + type + d + firstName + d + surName + d + phoneNumber 
               + d + address + d + city + d + quadrant + d + province 
               + d + country + d + email + d + company;
        
        return s;
    }
}
