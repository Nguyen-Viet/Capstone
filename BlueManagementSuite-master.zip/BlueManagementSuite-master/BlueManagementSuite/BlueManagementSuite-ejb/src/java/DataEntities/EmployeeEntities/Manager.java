/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataEntities.EmployeeEntities;

import java.sql.Date;

/**
 *
 * @author Graham Ermter
 */
public final class Manager extends EmployeeADT {
    
    /**
     *
     * @param id
     * @param employeeType
     * @param firstName
     * @param surname
     * @param address
     * @param email
     * @param phoneNumber
     * @param city
     * @param provence
     * @param country
     * @param dateHired
     * @param dateChanged
     * @param dateTerminated
     */
    public Manager(int id, String employeeType, String firstName, String surname, String address, String email, String phoneNumber, String city, String provence, String country, Date dateHired, Date dateChanged, Date dateTerminated) {
        super(id, employeeType, firstName, surname, address, email, phoneNumber, city, provence, country, dateHired, dateChanged, dateTerminated);
    }

    /**
     *
     */
    public Manager() {
        
    }
    
}
