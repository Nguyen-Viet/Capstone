/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataEntities.EmployeeEntities;

import java.sql.Date;
import java.util.ArrayList;

/**
 *This class holds the default data attributes for all employee objects
 * @author Graham Ermter
 */
public abstract class EmployeeADT {
    
    private int id;
    private String employeeType;
    private String firstName;
    private String surname;
    private String address;
    private String email;
    private String phoneNumber;
    private String city;
    private String province;
    private String country;
    private Date dateHired;
    private Date dateChanged;
    private Date dateTerminated;
    private ArrayList contactList = new ArrayList();

    /**
     *
     */
    public EmployeeADT(){
        
    }
    
    /**
     *
     * @param id
     * @param employeeType
     * @param firstName
     * @param surname
     * @param address
     * @param email
     * @param phoneNumber
     * @param city
     * @param province
     * @param country
     * @param dateHired
     * @param dateChanged
     * @param dateTerminated
     */
    public EmployeeADT(int id, String employeeType, String firstName, String surname, String address, String email, String phoneNumber, String city, String province, String country, Date dateHired, Date dateChanged, Date dateTerminated) {
        
        this.id = id;
        this.employeeType = employeeType;
        this.firstName = firstName;
        this.surname = surname;
        this.address = address;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.city = city;
        this.province = province;
        this.country = country;
        this.dateHired = dateHired;
        this.dateChanged = dateChanged;
        this.dateTerminated = dateTerminated;
    }

    /**
     *
     * @return
     */
    public int getId() {
        return id;
    }

    /**
     *
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     *
     * @return
     */
    public String getEmployeeType() {
        return employeeType;
    }

    /**
     *
     * @param employeeType
     */
    public void setEmployeeType(String employeeType) {
        this.employeeType = employeeType;
    }

    /**
     *
     * @return
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     *
     * @param firstName
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     *
     * @return
     */
    public String getSurname() {
        return surname;
    }

    /**
     *
     * @param surname
     */
    public void setSurname(String surname) {
        this.surname = surname;
    }

    /**
     *
     * @return
     */
    public String getAddress() {
        return address;
    }

    /**
     *
     * @param address
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     *
     * @return
     */
    public String getEmail() {
        return email;
    }

    /**
     *
     * @param email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     *
     * @return
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     *
     * @param phoneNumber
     */
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    /**
     *
     * @return
     */
    public String getCity() {
        return city;
    }

    /**
     *
     * @param city
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     *
     * @return
     */
    public String getProvince() {
        return province;
    }

    /**
     *
     * @param province
     */
    public void setProvince(String province) {
        this.province = province;
    }

    /**
     *
     * @return
     */
    public String getCountry() {
        return country;
    }

    /**
     *
     * @param country
     */
    public void setCountry(String country) {
        this.country = country;
    }

    /**
     *
     * @return
     */
    public Date getDateHired() {
        return dateHired;
    }

    /**
     *
     * @param dateHired
     */
    public void setDateHired(Date dateHired) {
        this.dateHired = dateHired;
    }

    /**
     *
     * @return
     */
    public Date getDateChanged() {
        return dateChanged;
    }

    /**
     *
     * @param dateChanged
     */
    public void setDateChanged(Date dateChanged) {
        this.dateChanged = dateChanged;
    }

    /**
     *
     * @return
     */
    public Date getDateTerminated() {
        return dateTerminated;
    }

    /**
     *
     * @param dateTerminated
     */
    public void setDateTerminated(Date dateTerminated) {
        this.dateTerminated = dateTerminated;
    }

    /**
     *
     * @return
     */
    public ArrayList getContactList() {
        return contactList;
    }

    /**
     *
     * @param contactList
     */
    public void setContactList(ArrayList contactList) {
        this.contactList = contactList;
    }
    
    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return "EmployeeADT{" + "id=" + id + ", employeeType=" + employeeType + ", firstName=" + firstName + ", surname=" + surname + ", address=" + address + ", email=" + email + ", phoneNumber=" + phoneNumber + ", city=" + city + ", province=" + province + ", country=" + country + ", dateHired=" + dateHired + ", dateChanged=" + dateChanged + ", dateTerminated=" + dateTerminated + '}';
    }
    
    
}
