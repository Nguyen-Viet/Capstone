/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataAccessors.EmployeeAccessors;

import DataAccessors.DataBaseADT;
import DataEntities.EmployeeEntities.Admin;
import DataEntities.EmployeeEntities.BookKeeper;
import DataEntities.EmployeeEntities.EmployeeADT;
import DataEntities.EmployeeEntities.Manager;
import DataEntities.EmployeeEntities.Worker;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Graham Ermter
 */
public class EmployeeDatabaseADT extends DataBaseADT{

    /**
     *
     * @param id
     * @return
     */
    @Override
    public EmployeeADT get(int id) {
               
        EmployeeADT getEmployee = null;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stGet = conn.prepareCall("call searchEmployeeByID(?)");
                
                stGet.setInt(1, id);
                
                ResultSet rs = stGet.executeQuery();
                
                //Convert the next row into an employee object
                rs.next();
                getEmployee = toEmployee(rs);
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return getEmployee;
    }

    /**
     *
     * @return
     */
    @Override
    public ArrayList<EmployeeADT> getAll() {
        
        ArrayList<EmployeeADT> empList = new ArrayList<EmployeeADT>();
        
        try {
            try (Connection conn = getConnection()) {
                
                CallableStatement stGetAll = conn.prepareCall("call getAllEmployees()");
                
                ResultSet rs = stGetAll.executeQuery();
                
                //Convert and add the employees to the arraylist
                while(rs.next()){
                
                    EmployeeADT nextEmployee = toEmployee(rs);
                    empList.add(nextEmployee);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return empList;
    }

    /**
     *
     * @param name
     * @return
     */
    @Override
    public ArrayList<EmployeeADT> search(String name) {
               
        ArrayList<EmployeeADT> empList = new ArrayList<EmployeeADT>();
        
        try {
            try (Connection conn = getConnection()) {
                
                CallableStatement stSearchName = conn.prepareCall("call searchEmployeeByFullname(?, ?)");
                
                stSearchName.setString(1, name);
                stSearchName.setString(2, name);
                
                ResultSet rs = stSearchName.executeQuery();
                
                //Convert and add the employees to the arraylist
                while(rs.next()){
                
                    EmployeeADT nextEmployee = toEmployeeSearch(rs);
                    empList.add(nextEmployee);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return empList;
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public ArrayList<EmployeeADT> search(int id) {
                      
        ArrayList<EmployeeADT> empList = new ArrayList<EmployeeADT>();
        
        try {
            try (Connection conn = getConnection()) {
                
                CallableStatement stSearchName = conn.prepareCall("call searchEmployeeByID(?)");
                
                stSearchName.setInt(1, id);
                
                ResultSet rs = stSearchName.executeQuery();
                
                //Convert and add the employees to the arraylist
                while(rs.next()){
                
                    EmployeeADT nextEmployee = toEmployee(rs);
                    empList.add(nextEmployee);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return empList;
    }

    /**
     *
     * @param type
     * @return
     */
    @Override
    public ArrayList<EmployeeADT> searchType(String type) {
               
        ArrayList<EmployeeADT> empList = new ArrayList<EmployeeADT>();
        
        try {
            try (Connection conn = getConnection()) {
                
                CallableStatement stSearchName = conn.prepareCall("call searchEmployeeByType(?)");
                
                stSearchName.setString(1, type);
                
                ResultSet rs = stSearchName.executeQuery();
                
                //Convert and add the employees to the arraylist
                while(rs.next()){
                
                    EmployeeADT nextEmployee = toEmployeeSearch(rs);
                    empList.add(nextEmployee);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return empList;
    }
    
    /**
     *
     * @param id
     * @return
     */
    @Override
    public boolean delete(int id) {
        
        int complete = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stGet = conn.prepareCall("call deleteEmployeeByID(?)");
                
                stGet.setInt(1, id);
                
                complete = stGet.executeUpdate();
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete > 0;
    }
    
    /**
     *
     * @param newEmployee
     * @return
     */
    public final int add(EmployeeADT newEmployee){
        
        int newID = -1;
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stAdd = conn.prepareCall("call createEmployee(?, ?, ?, ?, ?, ?, ?, ?, ?)");
                
                stAdd.setString(1, newEmployee.getEmployeeType());
                stAdd.setString(2, newEmployee.getFirstName());
                stAdd.setString(3, newEmployee.getSurname());
                stAdd.setString(4, newEmployee.getAddress());
		stAdd.setString(5, newEmployee.getEmail());
                stAdd.setString(6, newEmployee.getPhoneNumber());
                stAdd.setString(7, newEmployee.getCity ());
		stAdd.setString(8, newEmployee.getProvince());
                stAdd.setString(9, newEmployee.getCountry());
                
                ResultSet rs = stAdd.executeQuery();
                rs.next();
                newID = rs.getInt(1);
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return newID;
    }
    
    /**
     *
     * @param toUpdate
     * @return
     */
    public final boolean update(EmployeeADT toUpdate){
        
        int complete = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stUpdate = conn.prepareCall("call updateEmployee(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                stUpdate.setInt(1, toUpdate.getId());
                stUpdate.setString(2, toUpdate.getEmployeeType());
                stUpdate.setString(3, toUpdate.getFirstName());
                stUpdate.setString(4, toUpdate.getSurname());
                stUpdate.setString(5, toUpdate.getAddress());
		stUpdate.setString(6, toUpdate.getEmail());
                stUpdate.setString(7, toUpdate.getPhoneNumber());
                stUpdate.setString(8, toUpdate.getCity ());
		stUpdate.setString(9, toUpdate.getProvince());
                stUpdate.setString(10, toUpdate.getCountry());
                
                complete = stUpdate.executeUpdate();
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete==1;
    }
    
    /**
     *
     * @param id
     * @param type
     * @param fname
     * @param surname
     * @param address
     * @param email
     * @param phone
     * @param city
     * @param province
     * @param country
     * @return
     */
    public final ArrayList<EmployeeADT> advancedSearch(int id, String type, String fname, String surname, String address, String email, String phone, String city, String province, String country){
        
        ArrayList<EmployeeADT> empList = new ArrayList<EmployeeADT>();
        
        try {
            try (Connection conn = getConnection()) {
                
                CallableStatement stAdvSrch = conn.prepareCall("call advancedSearchEmployee(?,?,?,?,?,?,?,?,?,?)");
                
                stAdvSrch.setInt(1, id);
                stAdvSrch.setString(2,type);
                stAdvSrch.setString(3,fname);
                stAdvSrch.setString(4,surname);
                stAdvSrch.setString(5,address);
                stAdvSrch.setString(6,email);
                stAdvSrch.setString(7,phone);
                stAdvSrch.setString(8,city);
                stAdvSrch.setString(9,province);
                stAdvSrch.setString(10,country);
                
                ResultSet rs = stAdvSrch.executeQuery();
                
                //Convert and add the employees to the arraylist
                while(rs.next()){
                
                    EmployeeADT nextEmployee = toEmployee(rs);
                    empList.add(nextEmployee);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return empList;
    }
    
    /**
     *
     * @param type
     * @return
     */
    public EmployeeADT getEmployeeTypeClass(String type) {
        EmployeeADT employee = null;
        switch (type) {
            case "AD":
                employee = new Admin();
                break;
            case "MA":
                employee = new Manager();
                break;
            case "WR":
                employee = new Worker();
                break;
            case "BK":
                employee = new BookKeeper();
        }
        return employee;
    }
        
    /**
     *
     * @param rs
     * @return
     * @throws SQLException
     */
    public EmployeeADT toEmployee(ResultSet rs) throws SQLException{
        
        //Get employee of proper type
        EmployeeADT newEmployee = getEmployeeTypeClass(rs.getString(2));
        
        //Insert all values into employee
        newEmployee.setId(rs.getInt(1));
        newEmployee.setEmployeeType(rs.getString(2));
        newEmployee.setFirstName(rs.getString(3));
        newEmployee.setSurname(rs.getString(4));
        newEmployee.setAddress(rs.getString(5));
        newEmployee.setEmail(rs.getString(6));
        newEmployee.setPhoneNumber(rs.getString(7));
        newEmployee.setCity(rs.getString(8));
        newEmployee.setProvince(rs.getString(9));
        newEmployee.setCountry(rs.getString(10));
        newEmployee.setDateChanged(rs.getDate(11));
        newEmployee.setDateHired(rs.getDate(12));
        newEmployee.setDateTerminated(rs.getDate(13));
        
        return newEmployee;
    }
    
    /**
     *
     * @param rs
     * @return
     * @throws SQLException
     */
    public EmployeeADT toEmployeeSearch(ResultSet rs) throws SQLException{
        
        //Get employee of proper type
        EmployeeADT newEmployee = getEmployeeTypeClass(rs.getString(4));
        
        //Insert aquired values into employee
        newEmployee.setId(rs.getInt(1));
        newEmployee.setFirstName(rs.getString(2));
        newEmployee.setSurname(rs.getString(3));
        newEmployee.setEmployeeType(rs.getString(4));
        
        return newEmployee;
    }
    
    /**
     *
     * @param employeeID
     * @param contactID
     * @return
     */
    public boolean addEmployeeContact(int employeeID, int contactID){
        
        int rows = 0;
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stAddClientContact = conn.prepareCall("call addEmployeeContact(?,?)");
                stAddClientContact.setInt(1, employeeID);
                stAddClientContact.setInt(2, contactID);
                rows = stAddClientContact.executeUpdate();
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return rows > 0;
    }
}
