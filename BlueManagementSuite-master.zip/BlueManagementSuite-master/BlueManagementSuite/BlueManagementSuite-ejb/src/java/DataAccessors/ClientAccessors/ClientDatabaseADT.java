/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataAccessors.ClientAccessors;

import DataAccessors.DataBaseADT;
import DataEntities.ClientEntities.ClientADT;
import DataEntities.ClientEntities.CorporateClient;
import DataEntities.ClientEntities.IndependentClient;
import DataEntities.ClientEntities.Supplier;
import DataEntities.ClientEntities.Vendor;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ese Brooks & Graham Ermter
 */
public abstract class ClientDatabaseADT extends DataBaseADT {
    
    /**
     * 
     * @param newClient
     * @return new id
     * adds a new client to the database and returns the new id of 
     * the added client, if it failed it will return -1.
     */
    public int add(ClientADT newClient) {
        int newID = -1;
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stAdd = conn.prepareCall("call createClient(?,?,?)");
                stAdd.setString(1, newClient.getType());
                stAdd.setString(2, newClient.getName());
                stAdd.setString(3, newClient.getEmail());
                ResultSet rs = stAdd.executeQuery();
                rs.next();
                newID = rs.getInt(1);
                conn.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(CorporateClientAccessor.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return newID;
    }
    
    /**
     *
     * @param toUpdate
     * @return
     */
    public boolean update(ClientADT toUpdate) {
        int rows = 0;
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stUpdate = conn.prepareCall("call updateClient(?,?,?,?)");
                stUpdate.setInt(1, toUpdate.getId());
                stUpdate.setString(2, toUpdate.getType());
                stUpdate.setString(3, toUpdate.getName());
                stUpdate.setString(4, toUpdate.getEmail());
                
                rows = stUpdate.executeUpdate();
                conn.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(CorporateClientAccessor.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return rows > 0;
    }
    
    /**
     * Gets all clients based on the provided input data, if id is set to -1,
     * it will not consider the value of id, if anything else is set to null,
     * it will also ignore those values.
     * @param id
     * @param type
     * @param name
     * @param email
     * @return ArrayList
     */
    public ArrayList<ClientADT> advancedSearch(int id, String type, String name, String email) {
        
        ArrayList<ClientADT> clientList = new ArrayList<ClientADT>();
        try {
            try (Connection conn = getConnection()) {
                CallableStatement advancedClientSearch = conn.prepareCall("call advancedSearchClient(?,?,?,?)");
                
                advancedClientSearch.setInt(1, id);
                advancedClientSearch.setString(2, type);
                advancedClientSearch.setString(3, name);
                advancedClientSearch.setString(4, email);
                
                ResultSet rs = advancedClientSearch.executeQuery();
                
                //while there are still rows in the result set
                while(rs.next()){

                    ClientADT thisClient = toClient(rs);
                    clientList.add(thisClient);
                }
                conn.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(CorporateClientAccessor.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return clientList;
    }
    
    /**
     * Gets the client based on the provided id number
     * @param id
     * @return ClientADT
     */
    @Override
    public ClientADT get(int id) {
        
        ClientADT client = null;
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stGetClientContacts = conn.prepareCall("call searchClientByID(?)");
                stGetClientContacts.setInt(1, id);
                ResultSet rs = stGetClientContacts.executeQuery();
                rs.next();
                
                client = toClient(rs);                
                conn.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(CorporateClientAccessor.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return client;
    }
    
    /**
     * Gets all clients regardless of type, name, or any other value.
     * @return ArrayList
     */
    @Override
    public ArrayList<ClientADT> getAll() {
        
        ArrayList<ClientADT> clients = new ArrayList<ClientADT>();
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stGetAllClients = conn.prepareCall("call getAllClients()");
                ResultSet rs = stGetAllClients.executeQuery();
                
                while (rs.next()) {
                    ClientADT client = toClient(rs);
                    clients.add(client);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(CorporateClientAccessor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return clients;
    }
    
    /**
     * searches the clients first and surnames by the provided string
     * @param name
     * @return ArrayList
     */
    @Override
    public ArrayList<ClientADT> search(String name) {
        ArrayList<ClientADT> clients = new ArrayList<ClientADT>();
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stSearchClientByName = conn.prepareCall("call searchClientByName(?)");
                stSearchClientByName.setString(1, name);
                ResultSet rs = stSearchClientByName.executeQuery();
                
                while (rs.next()) {               
                    ClientADT client = toClient(rs);
                    clients.add(client);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(CorporateClientAccessor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return clients;
    }
    
    /**
     * Searches clients by the provided id number
     * @param id
     * @return ArrayList
     */
    @Override
    public ArrayList<ClientADT> search(int id) {
        ArrayList<ClientADT> clients = new ArrayList<ClientADT>();
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stSearchClientByID = conn.prepareCall("call searchClientByID(?)");
                stSearchClientByID.setInt(1, id);
                ResultSet rs = stSearchClientByID.executeQuery();
                
                while (rs.next()) {
                    ClientADT client = toClient(rs);
                    clients.add(client);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(CorporateClientAccessor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return clients;
    }
    
    /**
     * Searches all clients by type and returns a list of found objects
     * @param type
     * @return arrayList
     */
    @Override
    public ArrayList<ClientADT> searchType(String type) {
        ArrayList<ClientADT> clients = new ArrayList<ClientADT>();
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stSearchClientByID = conn.prepareCall("call searchClientByType(?)");
                stSearchClientByID.setString(1, type);
                ResultSet rs = stSearchClientByID.executeQuery();
                
                while (rs.next()) {
                    ClientADT client = toClient(rs);
                    clients.add(client);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(CorporateClientAccessor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return clients;
    }
    
    /**
     * deletes a client with the id provided
     * @param id
     * @return boolean
     */
    @Override
    public boolean delete(int id) {
        int rows = 0;
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stDelete = conn.prepareCall("call deleteClientByID(?)");
                stDelete.setInt(1, id);
                rows = stDelete.executeUpdate();
                conn.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(CorporateClientAccessor.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return rows > 0;
    }
    
    /**
     * Joins a client with a contact in the database, once this is done, it will
     * be joined until either object is removed or deleted. Even through updates.
     * @param clientID
     * @param contactID
     * @return 
     */
    public boolean addClientContact(int clientID, int contactID){
        
        int rows = 0;
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stAddClientContact = conn.prepareCall("call addClientContact(?,?)");
                stAddClientContact.setInt(1, clientID);
                stAddClientContact.setInt(2, contactID);
                rows = stAddClientContact.executeUpdate();
                conn.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(CorporateClientAccessor.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return rows > 0;
    }
    
    /**
     * Converts one row in a result set into a client object and returns it
     * @param rs
     * @return clientADT
     * @throws java.sql.SQLException
     */
    public ClientADT toClient(ResultSet rs) throws SQLException{
        
        ClientADT newClient = getClientTypeClass(rs.getString(2));
        
        newClient.setId(rs.getInt(1));
        newClient.setType(rs.getString(2));
        newClient.setName(rs.getString(3));
        newClient.setDateCreated(rs.getDate(4));
        newClient.setEmail(rs.getString(5));
        
        return newClient;
    }
    
    /**
     *
     * @param type
     * @return
     */
    public ClientADT getClientTypeClass(String type) {
        ClientADT client = null;
        switch (type) {
            case "CO":
                client = new CorporateClient();
                break;
            case "IN":
                client = new IndependentClient();
                break;
            case "SP":
                client = new Supplier();
                break;
            case "VR":
                client = new Vendor();
        }
        return client;
    }
}
