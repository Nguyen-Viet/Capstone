/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Materials | Templates
 * and open the template in the editor.
 */
package DataAccessors.MaterialAccessors;

import DataAccessors.DataBaseADT;
import DataEntities.MaterialEntities.Material;
import DataEntities.MaterialEntities.MaterialADT;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Graham Ermter
 */
public class MaterialDatabaseADT extends DataBaseADT {
    
    /**
     *
     * @param addMaterial
     * @return
     */
    public int addMaterial(MaterialADT addMaterial){
        
        int newMaterialID = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stGet = conn.prepareCall("call createMaterial(?,?,?,?)");
                
                stGet.setString(1, addMaterial.getName());
                stGet.setString(2, addMaterial.getDescription());
                stGet.setInt(3, addMaterial.getQuantity());
                stGet.setString(4, addMaterial.getCategory());
                
                ResultSet rs = stGet.executeQuery();
                
                rs.next();
                newMaterialID = rs.getInt(1);
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return newMaterialID;
    }
    
    /**
     *
     * @param upMaterial
     * @return
     */
    public boolean updateMaterial(MaterialADT upMaterial){
        
        int complete = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stGet = conn.prepareCall("call updateMaterial(?,?,?,?,?)");
                
                stGet.setInt(1, upMaterial.getId());
                stGet.setString(2, upMaterial.getName());
                stGet.setString(3, upMaterial.getDescription());
                stGet.setInt(4, upMaterial.getQuantity());
                stGet.setString(5, upMaterial.getCategory());
                
                complete = stGet.executeUpdate();
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete != 0;
    }
    
    /**
     *
     * @param id
     * @return
     */
    @Override
    public MaterialADT get(int id) {
        
        MaterialADT getMaterial = null;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stGet = conn.prepareCall("call searchMaterialByID(?)");
                
                stGet.setInt(1, id);
                
                ResultSet rs = stGet.executeQuery();
                
                //Convert the next row into an object
                rs.next();
                getMaterial = toMaterial(rs);
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return getMaterial;
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public boolean delete(int id) {
        
        int complete = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stGet = conn.prepareCall("call deleteMaterialByID(?)");
                
                stGet.setInt(1, id);
                
                complete = stGet.executeUpdate();
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete != 0;
    }
    
    /**
     *
     * @return
     */
    @Override
    public ArrayList<MaterialADT> getAll() {
        
        ArrayList<MaterialADT> materialList = new ArrayList<MaterialADT>();
        
        try {
            try (Connection conn = getConnection()) {
                
                CallableStatement stGetAll = conn.prepareCall("call getAllMaterials()");
                
                ResultSet rs = stGetAll.executeQuery();
                
                //Convert and add the objects to the arraylist
                while(rs.next()){
                
                    MaterialADT thisMaterial = toMaterial(rs);
                    materialList.add(thisMaterial);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return materialList;
    }

    /**
     *
     * @param name
     * @return
     */
    @Override
    public ArrayList<MaterialADT> search(String name) {
        
        ArrayList<MaterialADT> materialList = new ArrayList<MaterialADT>();
        
        try {
            try (Connection conn = getConnection()) {
                
                CallableStatement search = conn.prepareCall("call searchMaterialByName(?)");
                
                search.setString(1, name);
                
                ResultSet rs = search.executeQuery();
                
                //Convert and add the objects to the arraylist
                while(rs.next()){
                
                    MaterialADT thisMaterial = toMaterial(rs);
                    materialList.add(thisMaterial);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return materialList;
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public ArrayList<MaterialADT> search(int id) {
        
        ArrayList<MaterialADT> materialList = new ArrayList<MaterialADT>();
        
        try {
            try (Connection conn = getConnection()) {
                
                CallableStatement search = conn.prepareCall("call searchMaterialByID(?)");
                
                search.setInt(1, id);
                
                ResultSet rs = search.executeQuery();
                
                //Convert and add the objects to the arraylist
                while(rs.next()){
                
                    MaterialADT thisMaterial = toMaterial(rs);
                    materialList.add(thisMaterial);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return materialList;
    }

    /**
     *
     * @param type
     * @return
     */
    @Override
    public ArrayList<MaterialADT> searchType(String type) {
        
        ArrayList<MaterialADT> materialList = new ArrayList<MaterialADT>();
        
        try {
            try (Connection conn = getConnection()) {
                
                CallableStatement search = conn.prepareCall("call searchMaterialByCategory(?)");
                
                search.setString(1, type);
                
                ResultSet rs = search.executeQuery();
                
                //Convert and add the objects to the arraylist
                while(rs.next()){
                
                    MaterialADT thisMaterial = toMaterial(rs);
                    materialList.add(thisMaterial);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return materialList;
    }
    
    /**
     *
     * @param id
     * @param name
     * @param category
     * @param clientName
     * @param description
     * @param lowPrice
     * @param highPrice
     * @return
     */
    public ArrayList<MaterialADT> advancedSearch(int id, String name, String category, String clientName, String description, double lowPrice, double highPrice){
        
        ArrayList<MaterialADT> materialList = new ArrayList<MaterialADT>();
        
        try {
            try (Connection conn = getConnection()) {
                
                CallableStatement search = conn.prepareCall("call advancedSearchClientMaterial(?,?,?,?,?,?,?)");
                
                search.setInt(1, id);
                search.setString(2, name);
                search.setString(3, category);
                search.setString(4, clientName);
                search.setString(5, description);
                search.setDouble(6, lowPrice);
                search.setDouble(7, highPrice);
                
                ResultSet rs = search.executeQuery();
                
                //Convert and add the objects to the arraylist
                while(rs.next()){
                
                    MaterialADT thisMaterial = toMaterial(rs);
                    materialList.add(thisMaterial);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return materialList;
    }
    
    /**
     *
     * @param clientID
     * @param materialID
     * @param price
     * @return
     */
    public boolean addClientMaterial(int clientID, int materialID, double price){
        
        int complete = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call addClientMaterial(?,?,?)");
                
                st.setInt(1, clientID);
                st.setInt(2, materialID);
                st.setDouble(3, price);
                
                complete = st.executeUpdate();
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete != 0;
        
    }
    
    /**
     *
     * @param clientID
     * @param materialID
     * @param price
     * @return
     */
    public boolean updateClientMaterial(int clientID, int materialID, double price){
        int complete = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call updateClientMaterial(?,?,?)");
                
                st.setInt(1, clientID);
                st.setInt(2, materialID);
                st.setDouble(3, price);
                
                complete = st.executeUpdate();
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete != 0;
    }
    
    /**
     *
     * @param clientID
     * @param materialID
     * @return
     */
    public boolean deleteClientMaterial(int clientID, int materialID){
                int complete = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call deleteClientMaterial(?,?)");
                
                st.setInt(1, clientID);
                st.setInt(2, materialID);
                
                complete = st.executeUpdate();
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete != 0;
    }
    
    /**
     *
     * @param materialID
     * @return
     */
    public ArrayList<String> getCategories(){
        ArrayList<String> categories = new ArrayList<String>();
        
        try {
            try (Connection conn = getConnection()) {
                
                CallableStatement getCategories = conn.prepareCall("call getUniqueMaterialCategory()");
                ResultSet rs = getCategories.executeQuery();
                
                //Convert and add the objects to the arraylist
                while(rs.next()){
                    categories.add(rs.getString(1));
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return categories;
    }
    
    public ArrayList<Integer> getClientsByMaterial(int materialID){
        
        ArrayList<Integer> clientIDList = new ArrayList();
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call getClientsByMaterial(?)");
                
                st.setInt(1, materialID);
                
                ResultSet rs = st.executeQuery();
                
                while(rs.next()){
                 
                    clientIDList.add(rs.getInt(1));
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return clientIDList;
    }
    
    /**
     *
     * @param clientID
     * @param materialID
     * @return
     */
    public double getMaterialPrice(int clientID, int materialID){

        double materialPrice = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call getMaterialPrice(?,?)");
                
                st.setInt(1, clientID);
                st.setInt(2, materialID);
                
                ResultSet rs = st.executeQuery();
                rs.next();
                materialPrice = rs.getDouble(1);
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return materialPrice;   
    }
    
    
    private MaterialADT toMaterial(ResultSet rs) throws SQLException{
        
        Material newMaterial = new Material();
        
        newMaterial.setId(rs.getInt(1));
        newMaterial.setName(rs.getString(2));
        newMaterial.setDescription(rs.getString(3));
        newMaterial.setQuantity(rs.getInt(4));
        newMaterial.setCategory(rs.getString(5));
        
        return newMaterial;
    }
}
