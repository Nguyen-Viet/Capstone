/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Materials | Templates
 * and open the template in the editor.
 */
package DataAccessors.AssemblyAccessors;

import DataAccessors.DataBaseADT;
import DataEntities.AssemblyEntities.Assembly;
import DataEntities.AssemblyEntities.AssemblyADT;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Graham Ermter
 */
public abstract class AssemblyDatabaseADT extends DataBaseADT {

    /**
     *
     * @param addAssembly
     * @return
     */
    public int addAssembly(AssemblyADT addAssembly) {

        int newAssemblyID = 0;

        try {
            try (Connection conn = getConnection()) {
                CallableStatement stGet = conn.prepareCall("call createAssembly(?,?,?)");

                stGet.setString(1, addAssembly.getName());
                stGet.setString(2, addAssembly.getDescription());
                stGet.setString(3, addAssembly.getCategory());

                ResultSet rs = stGet.executeQuery();

                rs.next();
                newAssemblyID = rs.getInt(1);

                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return newAssemblyID;
    }

    /**
     *
     * @param upAssembly
     * @return
     */
    public boolean updateAssembly(AssemblyADT upAssembly) {

        int complete = 0;

        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call updateAssembly(?,?,?,?)");

                st.setInt(1, upAssembly.getId());
                st.setString(2, upAssembly.getName());
                st.setString(3, upAssembly.getDescription());
                st.setString(4, upAssembly.getCategory());

                complete = st.executeUpdate();

                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return complete != 0;
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public AssemblyADT get(int id) {

        AssemblyADT getAssembly = null;

        try {
            try (Connection conn = getConnection()) {
                CallableStatement stGet = conn.prepareCall("call searchAssemblyByID(?)");

                stGet.setInt(1, id);

                ResultSet rs = stGet.executeQuery();

                //Convert the next row into an object
                rs.next();
                getAssembly = toAssembly(rs);

                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return getAssembly;
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public boolean delete(int id) {

        int complete = 0;

        try {
            try (Connection conn = getConnection()) {
                CallableStatement stGet = conn.prepareCall("call deleteAssemblyByID(?)");

                stGet.setInt(1, id);

                complete = stGet.executeUpdate();

                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return complete != 0;
    }

    /**
     *
     * @return
     */
    @Override
    public ArrayList<AssemblyADT> getAll() {

        ArrayList<AssemblyADT> assemblyList = new ArrayList<AssemblyADT>();

        try {
            try (Connection conn = getConnection()) {

                CallableStatement stGetAll = conn.prepareCall("call getAllAssemblies()");

                ResultSet rs = stGetAll.executeQuery();

                //Convert and add the objects to the arraylist
                while (rs.next()) {

                    AssemblyADT thisAssembly = toAssembly(rs);
                    assemblyList.add(thisAssembly);
                }

                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return assemblyList;
    }

    /**
     *
     * @param name
     * @return
     */
    @Override
    public ArrayList<AssemblyADT> search(String name) {

        ArrayList<AssemblyADT> assemblyList = new ArrayList<AssemblyADT>();

        try {
            try (Connection conn = getConnection()) {

                CallableStatement search = conn.prepareCall("call searchAssemblyByName(?)");

                search.setString(1, name);

                ResultSet rs = search.executeQuery();

                //Convert and add the objects to the arraylist
                while (rs.next()) {

                    AssemblyADT thisAssembly = toAssembly(rs);
                    assemblyList.add(thisAssembly);
                }

                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return assemblyList;
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public ArrayList<AssemblyADT> search(int id) {

        ArrayList<AssemblyADT> assemblyList = new ArrayList<AssemblyADT>();

        try {
            try (Connection conn = getConnection()) {

                CallableStatement search = conn.prepareCall("call searchAssemblyByID(?)");

                search.setInt(1, id);

                ResultSet rs = search.executeQuery();

                //Convert and add the objects to the arraylist
                while (rs.next()) {

                    AssemblyADT thisAssembly = toAssembly(rs);
                    assemblyList.add(thisAssembly);
                }

                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return assemblyList;
    }

    /**
     *
     * @param type
     * @return
     */
    @Override
    public ArrayList<AssemblyADT> searchType(String type) {

        ArrayList<AssemblyADT> assemblyList = new ArrayList<AssemblyADT>();

        try {
            try (Connection conn = getConnection()) {

                CallableStatement search = conn.prepareCall("call searchAssemblyByCategory(?)");

                search.setString(1, type);

                ResultSet rs = search.executeQuery();

                //Convert and add the objects to the arraylist
                while (rs.next()) {

                    AssemblyADT thisAssembly = toAssembly(rs);
                    assemblyList.add(thisAssembly);
                }

                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return assemblyList;
    }

    /**
     *
     * @param id
     * @param name
     * @param description
     * @param category
     * @return
     */
    public ArrayList<AssemblyADT> advancedSearch(int id, String name, String description, String category) {

        ArrayList<AssemblyADT> assemblyList = new ArrayList<AssemblyADT>();

        try {
            try (Connection conn = getConnection()) {

                CallableStatement search = conn.prepareCall("call advancedSearchAssembly(?,?,?,?)");

                search.setInt(1, id);
                search.setString(2, name);
                search.setString(3, description);
                search.setString(4, category);

                ResultSet rs = search.executeQuery();

                //Convert and add the objects to the arraylist
                while (rs.next()) {

                    AssemblyADT thisAssembly = toAssembly(rs);
                    assemblyList.add(thisAssembly);
                }

                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return assemblyList;
    }

    /**
     *
     * @param assemblyID
     * @param materialID
     * @return
     */
    public boolean addMaterial(int assemblyID, int materialID) {

        int complete = 0;

        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call addAssemblyMaterial(?,?)");

                st.setInt(1, assemblyID);
                st.setInt(2, materialID);

                complete = st.executeUpdate();

                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return complete != 0;
    }

    /**
     *
     * @param assemblyID
     * @param materialID
     * @return
     */
    public boolean deleteMaterial(int assemblyID, int materialID) {

        int complete = 0;

        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call deleteMaterialFromAssembly(?,?)");

                st.setInt(1, assemblyID);
                st.setInt(2, materialID);

                complete = st.executeUpdate();

                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return complete != 0;
    }

    /**
     *
     * @param id
     * @return
     */
    public ArrayList<Integer> getMaterials(int id) {

        ArrayList<Integer> matIDList = new ArrayList<>();

        try {
            try (Connection conn = getConnection()) {

                CallableStatement search = conn.prepareCall("call getAssemblyMaterials(?)");

                search.setInt(1, id);

                ResultSet rs = search.executeQuery();

                //Convert and add the objects to the arraylist
                while (rs.next()) {

                    matIDList.add(rs.getInt(1));
                }

                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return matIDList;
    }

    private AssemblyADT toAssembly(ResultSet rs) throws SQLException {

        Assembly newAssembly = new Assembly();

        newAssembly.setId(rs.getInt(1));
        newAssembly.setName(rs.getString(2));
        newAssembly.setDescription(rs.getString(3));
        newAssembly.setCategory(rs.getString(4));

        return newAssembly;
    }
}
