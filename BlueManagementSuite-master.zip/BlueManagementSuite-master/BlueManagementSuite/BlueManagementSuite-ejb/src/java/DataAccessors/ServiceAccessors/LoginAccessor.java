/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataAccessors.ServiceAccessors;

import DataAccessors.DataBaseADT;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 * Class designed to validate logins of clients and employees
 * @author Graham Ermter
 */
public final class LoginAccessor {
    
    /**
     *
     * @param username
     * @param password
     * @return
     */
    public int validateClient(String username, String password){
        
        int accountID = 0;
        
        try {
            try (Connection conn = getConnection()) {
                
                CallableStatement stValid = conn.prepareCall("call validateClientAccount(?,?)");
                
                stValid.setString(1, username);
                stValid.setString(2, password);
                
                ResultSet rs = stValid.executeQuery();
                rs.next();
                accountID = rs.getInt(1);
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return accountID;
    }
    
    /**
     *
     * @param username
     * @param password
     * @return
     */
    public int validateEmployee(String username, String password){
                int accountID = 0;
        
        try {
            try (Connection conn = getConnection()) {
                
                CallableStatement stValid = conn.prepareCall("call validateEmployeeAccount(?,?)");
                
                stValid.setString(1, username);
                stValid.setString(2, password);
                
                ResultSet rs = stValid.executeQuery();
                rs.next();
                accountID = rs.getInt(1);
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return accountID;
    }

    /**
     *
     * @return
     */
    final public Connection getConnection(){
        Connection connection = null;
        try {
            DataSource ds = (DataSource) (new InitialContext().lookup("jdbc/bluePool"));
            connection = ds.getConnection();
        } catch (NamingException | SQLException ex) {
            Logger.getLogger(DataBaseADT.class.getName()).log(Level.SEVERE, null, ex);
        }
        return connection;
    }
}
