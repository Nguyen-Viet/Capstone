/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataAccessors.ServiceAccessors;

import DataAccessors.DataBaseADT;
import DataEntities.ServiceEntities.Contact;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Graham Ermter
 */
public class ContactDatabaseAccessor extends DataBaseADT {

    /**
     *
     * @param toAdd
     * @return boolean adds a new contact to the database and returns if it
     * worked or not
     * @throws java.sql.SQLException
     */
    public int addContact(Contact toAdd) throws SQLException {

        Connection conn = getConnection();
        CallableStatement addCon = conn.prepareCall("call createContact(?,?,?,?,?,?,?,?,?,?,?)");

        addCon.setString(1, toAdd.getType());
        addCon.setString(2, toAdd.getFirstName());
        addCon.setString(3, toAdd.getSurName());
        addCon.setString(4, toAdd.getAddress());
        addCon.setString(5, toAdd.getEmail());
        addCon.setString(6, toAdd.getPhoneNumber());
        addCon.setString(7, toAdd.getCity());
        addCon.setString(8, toAdd.getProvince());
        addCon.setString(9, toAdd.getCountry());
        addCon.setString(10, toAdd.getQuadrant());
        addCon.setString(11, toAdd.getCompany());

        ResultSet result = addCon.executeQuery();
        result.next();
        
        int newID = result.getInt(1);
        
        conn.close();

        return newID;
    }

    /**
     *
     * @param toUpdate
     * @return boolean
     * @throws java.sql.SQLException
     */
    public boolean updateContact(Contact toUpdate) throws SQLException {

        Connection conn = getConnection();
        CallableStatement updateCon = conn.prepareCall("call updateContact(?,?,?,?,?,?,?,?,?,?,?,?)");

        updateCon.setInt(1, toUpdate.getId());
        updateCon.setString(2, toUpdate.getType());
        updateCon.setString(3, toUpdate.getFirstName());
        updateCon.setString(4, toUpdate.getSurName());
        updateCon.setString(5, toUpdate.getAddress());
        updateCon.setString(6, toUpdate.getEmail());
        updateCon.setString(7, toUpdate.getPhoneNumber());
        updateCon.setString(8, toUpdate.getCity());
        updateCon.setString(9, toUpdate.getProvince());
        updateCon.setString(10, toUpdate.getCountry());
        updateCon.setString(11, toUpdate.getQuadrant());
        updateCon.setString(12, toUpdate.getCompany());

        int result = updateCon.executeUpdate();

        conn.close();

        return result > 0;
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public Contact get(int id) {

        Connection conn = getConnection();

        try {

            CallableStatement getCon = conn.prepareCall("call getContact(?)");
            getCon.setInt(1, id);
            ResultSet conData = getCon.executeQuery();
            conData.next();
            Contact newCon = toContact(conData);
            conn.close();
            return newCon;

        } catch (SQLException ex) {
            Logger.getLogger(ContactDatabaseAccessor.class.getName()).log(Level.SEVERE, null, ex);
            closeConnection(conn);
            return null;
        }
    }

    /**
     *
     * @return
     */
    @Override
    public ArrayList getAll() {

        Connection conn = getConnection();
        ArrayList<Contact> conList = new ArrayList<Contact>();

        try {

            CallableStatement getAllCon = conn.prepareCall("call getAllContacts()");
            ResultSet conData = getAllCon.executeQuery();

            //Move to the next row, convert, and add to the array
            while (conData.next()) {

                Contact newCon = toContact(conData);
                conList.add(newCon);
            }

        } catch (SQLException ex) {

            Logger.getLogger(ContactDatabaseAccessor.class.getName()).log(Level.SEVERE, null, ex);
        }

        closeConnection(conn);

        return conList;
    }

    /**
     *
     * @param name
     * @return
     */
    @Override
    public ArrayList search(String name) {

        Connection conn = getConnection();
        ArrayList<Contact> conList = new ArrayList<Contact>();

        try {

            CallableStatement searchString = conn.prepareCall("call searchContactByFullName(?,?)");

            searchString.setString(1, name);
            searchString.setString(2, name);

            ResultSet conData = searchString.executeQuery();

            //Move to the next row, convert, and add to the array
            while (conData.next()) {

                Contact newCon = toSearchContact(conData);
                conList.add(newCon);
            }

        } catch (SQLException ex) {

            Logger.getLogger(ContactDatabaseAccessor.class.getName()).log(Level.SEVERE, null, ex);
        }

        closeConnection(conn);

        return conList;
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public ArrayList search(int id) {

        Connection conn = getConnection();
        ArrayList<Contact> conList = new ArrayList<Contact>();

        try {

            CallableStatement searchID = conn.prepareCall("call searchContactByID(?)");

            searchID.setInt(1, id);

            ResultSet conData = searchID.executeQuery();

            //Move to the next row, convert, and add to the array
            while (conData.next()) {

                Contact newCon = toSearchContact(conData);
                conList.add(newCon);
            }

        } catch (SQLException ex) {

            Logger.getLogger(ContactDatabaseAccessor.class.getName()).log(Level.SEVERE, null, ex);
        }

        closeConnection(conn);

        return conList;
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public boolean delete(int id) {
        Connection conn = getConnection();
        int conStatus = 0;
        
        try {

            CallableStatement deleteCon = conn.prepareCall("call deleteContactByID(?)");

            deleteCon.setInt(1, id);

            conStatus = deleteCon.executeUpdate();

            closeConnection(conn);
            return conStatus > 0;
            
        } catch (SQLException ex) {

            Logger.getLogger(ContactDatabaseAccessor.class.getName()).log(Level.SEVERE, null, ex);
            closeConnection(conn);
            return conStatus > 0;
        }
    }

    /**
     * @param conData
     * @return Contact
     * @throws java.sql.SQLException This function takes in a ResultSet and
     * converts the values into a permission object.
     */
    public Contact toContact(ResultSet conData) throws SQLException {

        //Create new contact to return
        Contact newCon = new Contact();

        //Feed the result set data into the contact
        newCon.setId(conData.getInt(1));
        newCon.setType(conData.getString(2));
        newCon.setFirstName(conData.getString(3));
        newCon.setSurName(conData.getString(4));
        newCon.setAddress(conData.getString(5));
        newCon.setEmail(conData.getString(6));
        newCon.setPhoneNumber(conData.getString(7));
        newCon.setCity(conData.getString(8));
        newCon.setProvince(conData.getString(9));
        newCon.setCountry(conData.getString(10));
        newCon.setQuadrant(conData.getString(11));
        newCon.setCompany(conData.getString(12));

        //Return the newly created contact
        return newCon;
    }

    /**
     * @param conData
     * @return Contact
     * @throws java.sql.SQLException This function takes in a ResultSet and
     * converts the values into a permission object.
     */
    public Contact toSearchContact(ResultSet conData) throws SQLException {

        //Create new contact to return
        Contact newCon = new Contact();

        //Feed the result set data into the contact
        newCon.setId(conData.getInt(1));
        newCon.setType(conData.getString(2));
        newCon.setFirstName(conData.getString(3));
        newCon.setSurName(conData.getString(4));


        //Return the newly created search contact
        return newCon;
    }
    
    /**
     *
     * @param id
     * @return
     */
    public final ArrayList<Contact> getContactsByClient(int id){
        
        Connection conn = getConnection();
        ArrayList<Contact> conList = new ArrayList<Contact>();

        try {

            CallableStatement getContactByClient = conn.prepareCall("call getClientContacts(?)");

            getContactByClient.setInt(1, id);

            ResultSet conData = getContactByClient.executeQuery();

            //Move to the next row, convert, and add to the array
            while (conData.next()) {

                Contact newCon = toContact(conData);
                conList.add(newCon);
            }

        } catch (SQLException ex) {

            Logger.getLogger(ContactDatabaseAccessor.class.getName()).log(Level.SEVERE, null, ex);
        }

        closeConnection(conn);

        return conList;
    }
    
    /**
     *
     * @param id
     * @return
     */
    public final ArrayList<Contact> getContactsByEmployee(int id){
        
        Connection conn = getConnection();
        ArrayList<Contact> conList = new ArrayList<Contact>();

        try {

            CallableStatement getContactByClient = conn.prepareCall("call getEmployeeContacts(?)");

            getContactByClient.setInt(1, id);

            ResultSet conData = getContactByClient.executeQuery();

            //Move to the next row, convert, and add to the array
            while (conData.next()) {

                Contact newCon = toContact(conData);
                conList.add(newCon);
            }

        } catch (SQLException ex) {

            Logger.getLogger(ContactDatabaseAccessor.class.getName()).log(Level.SEVERE, null, ex);
        }

        closeConnection(conn);

        return conList;
    }
    
    /**
     *
     * @param type
     * @return
     */
    @Override
    public ArrayList searchType(String type) {
        throw new UnsupportedOperationException("Search type not supported by contact");
    }
}
