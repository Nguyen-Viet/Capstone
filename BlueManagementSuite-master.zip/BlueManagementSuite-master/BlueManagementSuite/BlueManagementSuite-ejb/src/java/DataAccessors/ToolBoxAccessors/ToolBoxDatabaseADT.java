/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataAccessors.ToolBoxAccessors;

import DataAccessors.DataBaseADT;
import DataEntities.ToolBoxEntities.ToolBox;
import DataEntities.ToolBoxEntities.ToolBoxADT;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Graham Ermter
 */
public abstract class ToolBoxDatabaseADT extends DataBaseADT {

    /**
     *
     * @param addToolBox
     * @return
     */
    public int addToolBox(ToolBoxADT addToolBox) {

        int newToolBoxID = 0;

        try {
            try (Connection conn = getConnection()) {
                CallableStatement stGet = conn.prepareCall("call createToolBox(?,?,?)");

                stGet.setString(1, addToolBox.getName());
                stGet.setString(2, addToolBox.getDescription());
                stGet.setString(3, addToolBox.getCategory());

                ResultSet rs = stGet.executeQuery();

                rs.next();
                newToolBoxID = rs.getInt(1);

                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return newToolBoxID;
    }

    /**
     *
     * @param upToolBox
     * @return
     */
    public boolean updateToolBox(ToolBoxADT upToolBox) {

        int complete = 0;

        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call updateToolBox(?,?,?,?)");

                st.setInt(1, upToolBox.getId());
                st.setString(2, upToolBox.getName());
                st.setString(3, upToolBox.getDescription());
                st.setString(4, upToolBox.getCategory());

                complete = st.executeUpdate();

                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return complete != 0;
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public ToolBoxADT get(int id) {

        ToolBoxADT getToolBox = null;

        try {
            try (Connection conn = getConnection()) {
                CallableStatement stGet = conn.prepareCall("call searchToolBoxByID(?)");

                stGet.setInt(1, id);

                ResultSet rs = stGet.executeQuery();

                //Convert the next row into an object
                rs.next();
                getToolBox = toToolBox(rs);

                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return getToolBox;
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public boolean delete(int id) {

        int complete = 0;

        try {
            try (Connection conn = getConnection()) {
                CallableStatement stGet = conn.prepareCall("call deleteToolBoxByID(?)");

                stGet.setInt(1, id);

                complete = stGet.executeUpdate();

                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return complete != 0;
    }

    /**
     *
     * @return
     */
    @Override
    public ArrayList<ToolBoxADT> getAll() {

        ArrayList<ToolBoxADT> toolBoxList = new ArrayList<ToolBoxADT>();

        try {
            try (Connection conn = getConnection()) {

                CallableStatement stGetAll = conn.prepareCall("call getAllToolBoxes()");

                ResultSet rs = stGetAll.executeQuery();

                //Convert and add the objects to the arraylist
                while (rs.next()) {

                    ToolBoxADT thisToolBox = toToolBox(rs);
                    toolBoxList.add(thisToolBox);
                }

                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return toolBoxList;
    }

    /**
     *
     * @param name
     * @return
     */
    @Override
    public ArrayList<ToolBoxADT> search(String name) {

        ArrayList<ToolBoxADT> toolBoxList = new ArrayList<ToolBoxADT>();

        try {
            try (Connection conn = getConnection()) {

                CallableStatement search = conn.prepareCall("call searchToolBoxByName(?)");

                search.setString(1, name);

                ResultSet rs = search.executeQuery();

                //Convert and add the objects to the arraylist
                while (rs.next()) {

                    ToolBoxADT thisToolBox = toToolBox(rs);
                    toolBoxList.add(thisToolBox);
                }

                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return toolBoxList;
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public ArrayList<ToolBoxADT> search(int id) {

        ArrayList<ToolBoxADT> toolBoxList = new ArrayList<ToolBoxADT>();

        try {
            try (Connection conn = getConnection()) {

                CallableStatement search = conn.prepareCall("call searchToolBoxByID(?)");

                search.setInt(1, id);

                ResultSet rs = search.executeQuery();

                //Convert and add the objects to the arraylist
                while (rs.next()) {

                    ToolBoxADT thisToolBox = toToolBox(rs);
                    toolBoxList.add(thisToolBox);
                }

                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return toolBoxList;
    }

    /**
     *
     * @param type
     * @return
     */
    @Override
    public ArrayList<ToolBoxADT> searchType(String type) {

        ArrayList<ToolBoxADT> toolBoxList = new ArrayList<ToolBoxADT>();

        try {
            try (Connection conn = getConnection()) {

                CallableStatement search = conn.prepareCall("call searchToolBoxByCategory(?)");

                search.setString(1, type);

                ResultSet rs = search.executeQuery();

                //Convert and add the objects to the arraylist
                while (rs.next()) {

                    ToolBoxADT thisToolBox = toToolBox(rs);
                    toolBoxList.add(thisToolBox);
                }

                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return toolBoxList;
    }

    /**
     *
     * @param id
     * @param name
     * @param description
     * @param category
     * @return
     */
    public ArrayList<ToolBoxADT> advancedSearch(int id, String name, String description, String category) {

        ArrayList<ToolBoxADT> toolBoxList = new ArrayList<ToolBoxADT>();

        try {
            try (Connection conn = getConnection()) {

                CallableStatement search = conn.prepareCall("call advancedSearchToolBox(?,?,?,?)");

                search.setInt(1, id);
                search.setString(2, name);
                search.setString(3, description);
                search.setString(4, category);

                ResultSet rs = search.executeQuery();

                //Convert and add the objects to the arraylist
                while (rs.next()) {

                    ToolBoxADT thisToolBox = toToolBox(rs);
                    toolBoxList.add(thisToolBox);
                }

                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return toolBoxList;
    }

    /**
     *
     * @param toolBoxID
     * @param toolID
     * @return
     */
    public boolean addTool(int toolBoxID, int toolID) {

        int complete = 0;

        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call addToolBoxTool(?,?)");

                st.setInt(1, toolBoxID);
                st.setInt(2, toolID);

                complete = st.executeUpdate();

                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return complete != 0;
    }

    /**
     *
     * @param toolBoxID
     * @param toolID
     * @return
     */
    public boolean deleteTool(int toolBoxID, int toolID) {

        int complete = 0;

        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call deleteToolFromToolBox(?,?)");

                st.setInt(1, toolBoxID);
                st.setInt(2, toolID);

                complete = st.executeUpdate();

                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return complete != 0;
    }

    /**
     *
     * @param id
     * @return
     */
    public ArrayList<Integer> getTools(int id) {

        ArrayList<Integer> toolIDLIst = new ArrayList<Integer>();

        try {
            try (Connection conn = getConnection()) {

                CallableStatement search = conn.prepareCall("call getToolBoxTools(?)");

                search.setInt(1, id);

                ResultSet rs = search.executeQuery();

                //Convert and add the objects to the arraylist
                while (rs.next()) {

                    toolIDLIst.add(rs.getInt(1));
                }

                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return toolIDLIst;
    }

    private ToolBoxADT toToolBox(ResultSet rs) throws SQLException {

        ToolBox newToolBox = new ToolBox();

        newToolBox.setId(rs.getInt(1));
        newToolBox.setName(rs.getString(2));
        newToolBox.setDescription(rs.getString(3));
        newToolBox.setCategory(rs.getString(4));

        return newToolBox;
    }
}
