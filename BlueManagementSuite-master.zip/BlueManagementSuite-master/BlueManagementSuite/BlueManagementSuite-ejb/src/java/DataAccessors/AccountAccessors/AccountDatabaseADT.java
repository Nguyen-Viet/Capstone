/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataAccessors.AccountAccessors;

import DataAccessors.DataBaseADT;
import DataEntities.AccountEntities.AccountADT;
import java.util.ArrayList;


/**
 *The default class that controls all accessors that deal with accounts
 * @author Graham Ermter
 */
public abstract class AccountDatabaseADT extends DataBaseADT {
    
    //Abstract methods for the specific stored proc for internal and external (employee/client)

    /**
     *
     * @param updatedAccount
     * @return
     */
    public abstract boolean update(AccountADT updatedAccount);

    /**
     *
     * @param id
     * @return
     */
    public abstract boolean isLocked(int id);

    /**
     *
     * @param id
     * @return
     */
    public abstract boolean toggleLocked(int id);

    /**
     *
     * @param id
     * @param type
     * @param username
     * @return
     */
    public abstract ArrayList advancedSearch(int id, String type, String username);
}
