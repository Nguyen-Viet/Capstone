/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataAccessors.AccountAccessors;

import DataAccessors.ClientAccessors.IndependentClientAccessor;
import DataEntities.AccountEntities.AccountADT;
import DataEntities.AccountEntities.ClientAccount;
import DataEntities.EmployeeEntities.EmployeeADT;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *Accessor object for getting ClientAccount objects from the database
 * @author Graham Ermter
 */
public final class ClientAccountAccessor extends AccountDatabaseADT{

    /**
     *
     * @param updatedAccount
     * @return
     */
    @Override
    public boolean update(AccountADT updatedAccount) {
                
        int complete = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stUpdate = conn.prepareCall("call updateClientAccount(?, ?, ?)");
                stUpdate.setInt(1, updatedAccount.getId());
                stUpdate.setString(2, updatedAccount.getUsername());
                stUpdate.setString(3, updatedAccount.getPassword());
                
                complete = stUpdate.executeUpdate();
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete==1;
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public boolean isLocked(int id) {
        
        int locked = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stGetLocked = conn.prepareCall("call getIsLockedClient(?)");
                stGetLocked.setInt(1, id);
                
                ResultSet rs = stGetLocked.executeQuery();
                rs.next();
                locked = rs.getInt(1);
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return locked == 1;
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public boolean toggleLocked(int id) {
        int locked = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stGetLocked = conn.prepareCall("call toggleIsLockedClient(?)");
                stGetLocked.setInt(1, id);
                
                ResultSet rs = stGetLocked.executeQuery();
                rs.next();
                locked = rs.getInt(1);
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return locked == 1;
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public ClientAccount get(int id) {
        
        ClientAccount getAccount = null;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stGet = conn.prepareCall("call searchCAByID(?)");
                
                stGet.setInt(1, id);
                
                ResultSet rs = stGet.executeQuery();
                
                //Convert the next row into an employee object
                rs.next();
                getAccount = toClientAccount(rs);
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return getAccount;
    }

    /**
     *
     * @return
     */
    @Override
    public ArrayList getAll() {
        
        ArrayList<ClientAccount> accList = new ArrayList<ClientAccount>();
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stGetAll = conn.prepareCall("call getAllClientAccounts()");
                
                ResultSet rs = stGetAll.executeQuery();
                
                //Convert the next row into an employee object
                while(rs.next()){
                    
                    ClientAccount nextAcc = toClientAccount(rs);
                    accList.add(nextAcc);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return accList;
    }

    /**
     *
     * @param name
     * @return
     */
    @Override
    public ArrayList search(String name) {
                
        ArrayList<ClientAccount> accList = new ArrayList<ClientAccount>();
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stSearchName = conn.prepareCall("call searchCAByUsername(?)");
                
                stSearchName.setString(1, name);
                
                ResultSet rs = stSearchName.executeQuery();
                
                //Convert the next row into an employee object
                while(rs.next()){
                    
                    ClientAccount nextAcc = toClientAccount(rs);
                    accList.add(nextAcc);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return accList;
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public ArrayList search(int id) {
                
        ArrayList<ClientAccount> accList = new ArrayList<ClientAccount>();
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stSearchID = conn.prepareCall("call searchCAByID(?)");
                
                stSearchID.setInt(1, id);
                
                ResultSet rs = stSearchID.executeQuery();
                
                //Convert the next row into an employee object
                while(rs.next()){
                    
                    ClientAccount nextAcc = toClientAccount(rs);
                    accList.add(nextAcc);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return accList;
    }

    /**
     *
     * @param type
     * @return
     */
    @Override
    public ArrayList searchType(String type) {
        
        ArrayList<ClientAccount> accList = new ArrayList<ClientAccount>();
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stSearchID = conn.prepareCall("call searchCAByType(?)");
                
                stSearchID.setString(1, type);
                
                ResultSet rs = stSearchID.executeQuery();
                
                //Convert the next row into an employee object
                while(rs.next()){
                    
                    ClientAccount nextAcc = toClientAccount(rs);
                    accList.add(nextAcc);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return accList;
    }

    /**
     *
     * @param id
     * @param type
     * @param username
     * @return
     */
    @Override
    public ArrayList<ClientAccount> advancedSearch(int id, String type, String username) {
        
         ArrayList<ClientAccount> accList = new ArrayList<ClientAccount>();
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stAdvSearch = conn.prepareCall("call advancedSearchClientAccount(?,?,?)");
                
                stAdvSearch.setInt(1, id);
                stAdvSearch.setString(2, type);
                stAdvSearch.setString(3, username);
                
                ResultSet rs = stAdvSearch.executeQuery();
                
                //Convert the next row into an employee object
                while(rs.next()){
                    
                    ClientAccount nextAcc = toClientAccount(rs);
                    accList.add(nextAcc);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return accList;
    }
    
    /**
     *
     * @param rs
     * @return
     * @throws SQLException
     */
    public ClientAccount toClientAccount(ResultSet rs) throws SQLException{
        
        ClientAccount newAcc = new ClientAccount();
        
        newAcc.setId(rs.getInt(1));
        newAcc.setUsername(rs.getString(2));
        newAcc.setPassword(rs.getString(3));
        newAcc.setIsLocked(rs.getInt(4)==1);
        
        return newAcc;
    }
    
    /**
     * This method is not used in this class, 
     * false is returned if use is attempted
     * @param id
     * @return false
     */
    @Override
    public boolean delete(int id) {      
        return false;
    }
    
}
