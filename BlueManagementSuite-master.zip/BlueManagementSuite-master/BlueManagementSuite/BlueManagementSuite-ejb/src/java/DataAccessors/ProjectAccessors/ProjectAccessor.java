/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataAccessors.ProjectAccessors;

import DataEntities.ProjectEntities.Project;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author Graham Ermter
 */
public final class ProjectAccessor extends ProjectDatabaseADT {
    
    /**
     * Creates a new project row in the project database. Note this does not
     * update other project tables such as Cost, Detail or Site. These need to
     * be created individually.
     * @param project_type
     * @param state
     * @param project_name
     * @param start_date
     * @param expected_completion
     * @param description
     * @param drawing
     * @param permit
     * @return 
     */
    public int createProject(String project_type, int state, String project_name, LocalDate start_date, LocalDate expected_completion, String description, boolean drawing, boolean permit){
        
        int project_id = -1;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call createProject(?,?,?,?,?,?,?,?)");
                
                st.setString(1,project_type);
                st.setInt(2,state);
                st.setString(3,project_name);
                st.setDate(4,Date.valueOf(start_date));
                st.setDate(5,Date.valueOf(expected_completion));
                st.setString(6,description);
                st.setInt(7,(drawing) ? 1 : 0);
                st.setInt(8,(permit) ? 1 : 0);
                
                ResultSet rs = st.executeQuery();
                rs.next();
                project_id = rs.getInt(1);
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return project_id;
    }
    
    /**
     * Updates an already existing project table. Note this does not update any
     * other project tables.
     * @param id
     * @param project_type
     * @param state
     * @param project_name
     * @param start_date
     * @param expected_completion
     * @param description
     * @param drawing
     * @param permit
     * @return 
     */
    public boolean updateProject(int id, String project_type, int state, String project_name, LocalDate start_date, LocalDate expected_completion, String description, boolean drawing, boolean permit){
                
        int complete = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call updateProject(?,?,?,?,?,?,?,?,?)");
                
                st.setInt(1, id);
                st.setString(2,project_type);
                st.setInt(3, state);
                st.setString(4,project_name);
                st.setDate(5,Date.valueOf(start_date));
                st.setDate(6,Date.valueOf(expected_completion));
                st.setString(7,description);
                st.setInt(8,(drawing) ? 1 : 0);
                st.setInt(9,(permit) ? 1 : 0);
                
                complete = st.executeUpdate();
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete==1;
    }
    
    /**
     *
     * @param id
     * @return
     */
    public boolean deleteProject(int id){
                
        int complete = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call deleteProjectByID(?)");
                
                st.setInt(1, id);
                
                complete = st.executeUpdate();
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete==1;
    }

    /**
     * Returns one project object with only basic project information. Info from
     * other tables need to be taken from those tables.
     * @param id
     * @return 
     */
    public Project getProject(int id) {
        
        Project project = null;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call searchProjectByID(?)");
                
                st.setInt(1, id);
                
                ResultSet rs = st.executeQuery();
                
                //Convert the next row into an object
                rs.next();
                project = toProject(rs);
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return project;
    }

    /**
     * Searches and returns partial project objects from the project table.
     * @param name
     * @return 
     */
    public ArrayList<Project> search(String name) {
                
        ArrayList<Project> list = new ArrayList<>();
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call searchProjectByName(?)");
                
                st.setString(1, name);
                
                ResultSet rs = st.executeQuery();
                
                while(rs.next()){
                    
                    Project thisProject = toProject(rs);
                    list.add(thisProject);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return list;
    }

    /**
     * Searches and returns partial project objects from the project table.
     * @param id
     * @return 
     */
    public ArrayList<Project> search(int id) {
                
        ArrayList<Project> list = new ArrayList<>();
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call searchProjectByID(?)");
                
                st.setInt(1, id);
                
                ResultSet rs = st.executeQuery();
                
                while(rs.next()){
                    
                    Project thisProject = toProject(rs);
                    list.add(thisProject);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return list;
    }

    /**
     * Searches and returns partial project objects from the project table.
     * @param type
     * @return 
     */
    public ArrayList<Project> searchType(String type) {
        
        ArrayList<Project> list = new ArrayList<>();
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call searchProjectByType(?)");
                
                st.setString(1,type);
                
                ResultSet rs = st.executeQuery();
                
                while(rs.next()){
                    
                    Project thisProject = toProject(rs);
                    list.add(thisProject);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return list;
    }

    /**
     * Searches using advanced values and returns partial project objects 
     * from the project table.
     * @param id
     * @param state
     * @param type
     * @param name
     * @param description
     * @param client_name
     * @param employee_name
     * @return 
     */
    public ArrayList<Project> advancedSearch(int id, int state, String type, String name, String description, String client_name, String employee_name){
        
        ArrayList<Project> list = new ArrayList<>();
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call advancedSearchProject(?,?,?,?,?,?,?)");
                
                st.setInt(1, id);
                st.setInt(2, state);
                st.setString(3, type);
                st.setString(4,name);
                st.setString(5,description);
                st.setString(6, client_name);
                st.setString(7, employee_name);
                
                ResultSet rs = st.executeQuery();
                
                while(rs.next()){
                    
                    Project thisProject = toProject(rs);
                    list.add(thisProject);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return list;
    }
    
    /**
     * This method takes in a result set and returns a completed project object.
     * Use this method when loading any SELECT * type statement from the database
     * @param rs
     * @return
     * @throws SQLException 
     */
    private Project toProject (ResultSet rs) throws SQLException{

        Project project = new Project();
        
        project.setId(rs.getInt(1));
        project.setProject_type(rs.getString(2));
        project.setState(rs.getInt(3));
        project.setProject_name(rs.getString(4));
        project.setDate_created(rs.getDate(5).toLocalDate());
        project.setStart_date(rs.getDate(6).toLocalDate());
        project.setExpected_completion(rs.getDate(7).toLocalDate());
        project.setDescription(rs.getString(8));
        project.setDrawing(rs.getInt(9) == 1);
        project.setPermit(rs.getInt(10) == 1);
        
        return project;
    }
    
    
/*******************************adds****************************************/    
    
    /**
     * Adds an assembly relationship to the project
     * @param project_id
     * @param id
     * @return 
     */
    public boolean addAssembly(int project_id, int id){
        
        int complete = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call addProjectAssembly(?,?)");
                
                st.setInt(1, project_id);
                st.setInt(2, id);

                complete = st.executeUpdate();
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete==1;
        
    }
    
    /**
     * Adds a client relationship to the project
     * @param project_id
     * @param id
     * @return 
     */
    public boolean addClient(int project_id, int id){
        
        int complete = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call addProjectClient(?,?)");
                
                st.setInt(1, project_id);
                st.setInt(2, id);

                complete = st.executeUpdate();
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete==1;    
    }
    
    /**
     * Adds an employee relationship to the project
     * @param project_id
     * @param id
     * @return 
     */
    public boolean addEmployee(int project_id, int id){
        
        int complete = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call addProjectEmployee(?,?)");
                
                st.setInt(1, project_id);
                st.setInt(2, id);

                complete = st.executeUpdate();
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete==1;        
    }
    
    /**
     * Adds a Toolbox relationship to the project
     * @param project_id
     * @param id
     * @return 
     */
    public boolean addToolbox(int project_id, int id){

        int complete = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call addProjectToolbox(?,?)");
                
                st.setInt(1, project_id);
                st.setInt(2, id);

                complete = st.executeUpdate();
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete==1;        
    }


/*******************************deletes****************************************/   
    
    /**
     * Removes an assembly relationship to the project
     * @param project_id
     * @param id
     * @return 
     */
    public boolean deleteAssembly(int project_id, int id){

        int complete = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call deleteProjectAssembly(?,?)");
                
                st.setInt(1, project_id);
                st.setInt(2, id);

                complete = st.executeUpdate();
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete==1;        
    }
   
    /**
     * Removes a client relationship from the project
     * @param project_id
     * @param id
     * @return 
     */
    public boolean deleteClient(int project_id, int id){
        
        int complete = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call deleteProjectClient(?,?)");
                
                st.setInt(1, project_id);
                st.setInt(2, id);

                complete = st.executeUpdate();
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete==1;  
    }
    
    /**
     * Removes an employee relationship from the project
     * @param project_id
     * @param id
     * @return 
     */
    public boolean deleteEmployee(int project_id, int id){
        
        int complete = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call deleteProjectEmployee(?,?)");
                
                st.setInt(1, project_id);
                st.setInt(2, id);

                complete = st.executeUpdate();
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete==1;  
    }
   
    /**
     * Removes a toolbox relationship from the project
     * @param project_id
     * @param id
     * @return 
     */
    public boolean deleteToolbox(int project_id, int id){
        
        int complete = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call deleteProjectToolbox(?,?)");
                
                st.setInt(1, project_id);
                st.setInt(2, id);

                complete = st.executeUpdate();
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete==1;  
    }

/*******************************gets****************************************/    
    
    /**
     * Returns a list of Assembly IDs associated with the provided project
     * @param project_id
     * @return 
     */
    public ArrayList<Integer> getAssembly(int project_id){
        
        ArrayList<Integer> list = new ArrayList();
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call getProjectAssembly(?)");
                
                st.setInt(1, project_id);

                ResultSet rs = st.executeQuery();
                
                while(rs.next()){
                    
                    list.add(rs.getInt(1));
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return list; 
    }
    
    /**
     * Returns a list of Client IDs associated with the provided project
     * @param project_id
     * @return 
     */
    public ArrayList<Integer> getClient(int project_id){
        
        ArrayList<Integer> list = new ArrayList();
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call getProjectClient(?)");
                
                st.setInt(1, project_id);

                ResultSet rs = st.executeQuery();
                
                while(rs.next()){
                    
                    list.add(rs.getInt(1));
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return list; 
        
    }
    
    /**
     * Returns a list of employee IDs associated with the provided project
     * @param project_id
     * @param id
     * @return 
     */
    public ArrayList<Integer> getEmployee(int project_id){
        
        ArrayList<Integer> list = new ArrayList();
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call getProjectEmployee(?)");
                
                st.setInt(1, project_id);

                ResultSet rs = st.executeQuery();
                
                while(rs.next()){
                    
                    list.add(rs.getInt(1));
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return list;         
    }
    
    /**
     * returns a list of toolbox IDs associated with the provided project
     * @param project_id
     * @param id
     * @return 
     */
    public ArrayList<Integer> getToolbox(int project_id){
        
        ArrayList<Integer> list = new ArrayList();
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call getProjectToolbox(?)");
                
                st.setInt(1, project_id);

                ResultSet rs = st.executeQuery();
                
                while(rs.next()){
                    
                    list.add(rs.getInt(1));
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return list;         
    }
  
}
