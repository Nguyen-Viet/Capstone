/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataAccessors.ProjectAccessors;

import DataEntities.ProjectEntities.Project;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Used for doing CRU operations on the projectSite table
 * @author Graham Ermter
 */
public final class ProjectSiteAccessor extends ProjectDatabaseADT{
    
    /**
     * Creates a project site table row for the provided project id
     * @param project_id
     * @param site_name
     * @param address
     * @param parking
     * @param code
     * @param garbage
     * @param first_aid
     * @param bathroom
     * @return 
     */
    public boolean createProjectSite(int project_id, String site_name, String address, String parking, String code, boolean garbage, boolean first_aid, boolean bathroom){ 
    
        int complete = 0;
        
        try {
            try (Connection conn = getConnection()){
                CallableStatement st = conn.prepareCall("call createProjectSite(?,?,?,?,?,?,?,?)");
                st.setInt(1, project_id);
                st.setString(2, site_name);
                st.setString(3, address);
                st.setString(4, parking);
                st.setString(5, code);
                st.setInt(6, (garbage) ? 1 : 0); 
                st.setInt(7, (first_aid) ? 1 : 0);
                st.setInt(8, (bathroom) ? 1 : 0);                
               
                complete = st.executeUpdate();
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete==1;
    }
    
    /**
     * Updates a current projects values based on the id and values provided
     * @param project_id
     * @param site_name
     * @param address
     * @param parking
     * @param code
     * @param garbage
     * @param first_aid
     * @param bathroom
     * @return 
     */
    public boolean updateProjectSite(int project_id, String site_name, String address, String parking, String code, boolean garbage, boolean first_aid, boolean bathroom){ 
    
        int complete = 0;
        
        try {
            try (Connection conn = getConnection()){
                CallableStatement st = conn.prepareCall("call updateProjectSite(?,?,?,?,?,?,?,?)");
                st.setInt(1, project_id);
                st.setString(2, site_name);
                st.setString(3, address);
                st.setString(4, parking);
                st.setString(5, code);
                st.setInt(6, (garbage) ? 1 : 0); 
                st.setInt(7, (first_aid) ? 1 : 0);
                st.setInt(8, (bathroom) ? 1 : 0);                
               
                complete = st.executeUpdate();
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete==1;
    }
    
    /**
     * Takes in a project and updates it with the values in ProjectSite table
     * Then returnes the updated project.
     * @param project
     * @return 
     */
    public Project getProjectSite(Project project){
        
        try {
            try (Connection conn = getConnection()){
                CallableStatement st = conn.prepareCall("call getProjectSite(?)");
                st.setInt(1, project.getId());               
               
                ResultSet rs =  st.executeQuery();
                conn.close();
                
                rs.next();
                
                //Add values to arrayList
                project.setSite_name(rs.getString(2));
                project.setAddress(rs.getString(3));
                project.setParking(rs.getString(4));
                project.setCode(rs.getString(5));
                project.setGarbage(rs.getInt(6) == 1);
                project.setFirst_aid(rs.getInt(7) == 1);
                project.setBathroom(rs.getInt(8) == 1);    
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return project;    
    }
}
