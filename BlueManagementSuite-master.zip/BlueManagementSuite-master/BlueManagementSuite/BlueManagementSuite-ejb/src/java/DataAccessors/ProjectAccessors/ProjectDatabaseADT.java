/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataAccessors.ProjectAccessors;

import DataAccessors.DataBaseADT;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 *
 * @author Graham Ermter
 */
public class ProjectDatabaseADT {
    
    /**
     *
     * @return
     */
    static final public Connection getConnection(){
        Connection connection = null;
        try {
            DataSource ds = (DataSource) (new InitialContext().lookup("jdbc/bluePool"));
            connection = ds.getConnection();
        } catch (NamingException | SQLException ex) {
            Logger.getLogger(DataBaseADT.class.getName()).log(Level.SEVERE, null, ex);
        }
        return connection;
    }
    
    /**
     *
     * @param conn
     */
    static final public void closeConnection(Connection conn){
        
        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(DataBaseADT.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
}