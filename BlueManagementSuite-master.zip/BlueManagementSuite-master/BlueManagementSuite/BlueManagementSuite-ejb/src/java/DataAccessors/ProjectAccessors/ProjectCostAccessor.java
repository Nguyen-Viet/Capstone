/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataAccessors.ProjectAccessors;

import static DataAccessors.ProjectAccessors.ProjectDatabaseADT.getConnection;
import DataEntities.ProjectEntities.Project;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Graham Ermter
 */
public class ProjectCostAccessor {
    
        /**
         * Creates a cost table for the with the following values for the provided project
         * @param project_id
         * @param client_budget
         * @param project_budget
         * @param current_cost
         * @param estimated_cost
         * @param final_cost
         * @return 
         */
        public boolean createProjectCost(int project_id, double client_budget, double project_budget, double current_cost, double estimated_cost, double final_cost){    
        int complete = 0;
        
        try {
            try (Connection conn = getConnection()){
                CallableStatement st = conn.prepareCall("call createProjectCost(?,?,?,?,?,?)");
                st.setInt(1, project_id);
                st.setDouble(2,client_budget);
                st.setDouble(3,project_budget);
                st.setDouble(4,estimated_cost);
                st.setDouble(5,final_cost);
           
                complete = st.executeUpdate();
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete==1;
    }
    
    /**
     * Updates the cost values for the provided project
     * @param project_id
     * @param client_budget
     * @param project_budget
     * @param current_cost
     * @param estimated_cost
     * @param final_cost
     * @return 
     */
    public boolean updateProjectCost(int project_id, double client_budget, double project_budget, double current_cost, double estimated_cost, double final_cost){    
        int complete = 0;
        
        try {
            try (Connection conn = getConnection()){
                CallableStatement st = conn.prepareCall("call updateProjectCost(?,?,?,?,?,?)");
                st.setInt(1, project_id);
                st.setDouble(2,client_budget);
                st.setDouble(3,project_budget);
                st.setDouble(4,estimated_cost);
                st.setDouble(5,final_cost);               
               
                complete = st.executeUpdate();
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete==1;
    }
    
    /**
     * Adds project cost values into the provided project
     * @param project
     * @return 
     */
    public Project getProjectCost(Project project){
        
        try {
            try (Connection conn = getConnection()){
                CallableStatement st = conn.prepareCall("call getProjectCost(?)");
                st.setInt(1, project.getId());               
               
                ResultSet rs =  st.executeQuery();
                conn.close();
                
                rs.next();
                
                //Add values to arrayList
                project.setClient_budget(rs.getDouble(2));
                project.setProject_budget(rs.getDouble(3));
                project.setCurrent_cost(rs.getDouble(4));
                project.setEstimated_cost(rs.getDouble(5));
                project.setFinal_cost(rs.getDouble(6));
                
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return project;    
    }
    
}
