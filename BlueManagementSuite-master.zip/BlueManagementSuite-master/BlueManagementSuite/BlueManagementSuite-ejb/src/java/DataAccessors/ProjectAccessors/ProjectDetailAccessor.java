/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataAccessors.ProjectAccessors;

import static DataAccessors.ProjectAccessors.ProjectDatabaseADT.getConnection;
import DataEntities.ProjectEntities.Project;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *Used for doing CRU operations on the projectDetail table
 * @author Graham Ermter
 */
public final class ProjectDetailAccessor extends ProjectDatabaseADT{
    
    /**
     * adds project detail values for the following project
     * @param project_id
     * @param ceiling_height
     * @param site_voltage
     * @param bond_wiring
     * @param trenching
     * @param hazardous_areas
     * @param insulated_ceiling
     * @param crawl_space
     * @return 
     */
    public boolean createProjectDetail(int project_id, double ceiling_height, double site_voltage, boolean bond_wiring, boolean trenching, boolean hazardous_areas, boolean insulated_ceiling, boolean crawl_space){ 
    
        int complete = 0;
        
        try {
            try (Connection conn = getConnection()){
                CallableStatement st = conn.prepareCall("call createProjectDetail(?,?,?,?,?,?,?,?)");
                st.setInt(1, project_id);
                st.setDouble(2,ceiling_height);
                st.setDouble(3,site_voltage);
                st.setInt(4, (bond_wiring) ? 1 : 0);
                st.setInt(5, (trenching) ? 1 : 0);
                st.setInt(6, (hazardous_areas) ? 1 : 0); 
                st.setInt(7, (insulated_ceiling) ? 1 : 0);
                st.setInt(8, (crawl_space) ? 1 : 0);                
               
                complete = st.executeUpdate();
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete==1;
    }
    
    /**
     * Updates project details for the following project
     * @param project_id
     * @param ceiling_height
     * @param site_voltage
     * @param bond_wiring
     * @param trenching
     * @param hazardous_areas
     * @param insulated_ceiling
     * @param crawl_space
     * @return 
     */
    public boolean updateProjectDetail(int project_id, double ceiling_height, double site_voltage, boolean bond_wiring, boolean trenching, boolean hazardous_areas, boolean insulated_ceiling, boolean crawl_space){ 
    
        int complete = 0;
        
        try {
            try (Connection conn = getConnection()){
                CallableStatement st = conn.prepareCall("call updateProjectDetail(?,?,?,?,?,?,?,?)");
                st.setInt(1, project_id);
                st.setDouble(2,ceiling_height);
                st.setDouble(3,site_voltage);
                st.setInt(4, (bond_wiring) ? 1 : 0);
                st.setInt(5, (trenching) ? 1 : 0);
                st.setInt(6, (hazardous_areas) ? 1 : 0); 
                st.setInt(7, (insulated_ceiling) ? 1 : 0);
                st.setInt(8, (crawl_space) ? 1 : 0);                 
               
                complete = st.executeUpdate();
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete==1;
    }
    
    /**
     * Inserts project details into the provided project
     * @param project
     * @return 
     */
    public Project getProjectDetail(Project project){
        
        try {
            try (Connection conn = getConnection()){
                CallableStatement st = conn.prepareCall("call getProjectDetail(?)");
                st.setInt(1, project.getId());               
               
                ResultSet rs =  st.executeQuery();
                conn.close();
                
                rs.next();
                
                //Add values to arrayList
                project.setCeiling_height(rs.getDouble(2));
                project.setSite_voltage(rs.getDouble(3));
                project.setBond_wiring(rs.getInt(4) == 1);
                project.setTrenching(rs.getInt(5) == 1);
                project.setHazardous_areas(rs.getInt(6) == 1);
                project.setInsulated_ceiling(rs.getInt(7) == 1);
                project.setCrawl_space(rs.getInt(8) == 1);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return project;    
    }
    
}