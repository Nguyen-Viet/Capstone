/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataAccessors.ToolAccessors;

import DataAccessors.DataBaseADT;
import DataEntities.ToolEntities.Tool;
import DataEntities.ToolEntities.ToolADT;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Graham Ermter
 */
public class ToolDatabaseADT extends DataBaseADT {

    /**
     *
     * @param addTool
     * @return
     */
    public int addTool(ToolADT addTool){
        
        int newToolID = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stGet = conn.prepareCall("call createTool(?,?,?,?)");
                
                stGet.setString(1, addTool.getName());
                stGet.setString(2, addTool.getDescription());
                stGet.setInt(3, addTool.getQuantity());
                stGet.setString(4, addTool.getCategory());
                
                ResultSet rs = stGet.executeQuery();
                
                rs.next();
                newToolID = rs.getInt(1);
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return newToolID;
    }
    
    /**
     *
     * @param upTool
     * @return
     */
    public boolean updateTool(ToolADT upTool){
        
        int complete = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stGet = conn.prepareCall("call updateTool(?,?,?,?,?)");
                
                stGet.setInt(1, upTool.getId());
                stGet.setString(2, upTool.getName());
                stGet.setString(3, upTool.getDescription());
                stGet.setInt(4, upTool.getQuantity());
                stGet.setString(5, upTool.getCategory());
                
                System.out.println(upTool.getId());
                System.out.println(upTool.getName());
                System.out.println(upTool.getDescription());
                System.out.println(upTool.getQuantity());
                System.out.println(upTool.getCategory());
                
                complete = stGet.executeUpdate();
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete != 0;
    }
    
    /**
     *
     * @param id
     * @return
     */
    @Override
    public ToolADT get(int id) {
        
        ToolADT getTool = null;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stGet = conn.prepareCall("call searchToolByID(?)");
                
                stGet.setInt(1, id);
                
                ResultSet rs = stGet.executeQuery();
                
                //Convert the next row into an object
                rs.next();
                getTool = toTool(rs);
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return getTool;
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public boolean delete(int id) {
        
        int complete = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement stGet = conn.prepareCall("call deleteToolByID(?)");
                
                stGet.setInt(1, id);
                
                complete = stGet.executeUpdate();
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete != 0;
    }
    
    /**
     *
     * @return
     */
    @Override
    public ArrayList<ToolADT> getAll() {
        
        ArrayList<ToolADT> toolList = new ArrayList<ToolADT>();
        
        try {
            try (Connection conn = getConnection()) {
                
                CallableStatement stGetAll = conn.prepareCall("call getAllTools()");
                
                ResultSet rs = stGetAll.executeQuery();
                
                //Convert and add the objects to the arraylist
                while(rs.next()){
                
                    ToolADT thisTool = toTool(rs);
                    toolList.add(thisTool);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return toolList;
    }

    /**
     *
     * @param name
     * @return
     */
    @Override
    public ArrayList<ToolADT> search(String name) {
        
        ArrayList<ToolADT> toolList = new ArrayList<ToolADT>();
        
        try {
            try (Connection conn = getConnection()) {
                
                CallableStatement search = conn.prepareCall("call searchToolByName(?)");
                
                search.setString(1, name);
                
                ResultSet rs = search.executeQuery();
                
                //Convert and add the objects to the arraylist
                while(rs.next()){
                
                    ToolADT thisTool = toTool(rs);
                    toolList.add(thisTool);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return toolList;
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public ArrayList<ToolADT> search(int id) {
        
        ArrayList<ToolADT> toolList = new ArrayList<ToolADT>();
        
        try {
            try (Connection conn = getConnection()) {
                
                CallableStatement search = conn.prepareCall("call searchToolByID(?)");
                
                search.setInt(1, id);
                
                ResultSet rs = search.executeQuery();
                
                //Convert and add the objects to the arraylist
                while(rs.next()){
                
                    ToolADT thisTool = toTool(rs);
                    toolList.add(thisTool);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return toolList;
    }

    /**
     *
     * @param type
     * @return
     */
    @Override
    public ArrayList<ToolADT> searchType(String type) {
        
        ArrayList<ToolADT> toolList = new ArrayList<ToolADT>();
        
        try {
            try (Connection conn = getConnection()) {
                
                CallableStatement search = conn.prepareCall("call searchToolByCategory(?)");
                
                search.setString(1, type);
                
                ResultSet rs = search.executeQuery();
                
                //Convert and add the objects to the arraylist
                while(rs.next()){
                
                    ToolADT thisTool = toTool(rs);
                    toolList.add(thisTool);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return toolList;
    }
    
    /**
     *
     * @return
     */
    public ArrayList<String> getCategories(){
        ArrayList<String> categories = new ArrayList<String>();
        
        try {
            try (Connection conn = getConnection()) {
                
                CallableStatement getCategories = conn.prepareCall("call getUniqueToolCategory()");
                ResultSet rs = getCategories.executeQuery();
                
                //Convert and add the objects to the arraylist
                while(rs.next()){
                    categories.add(rs.getString(1));
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return categories;
    }
    
    /**
     *
     * @param id
     * @param name
     * @param category
     * @param clientName
     * @param description
     * @param lowPrice
     * @param highPrice
     * @return
     */
    public ArrayList<ToolADT> advancedSearch(int id, String name, String category, String clientName, String description, double lowPrice, double highPrice){
        
        ArrayList<ToolADT> toolList = new ArrayList<ToolADT>();
        
        try {
            try (Connection conn = getConnection()) {
                
                CallableStatement search = conn.prepareCall("call advancedSearchClientTool(?,?,?,?,?,?,?)");
                
                search.setInt(1, id);
                search.setString(2, name);
                search.setString(3, category);
                search.setString(4, clientName);
                search.setString(5, description);
                search.setDouble(6, lowPrice);
                search.setDouble(7, highPrice);
                
                ResultSet rs = search.executeQuery();
                
                //Convert and add the objects to the arraylist
                while(rs.next()){
                    
                    ToolADT thisTool = toTool(rs);
                    toolList.add(thisTool);
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return toolList;
    }
    
    /**
     *
     * @param clientID
     * @param toolID
     * @param price
     * @return
     */
    public boolean addClientTool(int clientID, int toolID, double price){
        
        int complete = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call addClientTool(?,?,?)");
                
                st.setInt(1, clientID);
                st.setInt(2, toolID);
                st.setDouble(3, price);
                
                complete = st.executeUpdate();
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete != 0;
        
    }
    
    /**
     *
     * @param clientID
     * @param toolID
     * @param price
     * @return
     */
    public boolean updateClientTool(int clientID, int toolID, double price){
        int complete = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call updateClientTool(?,?,?)");
                
                st.setInt(1, clientID);
                st.setInt(2, toolID);
                st.setDouble(3, price);
                
                complete = st.executeUpdate();
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete != 0;
    }
    
    /**
     *
     * @param clientID
     * @param toolID
     * @return
     */
    public boolean deleteClientTool(int clientID, int toolID){
                int complete = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call deleteClientTool(?,?)");
                
                st.setInt(1, clientID);
                st.setInt(2, toolID);
                
                complete = st.executeUpdate();
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return complete != 0;
    }
    
    /**
     *
     * @param toolID
     * @return
     */
    public ArrayList<Integer> getClientsByTool(int toolID){
        
        ArrayList<Integer> clientIDList = new ArrayList();
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call getClientsByTool(?)");
                
                st.setInt(1, toolID);
                
                ResultSet rs = st.executeQuery();
                
                while(rs.next()){
                 
                    clientIDList.add(rs.getInt(1));
                }
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return clientIDList;
    }
    
    /**
     *
     * @param clientID
     * @param toolID
     * @return
     */
    public double getToolPrice(int clientID, int toolID){

        double toolPrice = 0;
        
        try {
            try (Connection conn = getConnection()) {
                CallableStatement st = conn.prepareCall("call getToolPrice(?,?)");
                
                st.setInt(1, clientID);
                st.setInt(2, toolID);
                
                ResultSet rs = st.executeQuery();
                rs.next();
                toolPrice = rs.getDouble(1);
                
                conn.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        return toolPrice;   
    }
    
    
    private ToolADT toTool(ResultSet rs) throws SQLException{
        
        Tool newTool = new Tool();
        
        newTool.setId(rs.getInt(1));
        newTool.setName(rs.getString(2));
        newTool.setDescription(rs.getString(3));
        newTool.setQuantity(rs.getInt(4));
        newTool.setCategory(rs.getString(5));
        
        return newTool;
    }
}
