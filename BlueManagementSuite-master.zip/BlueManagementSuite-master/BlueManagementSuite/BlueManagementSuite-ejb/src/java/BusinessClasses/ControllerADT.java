/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessClasses;

import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author Graham Desktop
 */
public abstract class ControllerADT {
    
    /**
     *
     * @param name
     * @return
     */
    public abstract ArrayList search(String name);

    /**
     *
     * @param id
     * @return
     */
    public abstract ArrayList search(int id);

    /**
     *
     * @param type
     * @return
     */
    public abstract ArrayList searchType(String type);

    /**
     *
     * @return
     */
    public abstract ArrayList getAll();
}
