/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessClasses.AccountControllers;

import BusinessClasses.ControllerADT;
import DataEntities.AccountEntities.AccountADT;
import java.util.ArrayList;

/**
 * 
 * @author Graham Ermter
 */
public abstract class AccountControllerADT extends ControllerADT{

    /**
     *
     * @param updatedAccount
     * @return
     */
    public abstract boolean update(AccountADT updatedAccount);

    /**
     *
     * @param id
     * @return
     */
    public abstract boolean isLocked(int id);

    /**
     *
     * @param id
     * @return
     */
    public abstract boolean toggleLocked(int id);

    /**
     *
     * @param id
     * @param type
     * @param username
     * @return
     */
    public abstract ArrayList advancedSearch(int id, String type, String username);
}
