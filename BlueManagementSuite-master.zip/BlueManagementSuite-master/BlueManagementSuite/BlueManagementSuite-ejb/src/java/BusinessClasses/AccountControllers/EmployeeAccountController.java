/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessClasses.AccountControllers;

import BusinessClasses.EmployeeControllers.AdminController;
import DataAccessors.AccountAccessors.EmployeeAccountAccessor;
import DataEntities.AccountEntities.AccountADT;
import DataEntities.AccountEntities.EmployeeAccount;
import java.util.ArrayList;

/**
 *
 * @author Graham Ermter
 */
public final class EmployeeAccountController extends AccountControllerADT{

    private final EmployeeAccountAccessor accessor = new EmployeeAccountAccessor();
    
    /**
     *
     * @param id
     * @return
     */
    public EmployeeAccount get(int id){
        
        //Get account
        EmployeeAccount newAcc = accessor.get(id);
        
        //Add employee to account
        newAcc = addUser(newAcc);
       
        return newAcc;
    }
    
    /**
     *
     * @param updatedAccount
     * @return
     */
    @Override
    public boolean update(AccountADT updatedAccount) {
        
        return accessor.update(updatedAccount);
        
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public boolean isLocked(int id) {
        
        return accessor.isLocked(id);
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public boolean toggleLocked(int id) {
        
        return accessor.toggleLocked(id);
    }

    /**
     *
     * @param id
     * @param type
     * @param username
     * @return
     */
    @Override
    public ArrayList advancedSearch(int id, String type, String username) {
        
        ArrayList<EmployeeAccount> searchList = accessor.advancedSearch(id, type, username);
        searchList = addUserToArrayList(searchList);
        return searchList;
    }

    /**
     *
     * @param name
     * @return
     */
    @Override
    public ArrayList search(String name) {
        
        ArrayList<EmployeeAccount> searchList = accessor.search(name);
        searchList = addUserToArrayList(searchList);
        return searchList;
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public ArrayList search(int id) {
       
        ArrayList<EmployeeAccount> searchList = accessor.search(id);
        searchList = addUserToArrayList(searchList);
        return searchList;
    }

    /**
     *
     * @param type
     * @return
     */
    @Override
    public ArrayList searchType(String type) {
        
        ArrayList<EmployeeAccount> searchList = accessor.searchType(type);
        searchList = addUserToArrayList(searchList);
        return searchList;
    }

    /**
     *
     * @return
     */
    @Override
    public ArrayList getAll() {
       
        ArrayList<EmployeeAccount> searchList = accessor.getAll();
        searchList = addUserToArrayList(searchList);
        return searchList;
    }
    
    private EmployeeAccount addUser(EmployeeAccount thisAcc){
        
        AdminController AC = new AdminController();

        thisAcc.setUser(AC.getEmployee(thisAcc.getId()));
        
        return thisAcc;
    }
    
    private ArrayList<EmployeeAccount> addUserToArrayList(ArrayList<EmployeeAccount> thisList){
        
        AdminController AC = new AdminController();
        
        //Add the users to this list
        for(int i = 0; i < thisList.size(); i++){
        
            EmployeeAccount thisAcc = thisList.get(i);
            thisAcc.setUser(AC.getEmployee(thisAcc.getId()));
        }
        
        return thisList;
    }
}
