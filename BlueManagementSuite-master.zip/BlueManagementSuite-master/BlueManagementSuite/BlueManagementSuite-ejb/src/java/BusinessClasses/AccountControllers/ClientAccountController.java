/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessClasses.AccountControllers;

import BusinessClasses.ClientControllers.IndependentClientController;
import DataAccessors.AccountAccessors.ClientAccountAccessor;
import DataEntities.AccountEntities.AccountADT;
import DataEntities.AccountEntities.ClientAccount;
import DataEntities.AccountEntities.EmployeeAccount;
import java.util.ArrayList;

/**
 *
 * @author Graham Ermter
 */
public final class ClientAccountController extends AccountControllerADT{

    private final ClientAccountAccessor accessor = new ClientAccountAccessor();
    
    /**
     *
     * @param id
     * @return
     */
    public ClientAccount get(int id){
        
        //Get account
        ClientAccount newAcc = accessor.get(id);
        
        //Add client to account
        newAcc = addUser(newAcc);
       
        return newAcc;
    }
    
    /**
     *
     * @param updatedAccount
     * @return
     */
    @Override
    public boolean update(AccountADT updatedAccount) {
        
        return accessor.update(updatedAccount);
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public boolean isLocked(int id) {
        
        return accessor.isLocked(id);
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public boolean toggleLocked(int id) {
        
        return accessor.toggleLocked(id);
    }

    /**
     *
     * @param id
     * @param type
     * @param username
     * @return
     */
    @Override
    public ArrayList advancedSearch(int id, String type, String username) {
        
        ArrayList<ClientAccount> searchList = accessor.advancedSearch(id, type, username);
        searchList = addUserToArrayList(searchList);
        return searchList;
    }

    /**
     *
     * @param name
     * @return
     */
    @Override
    public ArrayList search(String name) {
        
        ArrayList<ClientAccount> searchList = accessor.search(name);
        searchList = addUserToArrayList(searchList);
        return searchList;
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public ArrayList search(int id) {
       
        ArrayList<ClientAccount> searchList = accessor.search(id);
        searchList = addUserToArrayList(searchList);
        return searchList;
    }

    /**
     *
     * @param type
     * @return
     */
    @Override
    public ArrayList searchType(String type) {
        
        ArrayList<ClientAccount> searchList = accessor.searchType(type);
        searchList = addUserToArrayList(searchList);
        return searchList;
    }

    /**
     *
     * @return
     */
    @Override
    public ArrayList getAll() {
       
        ArrayList<ClientAccount> searchList = accessor.getAll();
        searchList = addUserToArrayList(searchList);
        return searchList;
    }
    
    private ClientAccount addUser(ClientAccount thisAcc){
        
        IndependentClientController ICC = new IndependentClientController();

        thisAcc.setUser(ICC.getClient(thisAcc.getId()));
        
        return thisAcc;
    }
    
    private ArrayList<ClientAccount> addUserToArrayList(ArrayList<ClientAccount> thisList){
        
        IndependentClientController ICC = new IndependentClientController();
        
        //Add the users to this list
        for(int i = 0; i < thisList.size(); i++){
        
            ClientAccount thisAcc = thisList.get(i);
            thisAcc.setUser(ICC.getClient(thisAcc.getId()));
        }
        
        return thisList;
    }
}
