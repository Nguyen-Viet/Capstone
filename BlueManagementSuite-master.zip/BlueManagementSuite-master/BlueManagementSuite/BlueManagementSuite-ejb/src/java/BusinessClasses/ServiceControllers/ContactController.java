/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessClasses.ServiceControllers;

import DataAccessors.ServiceAccessors.ContactDatabaseAccessor;
import DataEntities.ServiceEntities.Contact;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Graham Desktop
 */
public final class ContactController {
    
    ContactDatabaseAccessor accessor = new ContactDatabaseAccessor();
    
    /**
     *
     */
    public ContactController(){
    
    }   
    
     /**
     * 
     * @param id
     * @return Contact
     * Returns one Contact from the provided values.
     */
    public Contact getContact(int id){
                
        return accessor.get(id);
    }
    
    /**
     * 
     * @param toAdd
     * @return boolean
     * adds a contact to the database and returns if the operation 
     * was successful or not.
     */
    public int addContact(Contact toAdd){
        
        int newID = -1;
        
        try {
            newID = accessor.addContact(toAdd);
            
        } catch (SQLException ex) {
            
            Logger.getLogger(ContactController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return newID;
    }
    
    /**
     * 
     * @param id
     * @return boolean
     * deletes a contact based on id and returns whether or not the operation
     * was successful or not.
     */
    public boolean deleteContact(int id){
        
        boolean success = accessor.delete(id);
        
        return success;
    }
    
    /**
     * 
     * @param toUpdate
     * @return boolean
     * updates a contact and returns if it worked or not
     */
    public final boolean updateContact(Contact toUpdate){
        
        boolean success;
        
        try {
            success = accessor.updateContact(toUpdate);
            
        } catch (SQLException ex) {
            
            success = false;
            Logger.getLogger(ContactController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return success;
    }
    
    /**
     *
     * @return
     */
    public ArrayList<Contact> getAll(){
        
        ArrayList<Contact> conList = accessor.getAll();
        
        return conList;
    }
    
    /**
     *
     * @param name
     * @return
     */
    public ArrayList<Contact> search(String name){
        
        ArrayList<Contact> searchData = accessor.search(name);
        
        return searchData;
    }
    
    /**
     *
     * @param id
     * @return
     */
    public ArrayList<Contact> search(int id){
        
        ArrayList<Contact> searchData = accessor.search(id);
        
        return searchData;
    }
    
    /**
     *
     * @param id
     * @return
     */
    public boolean delete(int id){
        
        return accessor.delete(id);
    }
    
    /**
     *
     * @param id
     * @return
     */
    public final ArrayList<Contact> getContactsByClient(int id){
        
        ArrayList<Contact> conList = accessor.getContactsByClient(id);
        
        return conList;
    }
    
    /**
     *
     * @param id
     * @return
     */
    public final ArrayList<Contact> getContactsByEmployee(int id){
        
        ArrayList<Contact> conList = accessor.getContactsByEmployee(id);
        
        return conList;
    }
}