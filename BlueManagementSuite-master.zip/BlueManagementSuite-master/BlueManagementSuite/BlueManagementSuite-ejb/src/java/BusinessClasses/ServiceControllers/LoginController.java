/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessClasses.ServiceControllers;

import BusinessClasses.AccountControllers.ClientAccountController;
import BusinessClasses.AccountControllers.EmployeeAccountController;
import BusinessClasses.EmployeeControllers.AdminController;
import DataAccessors.ServiceAccessors.LoginAccessor;
import DataEntities.AccountEntities.AccountADT;
import DataEntities.AccountEntities.ClientAccount;
import DataEntities.AccountEntities.EmployeeAccount;

/**
 * Controls all login functions and returns account objects or null
 * @author Graham Ermter
 */
public class LoginController {
    
    private final LoginAccessor accessor = new LoginAccessor();
    
    /**
     * Method searches for an employeeAccount, or a clientAccount, if either was
     * found, the account object will be constructed and returned. If not null
     * will be returned.
     * @param username
     * @param password
     * @return AccountADT
     */
    public final AccountADT validate(String username, String password){
        
        int accountID;
        
        //Test employee account id
        accountID = accessor.validateEmployee(username, password);
        
        //If an employee id was found
        if(accountID != 0){
            
            EmployeeAccountController EAC = new EmployeeAccountController();
            EmployeeAccount empAcc = EAC.get(accountID);
            
            return empAcc;
            
        } 
        else {
            
            //Test for client account
            accountID = accessor.validateClient(username, password);
            
            //If client account was found
            if(accountID != 0){
            
                ClientAccountController CAC = new ClientAccountController();
                ClientAccount clientAcc = CAC.get(accountID);
                
                return clientAcc;
                
            } 
            else {
                
                //If nothing was found, return null
                return null;
            }
        }  
    }
    
}
