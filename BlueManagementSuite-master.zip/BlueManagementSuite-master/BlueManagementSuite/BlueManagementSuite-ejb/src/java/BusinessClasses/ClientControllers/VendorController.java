/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessClasses.ClientControllers;

import DataAccessors.ClientAccessors.VendorAccessor;
import DataEntities.ClientEntities.ClientADT;
import java.sql.Date;
import java.sql.ResultSet;

/**
 *
 * @author Graham Ermter
 */
public final class VendorController extends ClientControllerADT {
    
    /**
     *
     */
    public VendorController(){
        
        accessor = new VendorAccessor();
    }
}
