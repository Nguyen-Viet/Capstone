/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessClasses.ClientControllers;

import BusinessClasses.ControllerADT;
import DataAccessors.ClientAccessors.ClientDatabaseADT;
import DataEntities.ClientEntities.*;
import java.util.ArrayList;

/**
 *
 * @author Graham Ermter
 */
public abstract class ClientControllerADT extends ControllerADT{
    
    ClientDatabaseADT accessor;
    
    
    /**
     * 
     * @param name
     * @return ArrayList searchData
     * returns the searched information based on a String name
     */
    @Override
    public ArrayList<ClientADT> search(String name) {
        
        ArrayList<ClientADT> searchData = accessor.search(name);
        
        return searchData;
    }

    /**
     * 
     * @param id
     * @return ArrayList searchData
     * returns the searched information based on an Integer id
     */
    @Override
    public ArrayList<ClientADT> search(int id) {
        
        ArrayList<ClientADT> searchData = accessor.search(id);
        
        return searchData;
    }
    
    /**
     * 
     * @return ArrayList allData
     * returns a resultSet populated with all client data
     */
    @Override
    public ArrayList<ClientADT> getAll() {
        
        ArrayList<ClientADT> allData = accessor.getAll();
        
        return allData;
    }
    
    /**
     * 
     * @param id
     * @return ClientADT newClient
     * returns a new client based on the provided id, 
     * returns null if no client was found
     */
    public ClientADT getClient(int id){
        
        ClientADT newClient = accessor.get(id);
        
        return newClient;
    }
    
    /**
     * 
     * @param toUpdate
     * @return boolean
     * returns true or false if the provided client object 
     * was updated successfully
     */
    public boolean updateClient(ClientADT toUpdate){
        
        boolean success = accessor.update(toUpdate);
        
        return success;
    }
    
    /**
     * 
     * @param toAdd
     * @return boolean
     * adds a new client and returns whether or not that client 
     * was added correctly or not
     */
    public int addClient(ClientADT toAdd){
        
        int success = accessor.add(toAdd);
        
        return success;
    }
    
    /**
     * 
     * @param id
     * @return boolean
     * deletes a client and returns whether the operation was successful or not
     */
    public boolean deleteClient(int id){
        
        boolean success = accessor.delete(id);
        
        return success;
    }

    /**
     * searches using an advanced search method which returns a ArrayList
     * of clients found by the search.
     * @param id
     * @param type
     * @param name
     * @param email
     * @return ArrayList
     */
    public ArrayList<ClientADT> advancedSearch(int id, String type, String name, String email){
        
        ArrayList<ClientADT> searchList = accessor.advancedSearch(id, type, name, email);
        
        return searchList;
    }
    
    /**
     *
     * @param clientID
     * @param contactID
     * @return
     */
    public boolean addClientContact(int clientID, int contactID){
        
        boolean worked = accessor.addClientContact(clientID, contactID);
        return worked;
    }
    
    /**
     * searches through clients by type
     * @param type
     * @return 
     */
    @Override
    public ArrayList<ClientADT> searchType(String type){
        
        ArrayList newList = accessor.searchType(type);
        
        return newList;
    }
    
    /**
     *
     * @param type
     * @return
     */
    public ClientADT getClientTypeClass(String type){
        
        ClientADT newType = accessor.getClientTypeClass(type);
        
        return newType;
    }
}
