/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessClasses.AssemblyControllers;

import BusinessClasses.ControllerADT;
import BusinessClasses.MaterialControllers.MaterialController;
import DataAccessors.AssemblyAccessors.AssemblyAccessor;
import DataEntities.AssemblyEntities.AssemblyADT;
import DataEntities.MaterialEntities.MaterialADT;

import java.util.ArrayList;

/**
 *
 * @author Graham Ermter
 */
public final class AssemblyController extends ControllerADT {

    AssemblyAccessor accessor = new AssemblyAccessor();

    /**
     *
     * @param addAssembly
     * @return
     */
    public int addAssembly(AssemblyADT addAssembly) {
        
        return accessor.addAssembly(addAssembly);
    }

    /**
     *
     * @param upAssembly
     * @return
     */
    public boolean updateAssembly(AssemblyADT upAssembly) {

        return accessor.updateAssembly(upAssembly);
    }

    /**
     *
     * @param id
     * @return
     */
    public AssemblyADT get(int id) {

        return accessor.get(id);
    }
    
    /**
     *
     * @param id
     * @return
     */
    public boolean delete(int id) {

        return accessor.delete(id);
    }

    /**
     *
     * @return
     */
    @Override
    public ArrayList<AssemblyADT> getAll() {

        return accessor.getAll();
    }

    /**
     *
     * @param name
     * @return
     */
    @Override
    public ArrayList<AssemblyADT> search(String name) {

        return accessor.search(name);
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public ArrayList<AssemblyADT> search(int id) {

        return accessor.search(id);
    }

    /**
     *
     * @param type
     * @return
     */
    @Override
    public ArrayList<AssemblyADT> searchType(String type) {

        return accessor.searchType(type);
    }

    /**
     *
     * @param id
     * @param name
     * @param description
     * @param category
     * @return
     */
    public ArrayList<AssemblyADT> advancedSearch(int id, String name, String description, String category) {

        return accessor.advancedSearch(id, name, description, category);
    }

    private boolean addMaterial(int assemblyID, int materialID) {

        return accessor.addMaterial(assemblyID, materialID);
    }

    private boolean deleteMaterial(int assemblyID, int materialID) {
        
        return accessor.deleteMaterial(assemblyID, materialID);
    }

    /**
     *
     * @param id
     * @return
     */
    public ArrayList<MaterialADT> getMaterials(int id) {
        
        ArrayList<Integer> materialIDList = accessor.getMaterials(id);
        ArrayList<MaterialADT> materialList = new ArrayList<>();
        
        MaterialController tc = new MaterialController();
        
        for(int i = 0; i < materialIDList.size(); i ++){
            
            MaterialADT thisMaterial = tc.get(materialIDList.get(i));
            materialList.add(thisMaterial);
        }

        return materialList;
    }
}
