/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Materials | Templates
 * and open the template in the editor.
 */
package BusinessClasses.MaterialControllers;

import BusinessClasses.ClientControllers.VendorController;
import BusinessClasses.ControllerADT;
import DataAccessors.MaterialAccessors.MaterialAccessor;
import DataEntities.ClientEntities.ClientADT;
import DataEntities.MaterialEntities.MaterialADT;
import java.util.ArrayList;

/**
 *
 * @author Graham Ermter
 */
public final class MaterialController extends ControllerADT{

    MaterialAccessor accessor = new MaterialAccessor();
    
    /**
     *
     * @param name
     * @return
     */
    @Override
    public ArrayList search(String name){     
        return accessor.search(name);
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public ArrayList search(int id) {
        return accessor.search(id);
    }

    /**
     *
     * @param type
     * @return
     */
    @Override
    public ArrayList searchType(String type) {
        return accessor.searchType(type);
    }

    /**
     *
     * @return
     */
    @Override
    public ArrayList getAll() {
        return accessor.getAll();
    }
    
    /**
     *
     * @param addMaterial
     * @return
     */
    public int addMaterial(MaterialADT addMaterial){       
        return accessor.addMaterial(addMaterial);
    }
    
    /**
     *
     * @param upMaterial
     * @return
     */
    public boolean updateMaterial(MaterialADT upMaterial){
        return accessor.updateMaterial(upMaterial);
    }
    
    /**
     *
     * @param id
     * @return
     */
    public MaterialADT get(int id) {
        return accessor.get(id);
    }

    /**
     *
     * @param id
     * @return
     */
    public boolean delete(int id) {
        return accessor.delete(id);
    }
    
    /**
     *
     * @param id
     * @param name
     * @param category
     * @param clientName
     * @param description
     * @param lowPrice
     * @param highPrice
     * @return
     */
    public ArrayList<MaterialADT> advancedSearch(int id, String name, String category, String clientName, double lowPrice, double highPrice){
        return accessor.advancedSearch(id, name, category, clientName, null, lowPrice, highPrice);
    }
    
    /**
     *
     * @param clientID
     * @param materialID
     * @param price
     * @return
     */
    public boolean addClientMaterial(int clientID, int materialID, double price){
        return accessor.addClientMaterial(clientID, materialID, price);
    }
    
    /**
     *
     * @param clientID
     * @param materialID
     * @param price
     * @return
     */
    public boolean updateClientMaterial(int clientID, int materialID, double price){
        return accessor.updateClientMaterial(clientID, materialID, price);
    }
    
    /**
     *
     * @param clientID
     * @param materialID
     * @return
     */
    public boolean deleteClientMaterial(int clientID, int materialID){
        return accessor.deleteClientMaterial(clientID, materialID);
    }
    
    /**
     *
     * @return
     */
    public ArrayList getCategories() {
        return accessor.getCategories();
    }
    
    /**
     *
     * @param materialID
     * @return
     */
    public ArrayList<ClientADT> getClientsByMaterial(int materialID){
        
        ArrayList<Integer> clientIDList = accessor.getClientsByMaterial(materialID);
        ArrayList<ClientADT> clientList = new ArrayList();
        
        VendorController vc = new VendorController();
        
        for(int i = 0; i <  clientIDList.size(); i++){
            
            ClientADT thisClient = vc.getClient(clientIDList.get(i));
            
            clientList.add(thisClient);
        }
        
        return clientList;
    }
    
    /**
     *
     * @param clientID
     * @param materialID
     * @return
     */
    public double getMaterialPrice(int clientID, int materialID){
        return accessor.getMaterialPrice(clientID, materialID);
    }    
}
