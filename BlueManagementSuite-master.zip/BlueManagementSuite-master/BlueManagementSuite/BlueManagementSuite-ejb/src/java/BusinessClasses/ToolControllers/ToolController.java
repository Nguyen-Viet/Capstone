/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessClasses.ToolControllers;

import BusinessClasses.ClientControllers.VendorController;
import BusinessClasses.ControllerADT;
import DataAccessors.ToolAccessors.ToolAccessor;
import DataEntities.ClientEntities.ClientADT;
import DataEntities.ToolEntities.ToolADT;
import java.util.ArrayList;

/**
 *
 * @author Graham Ermter
 */
public final class ToolController extends ControllerADT{

    ToolAccessor accessor = new ToolAccessor();
    
    /**
     *
     * @param name
     * @return
     */
    @Override
    public ArrayList search(String name){     
        return accessor.search(name);
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public ArrayList search(int id) {
        return accessor.search(id);
    }

    /**
     *
     * @param type
     * @return
     */
    @Override
    public ArrayList searchType(String type) {
        return accessor.searchType(type);
    }

    /**
     *
     * @return
     */
    @Override
    public ArrayList getAll() {
        return accessor.getAll();
    }
    
    /**
     *
     * @param addTool
     * @return
     */
    public int addTool(ToolADT addTool){       
        return accessor.addTool(addTool);
    }
    
    /**
     *
     * @param upTool
     * @return
     */
    public boolean updateTool(ToolADT upTool){
        return accessor.updateTool(upTool);
    }
    
    /**
     *
     * @return
     */
    public ArrayList getCategories() {
        return accessor.getCategories();
    }
    
    /**
     *
     * @param id
     * @return
     */
    public ToolADT get(int id) {
        return accessor.get(id);
    }

    /**
     *
     * @param id
     * @return
     */
    public boolean delete(int id) {
        return accessor.delete(id);
    }
    
    /**
     *
     * @param id
     * @param name
     * @param category
     * @param clientName
     * @param lowPrice
     * @param highPrice
     * @return
     */
    public ArrayList<ToolADT> advancedSearch(int id, String name, String category, String clientName, double lowPrice, double highPrice){
        return accessor.advancedSearch(id, name, category, clientName, null, lowPrice, highPrice);
    }
    
    /**
     *
     * @param clientID
     * @param toolID
     * @param price
     * @return
     */
    public boolean addClientTool(int clientID, int toolID, double price){
        return accessor.addClientTool(clientID, toolID, price);
    }
    
    /**
     *
     * @param clientID
     * @param toolID
     * @param price
     * @return
     */
    public boolean updateClientTool(int clientID, int toolID, double price){
        return accessor.updateClientTool(clientID, toolID, price);
    }
    
    /**
     *
     * @param clientID
     * @param toolID
     * @return
     */
    public boolean deleteClientTool(int clientID, int toolID){
        return accessor.deleteClientTool(clientID, toolID);
    }
    
    /**
     *
     * @param toolID
     * @return
     */
    public ArrayList<ClientADT> getClientsByTool(int toolID){
        
        ArrayList<Integer> clientIDList = accessor.getClientsByTool(toolID);
        ArrayList<ClientADT> clientList = new ArrayList();
        
        VendorController vc = new VendorController();
        
        for(int i = 0; i <  clientIDList.size(); i++){
            
            ClientADT thisClient = vc.getClient(clientIDList.get(i));
            
            clientList.add(thisClient);
        }
        
        return clientList;
    }
    
    /**
     *
     * @param clientID
     * @param toolID
     * @return
     */
    public double getToolPrice(int clientID, int toolID){
        return accessor.getToolPrice(clientID, toolID);
    }    
}
