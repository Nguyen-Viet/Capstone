/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessClasses.ProjectControllers;

import BusinessClasses.AssemblyControllers.AssemblyController;
import BusinessClasses.ClientControllers.VendorController;
import BusinessClasses.EmployeeControllers.AdminController;
import BusinessClasses.ToolBoxControllers.ToolBoxController;
import DataAccessors.ProjectAccessors.ProjectAccessor;
import DataAccessors.ProjectAccessors.ProjectCostAccessor;
import DataAccessors.ProjectAccessors.ProjectDetailAccessor;
import DataAccessors.ProjectAccessors.ProjectSiteAccessor;
import DataEntities.AssemblyEntities.AssemblyADT;
import DataEntities.ClientEntities.ClientADT;
import DataEntities.EmployeeEntities.EmployeeADT;
import DataEntities.ProjectEntities.Project;
import DataEntities.ToolBoxEntities.ToolBoxADT;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author Graham Ermter
 */
public class ProjectController {

    ProjectAccessor accessor = new ProjectAccessor();
    ProjectCostAccessor accessorCost = new ProjectCostAccessor();
    ProjectDetailAccessor accessorDetail = new ProjectDetailAccessor();
    ProjectSiteAccessor accessorSite = new ProjectSiteAccessor();

    /**
     * Creates a project will all the filled in attributes and list items.
     * WARNING: If a project is created where values are null, those values will
     * be saved as null! Please fill in the entire object before creating.
     * @param p
     * @return 
     */
    public int add(Project p) {

        //Create initial table
        int pID = accessor.createProject(p.getProject_type(), p.getState(), p.getProject_name(), p.getStart_date(), p.getExpected_completion(), p.getDescription(), p.isDrawing(), p.isPermit());

        //Create cost table
        boolean costWork = accessorCost.createProjectCost(pID, p.getClient_budget(), p.getProject_budget(), p.getCurrent_cost(), p.getEstimated_cost(), p.getFinal_cost());

        //Create detail table
        boolean detailWork = accessorDetail.createProjectDetail(pID, p.getCeiling_height(), p.getSite_voltage(), p.isBond_wiring(), p.isTrenching(), p.isHazardous_areas(), p.isInsulated_ceiling(), p.isCrawl_space());

        //Create site table
        boolean siteWork = accessorSite.createProjectSite(pID, p.getSite_name(), p.getAddress(), p.getParking(), p.getCode(), p.isGarbage(), p.isFirst_aid(), p.isBathroom());

        //Add assemblies
        ArrayList<AssemblyADT> aList = p.getAssemblyList();
        for (int i = 0; i < aList.size(); i++) {

            accessor.addAssembly(pID, aList.get(i).getId());
        }

        //Add clients
        ArrayList<ClientADT> cList = p.getClientList();
        for (int i = 0; i < cList.size(); i++) {

            accessor.addClient(pID, cList.get(i).getId());
        }

        //Add employees
        ArrayList<EmployeeADT> eList = p.getEmployeeList();
        for (int i = 0; i < eList.size(); i++) {

            accessor.addEmployee(pID, eList.get(i).getId());
        }

        //Add toolboxes
        ArrayList<ToolBoxADT> tList = p.getToolBoxList();
        for (int i = 0; i < tList.size(); i++) {

            accessor.addToolbox(pID, tList.get(i).getId());
        }

        if (pID != -1 && costWork && detailWork && siteWork) {

            return pID;

        } else {

            return -1;
        }

    }

    /**
     * Updates a project will all the filled in attributes and list items.
     * WARNING: If a project is updated where values are null, those values will
     * be saved as null! Please fill in the entire object before updating.
     * @param p
     * @return 
     */
    public boolean update(Project p) {

        //Create initial table
        boolean projWork = accessor.updateProject(p.getId(), p.getProject_type(), p.getState(), p.getProject_name(), p.getStart_date(), p.getExpected_completion(), p.getDescription(), p.isDrawing(), p.isPermit());

        //Create cost table
        boolean costWork = accessorCost.createProjectCost(p.getId(), p.getClient_budget(), p.getProject_budget(), p.getCurrent_cost(), p.getEstimated_cost(), p.getFinal_cost());

        //Create detail table
        boolean detailWork = accessorDetail.createProjectDetail(p.getId(), p.getCeiling_height(), p.getSite_voltage(), p.isBond_wiring(), p.isTrenching(), p.isHazardous_areas(), p.isInsulated_ceiling(), p.isCrawl_space());

        //Create site table
        boolean siteWork = accessorSite.createProjectSite(p.getId(), p.getSite_name(), p.getAddress(), p.getParking(), p.getCode(), p.isGarbage(), p.isFirst_aid(), p.isBathroom());

        //Add assemblies
        ArrayList<AssemblyADT> aList = p.getAssemblyList();
        for (int i = 0; i < aList.size(); i++) {

            accessor.addAssembly(p.getId(), aList.get(i).getId());
        }

        //Add clients
        ArrayList<ClientADT> cList = p.getClientList();
        for (int i = 0; i < cList.size(); i++) {

            accessor.addClient(p.getId(), cList.get(i).getId());
        }

        //Add employees
        ArrayList<EmployeeADT> eList = p.getEmployeeList();
        for (int i = 0; i < eList.size(); i++) {

            accessor.addEmployee(p.getId(), eList.get(i).getId());
        }

        //Add toolboxes
        ArrayList<ToolBoxADT> tList = p.getToolBoxList();
        for (int i = 0; i < tList.size(); i++) {

            accessor.addToolbox(p.getId(), tList.get(i).getId());
        }

        if (projWork && costWork && detailWork && siteWork) {

            return true;

        } else {

            return false;
        }
    }

    /**
     * Gets a project based on the provided id and returns a project will all
     * data and all lists filled in using available data.
     *
     * @param id
     * @return
     */
    public Project get(int id) {

        //Get project with all attributes
        Project p = accessor.getProject(id);
        p = accessorCost.getProjectCost(p);
        p = accessorDetail.getProjectDetail(p);
        p = accessorSite.getProjectSite(p);

        //Add assemblies
        ArrayList<Integer> aList = accessor.getAssembly(id);
        AssemblyController AC = new AssemblyController();
        for (int i = 0; i < aList.size(); i++) {

            p.addAssembly(AC.get(aList.get(i)));
        }

        //Add clients
        ArrayList<Integer> cList = accessor.getClient(id);
        VendorController VC = new VendorController();
        for (int i = 0; i < cList.size(); i++) {

            p.addClient(VC.getClient(cList.get(i)));
        }

        //Add employees
        ArrayList<Integer> eList = accessor.getEmployee(id);
        AdminController AAC = new AdminController();
        for (int i = 0; i < eList.size(); i++) {

            p.addEmployee(AAC.getEmployee(eList.get(i)));
        }

        //Add toolboxes
        ArrayList<Integer> tList = accessor.getToolbox(id);
        ToolBoxController TBC = new ToolBoxController();
        for (int i = 0; i < tList.size(); i++) {

            p.addToolbox(TBC.get(tList.get(i)));
        }

        return p;
    }

    /**
     * Deletes ALL project data based on the provided id, including all extra
     * project tables.
     *
     * @param id
     * @return
     */
    public boolean delete(int id) {

        return accessor.deleteProject(id);
    }

    /**
     * Searches projects by id NOTE: this only returns partial projects, to get
     * a full project, use get.
     *
     * @param id
     * @return
     */
    public ArrayList<Project> search(int id) {

        return accessor.search(id);
    }

    /**
     * Searches projects by name NOTE: this only returns partial projects, to
     * get a full project, use get.
     *
     * @param name
     * @return
     */
    public ArrayList<Project> search(String name) {

        return accessor.search(name);
    }

    /**
     * Searches Projects by type NOTE: this only returns partial projects, to
     * get a full project, use get.
     *
     * @param type
     * @return
     */
    public ArrayList<Project> searchType(String type) {

        return accessor.searchType(type);
    }

    /**
     * Uses an advanced search to find projects NOTE: this only returns partial
     * projects, to get a full project, use get.
     *
     * @param id
     * @param state
     * @param name
     * @param type
     * @param description
     * @param client_name
     * @param employee_name
     * @return
     */
    public ArrayList<Project> advancedSearch(int id, int state, String type, String name, String description, String client_name, String employee_name) {

        return accessor.advancedSearch(id, state, type, name, description, client_name, employee_name);
    }

}
