/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessClasses.ToolBoxControllers;

import BusinessClasses.ControllerADT;
import BusinessClasses.ToolControllers.ToolController;
import DataAccessors.ToolBoxAccessors.ToolBoxAccessor;
import DataEntities.ToolBoxEntities.ToolBoxADT;
import DataEntities.ToolEntities.ToolADT;

import java.util.ArrayList;

/**
 *
 * @author Graham Ermter
 */
public final class ToolBoxController extends ControllerADT {

    ToolBoxAccessor accessor = new ToolBoxAccessor();

    /**
     *
     * @param addToolBox
     * @return
     */
    public int addToolBox(ToolBoxADT addToolBox) {
        
        return accessor.addToolBox(addToolBox);
    }

    /**
     *
     * @param upToolBox
     * @return
     */
    public boolean updateToolBox(ToolBoxADT upToolBox) {

        return accessor.updateToolBox(upToolBox);
    }

    /**
     *
     * @param id
     * @return
     */
    public ToolBoxADT get(int id) {

        return accessor.get(id);
    }
    
    /**
     *
     * @param id
     * @return
     */
    public boolean delete(int id) {

        return accessor.delete(id);
    }

    /**
     *
     * @return
     */
    @Override
    public ArrayList<ToolBoxADT> getAll() {

        return accessor.getAll();
    }

    /**
     *
     * @param name
     * @return
     */
    @Override
    public ArrayList<ToolBoxADT> search(String name) {

        return accessor.search(name);
    }

    /**
     *
     * @param id
     * @return
     */
    @Override
    public ArrayList<ToolBoxADT> search(int id) {

        return accessor.search(id);
    }

    /**
     *
     * @param type
     * @return
     */
    @Override
    public ArrayList<ToolBoxADT> searchType(String type) {

        return accessor.searchType(type);
    }

    /**
     *
     * @param id
     * @param name
     * @param description
     * @param category
     * @return
     */
    public ArrayList<ToolBoxADT> advancedSearch(int id, String name, String description, String category) {

        return accessor.advancedSearch(id, name, description, category);
    }

    private boolean addTool(int toolBoxID, int toolID) {

        return accessor.addTool(toolBoxID, toolID);
    }

    private boolean deleteTool(int toolBoxID, int toolID) {
        
        return accessor.deleteTool(toolBoxID, toolID);
    }

    /**
     *
     * @param id
     * @return
     */
    public ArrayList<ToolADT> getTools(int id) {
        
        ArrayList<Integer> toolIDList = accessor.getTools(id);
        ArrayList<ToolADT> toolList = new ArrayList<>();
        
        ToolController tc = new ToolController();
        
        for(int i = 0; i < toolIDList.size(); i ++){
            
            ToolADT thisTool = tc.get(toolIDList.get(i));
            toolList.add(thisTool);
        }

        return toolList;
    }
}
