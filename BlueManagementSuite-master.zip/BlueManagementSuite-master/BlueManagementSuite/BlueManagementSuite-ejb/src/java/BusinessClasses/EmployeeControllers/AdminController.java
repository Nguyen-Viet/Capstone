/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessClasses.EmployeeControllers;

import DataAccessors.EmployeeAccessors.AdminAccessor;

/**
 *
 * @author Graham Ermter
 */
public final class AdminController extends EmployeeControllerADT {
    
    /**
     *
     */
    public AdminController(){
        
        accessor = new AdminAccessor();
    }
    
}
