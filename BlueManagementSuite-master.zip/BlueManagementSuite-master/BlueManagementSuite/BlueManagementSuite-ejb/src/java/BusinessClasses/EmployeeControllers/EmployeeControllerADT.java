/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessClasses.EmployeeControllers;

import BusinessClasses.ControllerADT;
import DataAccessors.EmployeeAccessors.EmployeeDatabaseADT;
import DataEntities.ClientEntities.ClientADT;
import DataEntities.EmployeeEntities.EmployeeADT;
import java.util.ArrayList;

/**
 * Controller of all employees.
 * @author Graham Ermter
 */
public class EmployeeControllerADT extends ControllerADT{

    EmployeeDatabaseADT accessor;
    /**
     * 
     * @param name
     * @return ResultSet searchData
     * returns the searched information based on a String name
     */
    @Override
    public ArrayList<EmployeeADT> search(String name) {
        
        ArrayList<EmployeeADT> searchData = accessor.search(name);
        
        return searchData;
    }

    /**
     * 
     * @param id
     * @return ResultSet searchData
     * returns the searched object information based on an Integer id
     */
    @Override
    public ArrayList<EmployeeADT> search(int id) {
        
        ArrayList<EmployeeADT> searchData = accessor.search(id);
        
        return searchData;
    }
    
    /**
     * 
     * @return ArrayList allData
     * returns a resultSet populated with all object data
     */
    @Override
    public ArrayList<EmployeeADT> getAll() {
        
        ArrayList<EmployeeADT> allData = accessor.getAll();
        
        return allData;
    }
    
    /**
     * 
     * @param id
     * @return EmployeeADT
     * returns a new object based on the provided id, 
     * returns null if no object was found
     */
    public EmployeeADT getEmployee(int id){
        
        EmployeeADT newEmployee = accessor.get(id);
        
        return newEmployee;
    }
    
    /**
     * 
     * @param toUpdate
     * @return boolean
     * returns true or false if the provided object 
     * was updated successfully
     */
    public boolean updateEmployee(EmployeeADT toUpdate){
        
        boolean success = accessor.update(toUpdate);
        
        return success;
    }
    
    /**
     * 
     * @param toAdd
     * @return boolean
     * adds a new object and returns whether or not that object 
     * was added correctly or not
     */
    public int addEmployee(EmployeeADT toAdd){
        
        int success = accessor.add(toAdd);
        
        return success;
    }
    
    /**
     * 
     * @param id
     * @return boolean
     * deletes an object and returns whether the operation was successful or not
     */
    public boolean deleteEmployee(int id){
        
        boolean success = accessor.delete(id);
        
        return success;
    }

    /**
     * 
     * @param id
     * @param type
     * @param fname
     * @param surname
     * @param address
     * @param email
     * @param phone
     * @param city
     * @param province
     * @param country
     * @return searches using an advanced search method which returns an arrayList
     * of objects found by the search.
     */
    public ArrayList<EmployeeADT> advancedSearch(int id, String type, String fname, String surname, String address, String email, String phone, String city, String province, String country){
        
        ArrayList<EmployeeADT> searchList = accessor.advancedSearch(id, type, fname, surname, address, email, phone, city, province, country);
        
        return searchList;
    }
    
    /**
     *
     * @param employeeID
     * @param contactID
     * @return
     */
    public boolean addEmployeeContact(int employeeID, int contactID){
        
        boolean worked = accessor.addEmployeeContact(employeeID, contactID);
        return worked;
    }
    
    /**
     *
     * @param type
     * @return
     */
    @Override
    public ArrayList<EmployeeADT> searchType(String type){
        
        ArrayList newList = accessor.searchType(type);
        
        return newList;
    }
    
    /**
     *
     * @param type
     * @return
     */
    public EmployeeADT getEmployeeTypeClass(String type){
        
        EmployeeADT newType = accessor.getEmployeeTypeClass(type);
        
        return newType;
    }
}
