/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PresentationBeans.EmployeeBeans;

import BusinessClasses.EmployeeControllers.*;
import BusinessClasses.ServiceControllers.ContactController;
import DataEntities.EmployeeEntities.EmployeeADT;
import DataEntities.ServiceEntities.Contact;
import java.util.ArrayList;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import sun.rmi.server.UnicastRef;

/**
 *
 * @author Viet
 */
@Stateless
@LocalBean
public class EmployeeBean {

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    /**
     *
     * @param myEmployee
     * @param employeeType
     * @return
     */
    public String getEmployeeList(String myEmployee, String employeeType) {

        EmployeeControllerADT controller = null;
        String table = "";

        if (employeeType.toUpperCase() != null) {
            controller = new AdminController();
        }

        System.out.println("Client Type is:  " + employeeType);
        System.out.println("Client  name:  " + myEmployee);

        ArrayList<EmployeeADT> employees = null;

        if (employeeType.equalsIgnoreCase("ALL")) {

            if (myEmployee == null) {

                employees = controller.advancedSearch(-1, null, myEmployee, null, null, null, null, null, null, null);

            } else {

                employees = controller.advancedSearch(-1, null, myEmployee, null, null, null, null, null, null, null);
            }

            System.out.println("ALL");
        } else if (myEmployee != null && !myEmployee.equals("")) {
            char item = myEmployee.charAt(0);

            if (Character.isDigit(item)) {
                int empID = Integer.parseInt(myEmployee);

                employees = controller.advancedSearch(empID, null, null, null, null, null, null, null, null, null);
                System.out.println("yeee");
                // employees = controller.search(empID);
            } else {
                employees = controller.advancedSearch(-1, employeeType, myEmployee, null, null, null, null, null, null, null);
                System.out.println("yeee2");
            }

        } else {
            employees = controller.advancedSearch(-1, employeeType, null, null, null, null, null, null, null, null);
            System.out.println("here");
        }

        System.out.println("IS THE LIST EMPTY??: " + employees.isEmpty());

        table += "<h3>Employee List</h3>";
        table += "<div id='emp-list' class='table-responsive-sm'>";
        table += "<table class='table table-hover' name='client-table'>";
        table += "<thead class='thead-light'>";
        table += "<tr><th>Name</th><th>Type</th><th>Date Hired</th><th>View</th>";
        table += "</thead>";
        table += "<tbody>";

        for (EmployeeADT employee : employees) {

            table += "<td class='myid hidden'><label>" + employee.getId() + "</label></td>";
            table += "<tr><td><label>" + employee.getFirstName() + "  " + employee.getSurname() + "</label></td>";
            table += "<td class='mytype'><label>" + employee.getEmployeeType() + "</label></td>";
            table += "<td><label>" + employee.getDateHired() + "</label></td>";
            //table += "<td><button type='button' class='delete btn btn-danger'><i class=\"fas fa-times fa-lg \"></i></button>";
            table += "<td><button type='button' class='view btn btn-info' text='"+employee.getEmployeeType()+"'  value='"+employee.getId()+"'><i class='fas fa-info'></i></button>";
        }

        table += "</tbody>";
        table += "</table>";
        table += "</div>";

        return table;
    }

    /**
     *
     * @param emp_id
     * @param employeeType
     * @return
     */
    public String getEmployeeDetail(String emp_id, String employeeType) {

        EmployeeControllerADT controller = null;

        String table1 = "";
        String table2 = "";
        String contactLabel = "";
        String contactModal = "";

        if (employeeType != null) {
            switch (employeeType) {
                case "AD":
                    controller = new AdminController();
                    break;
                case "BK":
                    controller = new BookKeeperController();
                    break;
                case "MA":
                    controller = new ManagerController();
                    break;
                case "WR":
                    controller = new WorkerController();
                    break;
                default:
                    controller = new AdminController();
                    break;
            }
        }

        if (emp_id != null) {

            System.out.println("Trying to view:   " + emp_id);

            int id = Integer.parseInt(emp_id);

            EmployeeADT ea = controller.getEmployee(id);
            ContactController cu = new ContactController();
            ArrayList<Contact> c = cu.getContactsByEmployee(id);

            String employeeName = ea.getFirstName() + " " + ea.getSurname();
            String employeeEmail = ea.getEmail();
            int employeeId = ea.getId();

            System.out.println("IS THE ARRAY EMPTY?  " + c.isEmpty());

            table1 += "<form action='SpecialOps' method='POST'>";

            table1 += "<h3>" + employeeName
                    + " <button class='btn btn-primary' type='button' id='edit' value='edit'>edit</button>"
                    + " <button class='save btn btn-default' type='button' id='save' value='save' disabled>save</button>"
                    + " <button class='delete btn btn-danger pull-right' type='button' id='save' value='delete' onclick='deleteEmployeeSimple("+id+");' disabled>delete</button>"
                    + "</h3>";

            table1 += "<div class='form-group' id='emp' ><table class='table'>";
            table1 += "<tr><td class='row-strong'>Employee</td><td><input class='form-control input-sm detail-input' type='text' name='cname' value='" + employeeName + "' disabled></td>";
            table1 += "<input class='form-control hidden' type='text' name='cId' value='" + employeeId + "' disabled>";
            table1 += "<td class='row-strong'>Type</th><td><input class='form-control input-sm detail-input' type='text' name='ctype' value='" + ea.getEmployeeType() + "' disabled></td></tr>";
            table1 += "<tr><td class='row-strong'>Phone</th><td><input class='form-control input-sm detail-input' type='text' name='emp_phone' value='" + ea.getPhoneNumber() + "' disabled></td>";
            table1 += "<td class='row-strong'>Email</td><td><input class='form-control input-sm detail-input' type='text' name='emp_email' value='" + employeeEmail + "' disabled></td></tr>";
            table1 += "<tr><td class='row-strong'>Address</td><td><input class='form-control input-sm detail-input' type='text' name='cemail' value='" + ea.getAddress() + "' disabled></td>";
            table1 += "<td class='row-strong'>City</td><td><input class='form-control input-sm detail-input' type='text' name='emp_city' value='" + ea.getCity() + "' disabled></td></tr>";
            table1 += "<tr><td class='row-strong'>Province</td><td><input class='form-control input-sm detail-input' type='text' name='cemail' value='" + ea.getProvince() + "' disabled></td>";
            table1 += "<td class='row-strong'>Country</td><td><input class='form-control input-sm detail-input' type='text' name='cemail' value='" + ea.getCountry() + "' disabled></td></tr>";
            table1 += "</table></div>";

            //table2 += "<table class='table table-condensed' >";
            //table2 += "<thead><tr><th>First Name</th><th>Surname</th><th>Phone Number</th><th>more</th></tr></thead>";
            int counter = 0;

            for (Contact contact : c) {

                table2 += "<tr>";
                table2 += "<td><input class='form-control input-sm ' type='text' name='contactFname' value='" + contact.getFirstName() + "' disabled></td>";
                table2 += "<td><input class='form-control input-sm ' type='text' name='surname' value='" + contact.getSurName() + "' disabled></td>";
                table2 += "<td><input class='form-control input-sm ' type='text' name=''phone' value='" + contact.getPhoneNumber() + "' disabled></td>";
                table2 += "<td><button type=\"button\" class=\"btn btn-primary-sm\" data-toggle=\"collapse\" data-target=\"#demo" + counter + "\"><span class=\"glyphicon\">&#x25BC;</span></button></td>";
                table2 += "</tr>";

                //Colapse Row
                table2 += "<tr id='demo" + counter + "' class='collapse' rowspan='2'><td colspan='4'>";

                //ID
                table2 += "<input class='hidden' type='text' name='id' value='" + contact.getId() + "' disabled>";

                //Type
                table2 += "<b>Type:</b>"
                        + "<input class='form-control detail-input' type='text' name='type' value='" + contact.getType() + "' disabled>";
                //Address
                table2 += "<b>Address:</b>"
                        + "<input class='form-control detail-input' type='text' name='address' value='" + contact.getAddress() + "' disabled>";

                //Email
                table2 += "<b>Email:</b>"
                        + "<input class='form-control detail-input' type='text' name='email' value='" + contact.getEmail() + "' disabled>";

                //Company
                table2 += "<b>Company:</b>"
                        + "<input class='form-control detail-input' type='text' name='company' value='" + contact.getCompany() + "' disabled>";

                //Province
                table2 += "<b>Province:</b>"
                        + "<input class='form-control detail-input' type='text' name='province' value='" + contact.getProvince() + "' disabled>";

                //City
                table2 += "<b>City:</b>"
                        + "<input class='form-control detail-input' type='text' name='city' value='" + contact.getCity() + "' disabled>";

                //Quadrant
                table2 += "<b>Quadrant:</b>"
                        + "<input class='form-control detail-input' type='text' name='quadrant' value='" + contact.getQuadrant() + "' disabled>";

                //Country
                table2 += "<b>Country:</b>"
                        + "<input class='form-control detail-input' type='text' name='country' value='" + contact.getCountry() + "' disabled>";

                table2 += "</td></tr>";

                counter++;
            }

            //Contact Header
            contactLabel += "<h3>Contact "
                    + "<span id=contact-count class='badge badge-info'>" + counter + "</span>"
                    + "<input class='yes btn btn-primary pull-right' type='button' data-toggle='modal' data-target='#newConModal' value='+ Add New Contact'>"
                    + "</h3>";

            //Contact Table
            contactLabel += "<div><table class='table table-sm'>";

            //Data Header
            contactLabel += "<tr><th>First Name</th><th>Surname</th><th>Phone Number</th><th>more</th></tr>";
            /*
            // Beginning of Modal
            contactModal += "<div class='modal fade' id='newEmp'>";
            contactModal += "<div class='modal-dialog'>";
            contactModal += "<div class='modal-content'>";

            // modal header
            contactModal += "<div class='modal-header'>";
            contactModal += "<h4 class='modal-title'> ADD A CONTACT </h4>";
            contactModal += "<button type='button' class='close' data-dismiss='modal'>&times;</button>";
            contactModal += "</div>";

            //********************************* modal body **********************************************
            contactModal += "<form action='ContactServices' method='POST'>";
            contactModal += "<div class='modal-body'>";

            //************************** FIRSTNAME & LASTNAME
            contactModal += "           <div class='form-row'>"
                    + "                                <div class='form-group col-md-6'>"
                    + "                                    <label class='col-form-label'>First name</label>"
                    + "                                    <input class='form-control' type='text' name='contactFname' placeholder='Robert' required><br>"
                    + "                                </div>"
                    + "                                <div class='form-group' col-md-4>"
                    + "                                    <label class='col-form-label'> Surname</label>"
                    + "                                    <input class='form-control' type='text' name='contactSurname' placeholder='Smith' required><br>"
                    + "                                </div>"
                    + "                            </div>";

            //************************* PHONE NUMBER
            contactModal += "            <div class='form-row'>"
                    + "                                <div class='form-group col-md-4'>"
                    + "                                    <label class='col-form-label'>Phone</label>"
                    + "                                    <input class='form-control' type='tel' name='phone' placeholder='403-101-1234' required><br>"
                    + "                                </div>"
                    + "                            </div>";

            //***************************** EMAIL & COMPANY
            contactModal += "<div class='form-row'>"
                    + "<div class='form-group col-md-6'>"
                    + "<label class='col-form-label'> Email </label>"
                    + "<input class='form-control' type='email' name='email' placeholder='robert_smith@email.com' required><br>"
                    + "</div>"
                    + "<div class='form-group' col-md-4>"
                    + "<label class='col-form-label'> Company </label>"
                    + "<input class='form-control' type='text' name='company' placeholder='company X' ><br>"
                    + "</div>"
                    + "</div>";

            //******************************* ADDRESS & CITY & QUADRANT
            contactModal += "<div class='form-row'>"
                    + "                                <div class='form-group col-sm-6'>"
                    + "                                    <label class='col-form-label'> Address </label>"
                    + "                                    <input class='form-control' type='text' name='address' placeholder='123 fake street'>"
                    + "                                </div>"
                    + "                                <div class='form-group col-sm-4'>"
                    + "                                    <label class='col-form-label'>City</label>"
                    + "                                    <input class='form-control' type='text' name='city' placeholder='calgary'>"
                    + "                                </div>"
                    + "                                <div class='form-group col-sm-2'>"
                    + "                                    <label class='col-form-label'>Quadrant</label>"
                    + "                                    <select name='quadrant' class='form-control'>"
                    + "                                        <option value='NE'>NE</option>"
                    + "                                        <option value='NW'>NW</option>"
                    + "                                        <option value='SE'>SE</option>"
                    + "                                        <option value='SW'>SW</option>"
                    + "                                    </select>"
                    + "                                </div>"
                    + "                            </div>";

            //****************************** PROVINCE & COUNTRY
            contactModal += "             <div class='form-row'>"
                    + "                                <div class='form-group col-md-6'>"
                    + "                                    <label class='col-form-label'> Province </label>"
                    + "                                    <input class='form-control' type='text' name='province' placeholder='Alberta'>"
                    + "                                </div>"
                    + "                                <div class='form-group col-md-4'>"
                    + "                                    <label class='col-form-label'> Country </label>"
                    + "                                    <input class='form-control' type='text' name='country' placeholder='Canada'>"
                    + "                                </div>"
                    + "                            </div>";

            //***************************** CONTACT TYPE
            contactModal += "            <div class='form-row'>"
                    + "                                <div class='form-group col-md-6'>"
                    + "                                    <label class='col-form-labell'>Contact Type</label>"
                    + "                                    <select name='contactType' class='form-control'>"
                    + "                                        <option value='MA'>Main</option>"
                    + "                                        <option value='ER'>Emergency</option>"
                    + "                                        <option value='SC'>Secondary</option>"
                    + "                                    </select>"
                    + "                                </div>"
                    + "                            </div>";

            contactModal += "</div>";

            // modal footer
            contactModal += "<div class='modal-footer'>";
            contactModal += "<button class='btn btn-success' type='submit'>Save</button>";
            contactModal += "<input type='hidden' name='empId' value=' " + id + " '>";
            contactModal += "</div>";

            contactModal += "</form>";

            contactModal += "</div></div></div>";
             */

            //tyring to do popover
            //contactLabel += "<a href='#' rel='popover' data-toggle='popover' data-content='<form>sosososo</form>' data-placement='top' >sdfs </a>";
            table2 += "</table>";
            table2 += "</form>";
        }

        table1 += contactLabel += table2 += contactModal;

        return table1;
    }

}
