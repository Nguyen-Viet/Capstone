/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PresentationBeans.WizardBeans;

import javax.ejb.Stateless;
import javax.ejb.LocalBean;

/**
 *
 * @author Graham Desktop
 */
@Stateless
@LocalBean
public class ClientWizard {

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
}
