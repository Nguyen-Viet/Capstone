/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PresentationBeans.ClientBeans;

import BusinessClasses.ClientControllers.ClientControllerADT;
import BusinessClasses.ClientControllers.CorporateClientController;
import BusinessClasses.ClientControllers.IndependentClientController;
import BusinessClasses.ClientControllers.SupplierController;
import BusinessClasses.ClientControllers.VendorController;
import BusinessClasses.ServiceControllers.ContactController;
import DataEntities.ClientEntities.ClientADT;
import DataEntities.ServiceEntities.Contact;
import java.util.ArrayList;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;

/**
 *
 * @author Viet & Graham Ermter
 */
@Stateless
@LocalBean
public class ClientBean {

    private String name;

    /**
     *
     * @param clientToSearch
     * @param clientType
     * @return
     */
    public String getClientList(String clientToSearch, String clientType) {

        ClientControllerADT controller = null;
        String table = "";

        if (clientType.toUpperCase() != null) {
            switch (clientType) {
                case "IN":
                    controller = new IndependentClientController();
                    break;
                case "CO":
                    controller = new CorporateClientController();
                    break;
                case "VR":
                    controller = new VendorController();
                    break;
                case "SP":
                    controller = new SupplierController();
                    break;
                case "ALL":
                    controller = new IndependentClientController();
                    break;
                default:
                    break;
            }
        }

        System.out.println("Client Type is:  " + clientType);
        System.out.println("Client Type name:  " + clientToSearch);

        ArrayList<ClientADT> clients = new ArrayList<>();

        if (clientType.equalsIgnoreCase("ALL")) {

            if (clientToSearch != null) {

                clients = controller.search(clientToSearch);
            } else {
                clients = controller.search("");
            }

        } else if (clientToSearch != null && !clientToSearch.equals("")) {
            char item = clientToSearch.charAt(0);

            if (Character.isDigit(item)) {
                clients = controller.search(Integer.parseInt(clientToSearch));
            } else {
                clients = controller.advancedSearch(-1, clientType, clientToSearch, null);
            }

        } else {
            clients = controller.advancedSearch(-1, clientType, null, null);
        }

        System.out.println("answer is: " + clients.isEmpty());

        table += "<h3>Client List</h3>";
        table += "<table class='table' name='client-table'>";
        table += "<thead class='thead-light'>";
        table += "<tr><th>Name</th><th>Type</th><th>Date created</th><th>View</th>";
        table += "</thead>";
        table += "<tbody>";

        for (ClientADT client : clients) {

            table += "<tr><td class='myid hidden'><label>" + client.getId() + "</label></td>";
            table += "<td class='my-name'><label>" + client.getName() + "</label></td>";
            table += "<td class='mytype'><label>" + client.getType() + "</label></td>";
            table += "<td><label>" + client.getDateCreated() + "</label></td>";
            //table += "<td><button type='button' class='delete btn btn-danger'><i class=\"fas fa-times fa-lg \"></i></button>";
            table += "<td><button type='button' class='view btn btn-info'><i class=\"fas fa-info\"></i></button>";
            // table += "<td><input type=button class=\"delete\" value=\"delete\"></td>";
            // table += "<td><input type=button class=\"view\" value=\"View\"></td></tr>";
            // &nbsp;
        }

        table += "</tbody>";
        table += "</table>";

        return table;
    }

    /**
     *
     * @param viewClient the name of specific client we want more details from
     * @param clientType the type attribute of the client we want to view
     * @return
     */
    public String getClientDetail(String viewClient, String clientType) {

        ClientControllerADT controller = null;

        String clientTable = "";
        String contactTable = "";

        if (clientType != null) {
            switch (clientType) {
                case "IN":
                    controller = new IndependentClientController();
                    break;
                case "CO":
                    controller = new CorporateClientController();
                    break;
                case "VR":
                    controller = new VendorController();
                    break;
                case "SP":
                    controller = new SupplierController();
                    break;
                case "ALL":
                    controller = new SupplierController();
                default:
                    break;
            }
        }

        if (viewClient != null) {

            //Get the client to view
            ClientADT client = controller.getClient(Integer.parseInt(viewClient));

            //Get get the contacts for the view client
            ContactController contactCtrl = new ContactController();
            ArrayList<Contact> contactList = contactCtrl.getContactsByClient(client.getId());

            //Edit Area
            clientTable += "<form action='SpecialOps' method='POST'>";

            
            clientTable += "<h3>"+client.getName()
            + " <button class='btn btn-primary' type='button' id='edit' value='edit'>edit</button>"
            + " <button class='btn btn-default' type='button' id='save' value='save' onclick='searchLoad('');' disabled>save</button>"
            + " <button class='btn btn-danger btn-danger pull-right' type='button' id='save' value='delete' onclick='deleteClientSimple("+client.getId()+");' disabled>delete</button>"
            +"</h3>";

            //Start data table
            clientTable += "<table id='display-more-details'>";
            
                //Client Table
                clientTable += "<table class='table'>";
                
                //Name
                clientTable += "<tr>"
                + "<td class='row-strong'>Client</td>"
                + "<td><input class='form-control detail-input' type='text' name='cname' value='" + client.getName() + "' disabled></td>"
                + "</tr>";

                //ID
                clientTable += "<input class='form-control hidden' type='text' name='cId' value='" + client.getId() + "' disabled>";


                //Type
                clientTable += "<tr>"
                + "<td class='row-strong'>Type</td>"
                + "<td><input class='form-control detail-input' type='text' name='ctype' value='" + client.getType() + "' disabled></td>"
                + "</tr>";

                //Email
                clientTable += "<tr>"
                + "<td class='row-strong'>Email</td>"
                + "<td><input class='form-control detail-input' type='text' name='cemail' value='" + client.getEmail() + "' disabled></td>"
                + "</tr>";

            //End Client Table
            clientTable += "</table>";

            //Contact Table
            contactTable += "<table class='table' id='kk'>";

            //Lable
            contactTable += "<h3>Contact&nbsp;<span id=contact-count class='badge badge-info'>" + contactList.size() + "</span></h3>";

                //Row 1
                contactTable += "<tr>"
                + "<th>First Name</th>"
                + "<th>Surname</th>"
                + "<th colspan='2'>Phone Number</th>"
                + "</tr>";

                //For each contact in the contact list
                for (int i = 0; i < contactList.size(); i++) {

                    //Get the currecnt contact
                    Contact contact = contactList.get(i);

                    //Contact Display Row
                    contactTable += "<tr>";
                    contactTable += "<td><input class='form-control detail-input' type='text' name='contactFname' value='" + contact.getFirstName() + "' disabled></td>";
                    contactTable += "<td><input class='form-control detail-input' type='text' name='surname' value='" + contact.getSurName() + "' disabled></td>";
                    contactTable += "<td><input class='form-control detail-input' type='text' name='phone' value='" + contact.getPhoneNumber() + "' disabled></td>";
                    contactTable += "<td><button type='button' class='btn btn-primary-sm' data-toggle='collapse' data-target='#demo" + i + "'><span class='glyphicon'>&#x25BC;</span></button></td>";
                    contactTable += "</tr>";
                    
                    //Colapse Row
                    contactTable += "<tr id='demo" + i + "' class='collapse' rowspan='2'><td colspan='4'>";
                    
                    //ID
                    contactTable += "<input class='hidden' type='text' name='id' value='" + contact.getId() + "' disabled>";



                    //Type
                    contactTable += "<b>Type:</b>"
                            + "<input class='form-control detail-input' type='text' name='type' value='" + contact.getType() + "' disabled>";
                    //Address
                    contactTable += "<b>Address:</b>"
                            + "<input class='form-control detail-input' type='text' name='address' value='" + contact.getAddress() + "' disabled>";
                    
                    //Email
                    contactTable += "<b>Email:</b>"
                            + "<input class='form-control detail-input' type='text' name='email' value='" + contact.getEmail() + "' disabled>";
                    
                    //Company
                    contactTable += "<b>Company:</b>"
                            + "<input class='form-control detail-input' type='text' name='company' value='" + contact.getCompany() + "' disabled>";
                    
                    //Province
                    contactTable += "<b>Province:</b>"
                            + "<input class='form-control detail-input' type='text' name='province' value='" + contact.getProvince() + "' disabled>";
                    
                    //City
                    contactTable += "<b>City:</b>"
                            + "<input class='form-control detail-input' type='text' name='city' value='" + contact.getCity() + "' disabled>";
                    
                    //Quadrant
                    contactTable += "<b>Quadrant:</b>"
                            + "<input class='form-control detail-input' type='text' name='quadrant' value='" + contact.getQuadrant() + "' disabled>";
                    
                    //Country
                    contactTable += "<b>Country:</b>"
                            + "<input class='form-control detail-input' type='text' name='country' value='" + contact.getCountry() + "' disabled>";

                    contactTable += "</td></tr>";
                }

            //End Contact Table
            contactTable += "</table>";
            
            //End data table
            contactTable += "</table>";
            
            contactTable += "</form>";
        }

        return clientTable + contactTable;
    }
}
