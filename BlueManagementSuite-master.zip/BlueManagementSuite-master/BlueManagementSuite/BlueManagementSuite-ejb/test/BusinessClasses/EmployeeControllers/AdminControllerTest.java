/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinessClasses.EmployeeControllers;

import DataEntities.EmployeeEntities.EmployeeADT;
import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Administrator
 */
public class AdminControllerTest {
    
    private AdminController controller = new AdminController();   

    @Test
    public void testSearchByName() {
        
    }
    
    @Test
    public void testSearchById() {
        
    }
    
    @Test
    public void testGetAll() {
        ArrayList<EmployeeADT> list = controller.getAll();
        
    }
    
    @Test
    public void testGetEmployee() {
        
    }
    
    @Test
    public void testUpdateEmployee() {
        
    }
    
    @Test
    public void testAddEmployee() {
        
    }
    
    @Test
    public void testDeleteEmployee() {
        
    }
    
    @Test
    public void testAddEmployeeContact() {
        
    }
}
