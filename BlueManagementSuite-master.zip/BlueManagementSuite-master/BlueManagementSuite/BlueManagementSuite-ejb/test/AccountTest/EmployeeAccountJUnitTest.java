/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AccountTest;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author 661173
 */
public class EmployeeAccountJUnitTest {
    
    public EmployeeAccountJUnitTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        
                    /*
            AdminController con = new AdminController();
            ArrayList<EmployeeADT> list = con.getAll();
            
            //Refresh all the clients
            for(int i = 0; i < list.size(); i++){
                
                EmployeeADT newObj = list.get(i);
                con.deleteEmployee(newObj.getId());
                con.addEmployee(newObj);
            }
            
            
            EmployeeAccountController EAC = new EmployeeAccountController();
            ArrayList<EmployeeAccount> EAList = EAC.advancedSearch(-1, null, "scat");
            
            for(int i = 0; i < EAList.size(); i++){
            
                EmployeeAccount EA = EAList.get(i);

                out.print("================================================");
                out.print("================================================");
                out.print("================================================");
                out.println("</br>");
                out.println(EA.toString());
                out.println("</br>");
                out.println(EAC.update(EA));
                out.println("</br>");
                out.println("isLocked: " +  EAC.isLocked(EA.getId()));
                out.println("</br>");
                out.println(EAC.toggleLocked(EA.getId()));
                out.println("</br>");
                
            }
            out.print("================================================");
            out.print("================================================");
            out.print("================================================");
            */
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
}
