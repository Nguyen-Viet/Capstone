/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee_services;

import BusinessClasses.EmployeeControllers.*;
import DataEntities.EmployeeEntities.EmployeeADT;
import PresentationBeans.EmployeeBeans.*;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Viet
 */
@WebServlet(name = "EmployeeServices", urlPatterns = {"/EmployeeServices"})
public class EmployeeServices extends HttpServlet {

    @EJB
    private EmployeeBean employeeBean;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/plain");

        //  
        String employeeSearch = request.getParameter("employeeSearch");
        String employeeID = request.getParameter("employeeID");
        String operation = request.getParameter("operation");
        String des = request.getParameter("destination");

        // ATTRIBUTE TO ADD EMPLOYEE
        String employeeType = request.getParameter("employeeType");
        String Fname = request.getParameter("empFirst");
        String Lname = request.getParameter("empLast");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String address = request.getParameter("address");
        String city = request.getParameter("city");
        String province = request.getParameter("province");
        String country = request.getParameter("country");

        EmployeeControllerADT controller = null;

        System.out.println("EMPLOYEE TYPE IS: '" + employeeType + "'");

        if (employeeType != null) {
            switch (employeeType) {
                case "AD":
                    controller = new AdminController();
                    break;
                case "BK":
                    controller = new BookKeeperController();
                    break;
                case "MA":
                    controller = new ManagerController();
                    break;
                case "WR":
                    controller = new WorkerController();
                    break;
                default:
                    controller = new AdminController();
                    break;
            }
        }

        System.out.println("OPERATION IS:  " + operation);

        switch (operation) {

            case "listEmployees":

                if (employeeType != null || employeeSearch != null) {
                    String result = employeeBean.getEmployeeList(employeeSearch, employeeType);
                    PrintWriter out = response.getWriter();
                    out.print(result);
                } else {
                    System.out.println("cannot list all clients");
                }

                break;

            case "moreDetails":

                if (employeeID != null && employeeType != null) {
                    String result = employeeBean.getEmployeeDetail(employeeID, employeeType);
                    PrintWriter out = response.getWriter();
                    out.print(result);
                } else {
                    System.out.println("cannot show more detail");
                }

                break;

            case "delete":
                if (employeeID != null && employeeType != null) {
                    controller.deleteEmployee(Integer.parseInt(employeeID));
                    String result = employeeBean.getEmployeeList(employeeSearch, employeeType);
                    PrintWriter out = response.getWriter();
                    out.print(result);

                } else {
                    System.out.println("cannot delete");
                }

                break;

            case "addEmployee":

          
                

                EmployeeADT employee = controller.getEmployeeTypeClass(employeeType);

                employee.setFirstName(Fname);
                employee.setSurname(Lname);
                employee.setEmployeeType(employeeType);
                employee.setEmail(email);
                employee.setPhoneNumber(phone);
                employee.setAddress(address);
                employee.setCity(city);
                employee.setProvince(province);
                employee.setCountry(country);
                

                int myEmpId = controller.addEmployee(employee);

                System.out.println("emp id   " + myEmpId);

                getServletContext().getRequestDispatcher(des).forward(request, response);

                break;

        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
