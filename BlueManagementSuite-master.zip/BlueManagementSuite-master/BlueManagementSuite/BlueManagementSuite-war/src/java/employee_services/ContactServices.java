/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee_services;

import BusinessClasses.EmployeeControllers.AdminController;
import BusinessClasses.ServiceControllers.ContactController;
import DataEntities.ServiceEntities.Contact;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author 636494
 */
@WebServlet(name = "ContactServices", urlPatterns = {"/ContactServices"})
public class ContactServices extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        String contactFname = request.getParameter("contactFname");
        String contactSurname = request.getParameter("contactSurname");
        String phone = request.getParameter("phone");
        String address = request.getParameter("address");
        String city = request.getParameter("city");
        String quadrant = request.getParameter("quadrant");
        String province = request.getParameter("province");
        String country = request.getParameter("country");
        String email = request.getParameter("email");
        String company = request.getParameter("company");
        String contactType = request.getParameter("contactType");

        String emp_Id = request.getParameter("empId");

        
        System.out.println("contact type:  " + contactType);
        System.out.println("province : " + province);
        System.out.println("quadrant : " + quadrant);
        System.out.println("emp ID:  " + emp_Id);
        System.out.println("id length is : " + emp_Id.length());
        
        
        
        AdminController ac = new AdminController();
        ContactController cc = new ContactController();
        Contact con = new Contact();
        
        
        con.setType(contactType);
        con.setFirstName(contactFname);
        con.setSurName(contactSurname);
        con.setPhoneNumber(phone);
        con.setAddress(address);
        con.setCity(city);
        con.setQuadrant(quadrant);
        con.setProvince(province);
        con.setCountry(country);
        con.setEmail(email);
        con.setCompany(company);
        
        
        int contact_id = cc.addContact(con);
        int employee_id = Integer.parseInt(emp_Id.trim());
        
        System.out.println("employee_id :   " + employee_id);
        
        
        boolean flag = ac.addEmployeeContact(employee_id, contact_id);

        if( flag )
        {
            String message = "yes";
            request.setAttribute("message", message);
            System.out.println(message);
            
        }
        else
        {
            String message = "no";
            request.setAttribute("message", message);
            System.out.println(message);
        }
        
        getServletContext().getRequestDispatcher("/EmployeeView.jsp").forward(request, response);
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
