/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package account_services;

import BusinessClasses.AccountControllers.ClientAccountController;
import BusinessClasses.AccountControllers.EmployeeAccountController;
import BusinessClasses.ClientControllers.CorporateClientController;
import DataEntities.AccountEntities.AccountADT;
import DataEntities.AccountEntities.ClientAccount;
import DataEntities.AccountEntities.EmployeeAccount;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Graham Ermter
 */
@WebServlet(name = "AccountServices", urlPatterns = {"/AccountServices"})
public class AccountServices extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        String search = request.getParameter("search");
        String clientType = request.getParameter("clientType");
        String employeeType = request.getParameter("employeeType");
        String selected = request.getParameter("selected");
        String stringItemID = request.getParameter("itemID");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String isLocked = request.getParameter("locked");
        String operation = request.getParameter("operation");
        
        System.out.println("Is locked Original: " + isLocked);
        
        String tableString = "";
        PrintWriter out = response.getWriter();
        
        ClientAccountController CAC = new ClientAccountController();
        EmployeeAccountController EAC = new EmployeeAccountController();
        
        switch(operation){
            
            case "searchClient":
                
                ArrayList<ClientAccount> caList;
                
                //if normal search
                if(clientType.equals("allc")){
                    
                    caList = CAC.search(search); 
                    
                } else {
                    
                    caList = CAC.advancedSearch(-1, clientType, search);
                }
                
                tableString =  CATableHTML(caList, selected);
                break;
                
                
            case "searchEmployee":
                
                ArrayList<EmployeeAccount> eaList;
                
                //if normal search
                if(employeeType.equals("alle")){
                    
                    eaList = EAC.search(search); 
                    
                } else {
                    
                    eaList = EAC.advancedSearch(-1, employeeType, search);
                }
                
                tableString = EATableHTML(eaList,selected);
                break;
            
            case "displayClient":
                
                int clientItemID = Integer.parseInt(stringItemID);
                
                ClientAccount getClientAcc = CAC.get(clientItemID);
                
                tableString = clientAccHTML(getClientAcc);
                
                break;
                
            case "displayEmployee":
                
                int empItemID = Integer.parseInt(stringItemID);
                
                EmployeeAccount getEmpAcc = EAC.get(empItemID);
                
                tableString = empAccHTML(getEmpAcc);
                
                break;
             
            case "saveClient":
                
                int clientID = Integer.parseInt(stringItemID);
                
                ClientAccount testClient = CAC.get(clientID);
                
                if(testClient != null){
                    
                    testClient.setUsername(username);
                    testClient.setPassword(password);
                    
                    //if the current clocked status matches
                    if(testClient.isLocked() != (isLocked.equals("true"))){
                        
                        CAC.toggleLocked(testClient.getId());
                    }
                    
                    boolean worked = CAC.update(testClient);   
                    
                    if(worked){
                        
                        tableString = "true";
                        
                    } else {
                        
                        tableString = "false";
                    }  
                }
                break;
                
            case "saveEmployee":
                
                int employeeID = Integer.parseInt(stringItemID);
                
                EmployeeAccount testEmp = EAC.get(employeeID);
                
                if(testEmp != null){
                    
                    testEmp.setUsername(username);
                    testEmp.setPassword(password);
                    
                    //if the current clocked status matches
                    if(testEmp.isLocked() != (isLocked.equals("true"))){
                        
                        EAC.toggleLocked(testEmp.getId());
                    }
                    
                    boolean worked = EAC.update(testEmp);   
                    
                    if(worked){
                        
                        tableString = "true";
                        
                    } else {
                        
                        tableString = "false";
                    }
                }
                
                break;
        }
        
        out.print(tableString);
    }
    
    
    private final String CATableHTML(ArrayList<ClientAccount> accList, String selected){
        
        String rs = "";
        
        rs += "<h2>Client Accounts</h2>";
        rs += "<table class='panel panel-default'>";
            
            rs += "<tr><b>";
              rs += "<th>Username</th>";
              rs += "<th>Name</th>";
              rs += "<th>Type</th>";
              rs += "<th>Locked</th>";
            rs += "</tr></b>";
        
        //For each account (row item)
        for(int i = 0; i < accList.size(); i++){
            
            ClientAccount ca = accList.get(i);
            
            //Start Row
            if(selected != null){
            
                if(selected.equals(Integer.toString(ca.getId()))){

                    //Add item
                    rs += "<tr id='"+ca.getId()+"' class='tr-selected' onclick='getAccount(this.id);')>";
                } else {

                    //Add item 
                    rs += "<tr id='"+ca.getId()+"' class='tr-hover' onclick='getAccount(this.id);')>";
                }   
                
            } else {
                
                //Add item text
                rs += "<tr id='"+ca.getId()+"' class='tr-hover' onclick='getAccount(this.id);')>";
            }
            
            //Data
            rs += "<td>" + ca.getUsername() + "</td>";
            rs += "<td>"+ ca.getUser().getName() + "</td>";
            rs += "<td>"+ ca.getUser().getType() + "</td>";
            
            if(ca.isLocked()){
                
                rs += "<td>Yes</td>";
            } else {
                
                rs += "<td>No</td>";
            }
            
            //End row
            rs += "</tr>";
        }
        
        rs += "</table>";
        
        return rs;
    }
    
    private final String EATableHTML(ArrayList<EmployeeAccount> accList, String selected){
        
        String rs = "";
        rs += "<h2>Employee Accounts</h2>";
        rs += "<table class='panel panel-default'>";
            
            rs += "<tr><b>";
              rs += "<th>Username</th>";
              rs += "<th>Name</th>";
              rs += "<th>Type</th>";
              rs += "<th>Locked</th>";
            rs += "</tr></b>";
        
        //For each account (row item)
        for(int i = 0; i < accList.size(); i++){
            
            EmployeeAccount ca = accList.get(i);
            
            //Start Row
            if(selected != null){
            
                if(selected.equals(Integer.toString(ca.getId()))){

                    //Add item
                    rs += "<tr id='"+ca.getId()+"' class='tr-selected' onclick='getAccount(this.id);')>";
                } else {

                    //Add item 
                    rs += "<tr id='"+ca.getId()+"' class='tr-hover' onclick='getAccount(this.id);')>";
                }   
                
            } else {
                
                //Add item text
                rs += "<tr id='"+ca.getId()+"' class='tr-hover' onclick='getAccount(this.id);')>";
            }
            
            //Data
            rs += "<td>" + ca.getUsername() + "</td>";
            rs += "<td>"+ ca.getUser().getFirstName() + " " + ca.getUser().getSurname() + "</td>";
            rs += "<td>"+ ca.getUser().getEmployeeType() + "</td>";
            
            if(ca.isLocked()){
                
                rs += "<td>Yes</td>";
            } else {
                
                rs += "<td>No</td>";
            }
            
            //End row
            rs += "</tr>";
        }
        
        rs += "</table>";
        
        return rs;
    }
   
    private final String clientAccHTML(ClientAccount ca){
        
        String rs = "";
        
        rs += "<h2>"+ca.getUser().getName()+"</h2>";
                
        rs += "Username<input class='form-control' id='username' type='search' placeholder='Username' value='"+ca.getUsername()+"'>";
        rs +=  "<br>";
        rs += "Password<input class='form-control' id='password' type='search' placeholder='Password' value='"+ca.getPassword()+"'>";
        rs += "<hr/>";
        rs += "Account Lock<br>";
        
        //Add the locked status
        if(ca.isLocked()){
            
            rs += "<input checked type='checkbox' id='lockedStat'>";
            rs +=  "<script>";
            rs +=  "$(function() {";
            rs +=  "$('#lockedStat').bootstrapToggle({on: 'On', off: 'Off'});";
            rs +=  "})";
            rs +=  "</script>";
        
        } else {
            
            rs += "<input type='checkbox' id='lockedStat'>";
            rs +=  "<script>";
            rs +=  "$(function() {";
            rs +=  "$('#lockedStat').bootstrapToggle({on: 'On', off: 'Off'});";
            rs +=  "})";
            rs +=  "</script>";
        }
        
        rs += "<input type='button' class='btn' id='save' value='Save' style='float: right;' onclick='save();'>";
        rs += "<input type='hidden' id='editID' value='" + ca.getId() + "'>";
        
        return rs;
    }
    
    private final String empAccHTML(EmployeeAccount ea){

        String rs = "";
        
        rs += "<h2>"+ea.getUser().getFirstName()+ " " + ea.getUser().getSurname()+ "</h2>";
                
        rs += "Username<input class='form-control' id='username' type='search' placeholder='Username' value='"+ea.getUsername()+"'>";
        rs +=  "<br>";
        rs += "Password<input class='form-control' id='password' type='search' placeholder='Password' value='"+ea.getPassword()+"'>";
        rs += "<hr/>";
        rs += "Account Lock<br>";
        
        //Add the locked status
        if(ea.isLocked()){
            
            rs += "<input checked type='checkbox' id='lockedStat'>";
            rs +=  "<script>";
            rs +=  "$(function() {";
            rs +=  "$('#lockedStat').bootstrapToggle({on: 'On', off: 'Off'});";
            rs +=  "})";
            rs +=  "</script>";
        
        } else {
            
            rs += "<input type='checkbox' id='lockedStat'>";
            rs +=  "<script>";
            rs +=  "$(function() {";
            rs +=  "$('#lockedStat').bootstrapToggle({on: 'On', off: 'Off'});";
            rs +=  "})";
            rs +=  "</script>";
        }
        
    rs += "<input type='button' class='btn' id='save' value='Save' style='float: right;' onclick='save();'>";
    rs += "<input type='hidden' id='editID' value='" + ea.getId() + "'>";
        

        return rs;
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
