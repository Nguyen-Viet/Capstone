/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_services;

import BusinessClasses.ProjectControllers.ProjectController;
import DataEntities.ProjectEntities.Project;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author 661173
 */
@WebServlet(name = "projectViewServices", urlPatterns = {"/projectViewServices"})
public class projectViewServices extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected String processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        String search = request.getParameter("search");
        String type = request.getParameter("type");
        String statusString = request.getParameter("status");
        String operation = request.getParameter("operation");

        if (type.equals("ALL")) {

            type = null;
        }

        PrintWriter out = response.getWriter();

        ProjectController pc = new ProjectController();

        switch (operation) {

            case "search":

                int status = Integer.parseInt(statusString);

                System.out.println("status: " + status);
                System.out.println("type: " + type);
                System.out.println("search: '" + search + "'");

                ArrayList<Project> projectList = pc.advancedSearch(-1, status, type, search, null, null, null);

                System.out.println(projectList.size());

                String blockList = "";

                for (int i = 0; i < projectList.size(); i++) {

                    Project thisProject = projectList.get(i);

                    blockList += getProjectBlock(thisProject);
                }

                out.print(blockList);
        }

        return null;
    }

    private String getProjectBlock(Project project) {

        String block = "";

        block += "<article class='card'>";
        block += "<header class='card__title card-header'>";
        block += "<h3>" + project.getProject_name() + "</h3>";
        block += "</header>";
        block += "<table style='width:100%; text-align: center;'>";
        block += "<tr class='row-strong'><td>Type</td><td>State</td></tr>";
        block += "<tr><td>" + project.getProject_type() + "</td><td>" + getPSText(project.getState()) + "</td></tr>";
        block += "<tr class='row-strong'><td>Start Date</td><td>Completion Date</td></tr>";
        block += "<tr><td>" + project.getStart_date() + "</td><td>" + project.getExpected_completion() + "</td></tr>";
        block += "</table>";
        block += "<main class='card__description'>" + project.getDescription() + "</main>";
        block += "<a id='view-button' href='ProjectWizard.jsp' class='button'>View Project</a>";
        block += "</article>";

        return block;
    }

    private String getPSText(int state) {

        String ss = "";
        
        switch (state) {
            case 0:
                ss = "Canceled";
                break;
            case 1:
                ss = "Idle";
                break;
            case 2:
                ss = "Layout";
                break;
            case 3:
                ss = "Support";
                break;
            case 4:
                ss = "Enclosure";
                break;
            case 5:
                ss = "Rough-In";
                break;
            case 6:
                ss = "Inspection";
                break;
            case 7:
                ss = "Pre-Finish";
                break;
            case 8:
                ss = "Finishing";
                break;
            case 9:
                ss = "Testing";
                break;
            case 10:
                ss = "Final";
                break;
            case 11:
                ss = "Complete";
                break;
        }
        
        return ss;
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
