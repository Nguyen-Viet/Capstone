/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client_services;

import BusinessClasses.ClientControllers.IndependentClientController;
import BusinessClasses.EmployeeControllers.AdminController;
import BusinessClasses.EmployeeControllers.EmployeeControllerADT;
import BusinessClasses.ServiceControllers.ContactController;
import DataEntities.ClientEntities.ClientADT;
import DataEntities.ClientEntities.IndependentClient;
import DataEntities.EmployeeEntities.EmployeeADT;
import DataEntities.ServiceEntities.Contact;
import PresentationBeans.ClientBeans.ClientBean;
import PresentationBeans.EmployeeBeans.EmployeeBean;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.Arrays;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Description: This class is use for extensive operation in the ClientView.jsp
 * page
 *
 * @author 636494
 */
@WebServlet(name = "SpecialOps", urlPatterns = {"/SpecialOps"})
public class SpecialOps extends HttpServlet {

    @EJB
    private ClientBean clientBean;
    private EmployeeBean employeeBean;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/plain");

        // attribute to add a client
        String clientName = request.getParameter("clientName");
        String clientType = request.getParameter("newType");

        // attribute to add contact
        String contactFname = request.getParameter("contactFname");
        String contactSurname = request.getParameter("contactSurname");
        String phone = request.getParameter("phone");
        String address = request.getParameter("address");
        String city = request.getParameter("city");
        String quadrant = request.getParameter("quadrant");
        String province = request.getParameter("province");
        String country = request.getParameter("country");
        String email = request.getParameter("email");
        String company = request.getParameter("company");
        String contactType = request.getParameter("contactType");

        // meta-data
        String operation = request.getParameter("operation");
        String destination = request.getParameter("destination");
        String contactCount = request.getParameter("contactCount");

        // ARRAY OF INPUT FIELD DATA
        String[] list = request.getParameterValues("list[]");

        System.out.println("COMPANY:  " + company);
        System.out.println("Client Name:  " + clientName);

        ContactController cc2 = new ContactController();

        int numberOfContact = 0;
        Boolean success = false;

        switch (operation) {
            case "addClient":

                IndependentClientController ac = new IndependentClientController();
                ContactController cc = new ContactController();
                IndependentClient ic = new IndependentClient();
                Contact con = new Contact();

                ClientADT client1 = ac.getClientTypeClass(clientType);

                // Creating Client
                client1.setName(clientName);
                client1.setType(clientType);
                client1.setEmail(email);

                // Creating Contact
                con.setType(contactType);
                con.setFirstName(contactFname);
                con.setSurName(contactSurname);
                con.setPhoneNumber(phone);
                con.setAddress(address);
                con.setCity(city);
                con.setQuadrant(quadrant);
                con.setProvince(province);
                con.setCountry(country);
                con.setEmail(email);
                con.setCompany(company);

                // Get Id of Client and Contact
                int contactId = cc.addContact(con);
                int clientId = ac.addClient(client1);

                System.out.println("Client ID RECEIVED IS:   " + clientId);
                System.out.println("Contact ID RECEIVED IS:   " + contactId);

                // Create the Relationship between Client and Contact
                ac.addClientContact(clientId, contactId);

                // Send User Back to Page
                getServletContext().getRequestDispatcher(destination).forward(request, response);

                break;

            case "saveClient":
                System.out.println("DATA  " + Arrays.toString(list));
                System.out.println("List length is:  " + list.length);

                numberOfContact = Integer.parseInt(contactCount);

                // Get the Number of Contact this Client or Employee has
                int index = 4;
                int nextSet = 11;

                IndependentClientController icc = new IndependentClientController();
                ClientADT client2 = icc.getClientTypeClass(list[2]);

                // Update Client Fields
                client2.setId(Integer.parseInt(list[0]));
                client2.setName(list[1]);
                client2.setType(list[2]);
                client2.setEmail(list[3]);

                success = icc.updateClient(client2);

                System.out.println("NUMBER OF CONTACTS : " + numberOfContact);

                for (int i = 1; i <= numberOfContact; i++) {
                    Contact contact = new Contact();

                    contact.setFirstName(list[index].trim());
                    contact.setSurName(list[index + 1].trim());
                    contact.setPhoneNumber(list[index + 2].trim());

                    System.out.println("set ID " + Integer.parseInt(list[index + 3].trim()));
                    contact.setId(Integer.parseInt(list[index + 3].trim()));

                    System.out.println("set type: " + list[index + 4].trim());
                    contact.setType(list[index + 4].trim());

                    contact.setAddress(list[index + 5].trim());
                    contact.setEmail(list[index + 6].trim());
                    contact.setCompany(list[index + 7].trim());
                    contact.setProvince(list[index + 8].trim());
                    contact.setCity(list[index + 9].trim());
                    contact.setQuadrant(list[index + 10].trim());
                    contact.setCountry(list[index + 11].trim());

                    index = index + nextSet;

                    System.out.println("update for contact is : " + cc2.updateContact(contact));
                    System.out.println("contact updated to : " + contact.toString());
                }

                if (success) {
                    System.out.println("Client update successful");
                    String result = clientBean.getClientDetail(Integer.toString(client2.getId()), client2.getType());
                    PrintWriter out = response.getWriter();
                    out.print(result);
                } else {
                    System.out.println("Client update not successful");
                }

                break;

            case "saveEmp":

                System.out.println("DATA  " + Arrays.toString(list));
                System.out.println("List length is:  " + list.length);

                AdminController ec = new AdminController();
                EmployeeADT emp = ec.getEmployeeTypeClass(list[2]);

                String[] name = list[1].split(" ");
                int id = Integer.parseInt(list[0]);
                Boolean successEmp = false;

                if (name.length > 1) {

                    System.out.println("emp firstnamne  " + name[0]);
                    System.out.println("emp lastname " + name[1]);

                    emp.setFirstName(name[0]);
                    emp.setSurname(name[1]);

                } else {

                    System.out.println("emp firstnamne  " + name[0]);

                    emp.setFirstName(name[0]);
                    emp.setSurname("");
                }
                // Update Employee Fields
                emp.setId(id);
                emp.setEmployeeType(list[2]);
                emp.setPhoneNumber(list[3]);
                emp.setEmail(list[4]);
                emp.setAddress(list[5]);
                emp.setCity(list[6]);
                emp.setProvince(list[7]);
                emp.setCountry(list[8]);

                EmployeeADT _emp = ec.getEmployee(id);
                Date date = emp.getDateHired();

                emp.setDateHired(date);

                System.out.println("employee object: " + emp.toString());

                System.out.println("NUMBER OF CONTACTS : " + numberOfContact);

                int index2 = 9;
                int nextSet2 = 6;

                for (int i = 1; i <= numberOfContact; i++) {
                    Contact contact = new Contact();
                    contact.setFirstName(list[index2 + 1]);
                    contact.setSurName(list[index2 + 2]);
                    contact.setPhoneNumber(list[index2 + 3]);
                    contact.setId(Integer.parseInt(list[index2 + 4]));
                    contact.setType(list[index2 + 5]);
                    contact.setEmail(list[index2 + 6]);

                    index2 = index2 + nextSet2;

                    System.out.println("update for contact is : " + cc2.updateContact(contact));
                    System.out.println("contact updated to : " + contact.toString());
                }

                success = ec.updateEmployee(emp);

                if (success) {
                    System.out.println("Employee update successful");

                    System.out.println("EMP ID: " + emp.getId());

                    /*
                    String result = employeeBean.getEmployeeDetail(Integer.toString(emp.getId()), emp.getEmployeeType());
                    PrintWriter out = response.getWriter();
                    out.print(result);
                     */
                } else {
                    System.out.println("Employee update not successful");
                }

                break;

        } // END SWITCH 

    }

// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
