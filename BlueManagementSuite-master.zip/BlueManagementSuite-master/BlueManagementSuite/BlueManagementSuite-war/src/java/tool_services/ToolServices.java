/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tool_services;

import BusinessClasses.ClientControllers.VendorController;
import BusinessClasses.ToolControllers.ToolController;
import DataEntities.ClientEntities.ClientADT;
import DataEntities.ToolEntities.Tool;
import DataEntities.ToolEntities.ToolADT;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author 729737
 */
@WebServlet(name = "ToolServices", urlPatterns = {"/ToolServices"})
public class ToolServices extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String operation = request.getParameter("operation");

        ToolController tc = new ToolController();
        ArrayList<ToolADT> tools = null;
        String html = "";

        switch (operation) {
            case "search":
                String searchString = request.getParameter("searchString");
                String searchType = request.getParameter("searchType");
                String category = request.getParameter("category");
                String strMinPrice = request.getParameter("minPrice");
                String strMaxPrice = request.getParameter("maxPrice");
                double minPrice = 0;
                double maxPrice = 0;

                //Convert string prices to doubles
                if (strMinPrice != null && strMaxPrice != null) {
                    minPrice = Double.parseDouble(strMinPrice);
                    maxPrice = Double.parseDouble(strMaxPrice);
                }

                //filter the search params and call appropriate advanced search
                if (searchString != null) {
                    if (category != null && category.equals("all")) {
                        category = null;
                    }

                    if (searchType != null && searchType.equals("vendor")) {
                        tools = tc.advancedSearch(-1, null, category, searchString, minPrice, maxPrice);
                    } else {
                        tools = tc.advancedSearch(-1, searchString, category, null, minPrice, maxPrice);
                    }

                } else {
                    tools = tc.advancedSearch(-1, null, category, null, maxPrice, minPrice);
                }
                html = genToolTable(tools);
                out.print(html);
                break;

            case "view":
                String strToolID = request.getParameter("toolID");

                int toolID = -1;
                if (strToolID != null) {
                    toolID = Integer.parseInt(strToolID);
                }

                if (toolID != -1) {
                    ArrayList<ClientADT> clients = tc.getClientsByTool(toolID);
                    ToolADT viewTool = tc.get(toolID);
                    html = genToolDetails(clients, viewTool);
                } else {
                    html = "<h3>Error getting details of this tool!!</h3>";
                }

                out.print(html);
                break;

            case "update":
                String strID = request.getParameter("id");
                String name = request.getParameter("name");
                String cat = request.getParameter("cat");
                String amount = request.getParameter("quantity");
                String desc = request.getParameter("desc");
                String strPrice = request.getParameter("price");
                String strCID = request.getParameter("cid");

                if (strID != null && name != null && cat != null && amount != null && desc != null && strPrice != null && strCID != null) {
                    double price = Double.parseDouble(strPrice);
                    int id = Integer.parseInt(strID);
                    int quantity = Integer.parseInt(amount);
                    int cid = Integer.parseInt(strCID);

                    Tool upTool = new Tool();
                    upTool.setId(id);
                    upTool.setName(name);
                    upTool.setCategory(cat);
                    upTool.setDescription(desc);
                    upTool.setPrice(price);
                    upTool.setQuantity(quantity);

                    String updated = "";
                    if (tc.updateTool(upTool)) {
                        updated += "pass";
                    } else {
                        updated += "fail";
                    }

                    if (tc.updateClientTool(cid, id, price)) {
                        updated += "pass";
                    } else {
                        updated += "fail";
                    }
                    out.print(updated);
                } else {
                    out.print("FAIL");
                }
                break;

            case "add":
                name = request.getParameter("name");
                cat = request.getParameter("cat");
                desc = request.getParameter("desc");
                String cName = request.getParameter("cName");
                strPrice = request.getParameter("price");
                
                if(name != null && cat != null && desc != null && cName != null && strPrice != null){
                    int cid = Integer.parseInt(cName);
                    double price = Double.parseDouble(strPrice);
                    
                    Tool addTool = new Tool();
                    addTool.setName(name);
                    addTool.setCategory(cat);
                    addTool.setDescription(desc);
                    addTool.setPrice(price);
                    addTool.setQuantity(0);
                    
                    String added = "";
                    int newToolID = tc.addTool(addTool);
                    if(tc.addClientTool(cid, newToolID, price)){
                        added = "pass";
                    }
                    out.print(added);
                }
                break;
            case "delete":
                String strTID = request.getParameter("tid");
                strCID = request.getParameter("cid");
                
                if(strTID != null && strCID != null){
                    int tid = Integer.parseInt(strTID);
                    int cid = Integer.parseInt(strCID);
                    
                    String deleted = "";
                    if(tc.deleteClientTool(cid, tid)){
                        deleted += "pass";
                    }
                    else{
                        deleted += "fail";
                    }
                    
                    if(tc.delete(tid)){
                        deleted += "pass";
                    }
                    else{
                        deleted += "fail";
                    }
                    out.print(deleted);
                }
                
                break;
//            case "append":
//                html = genClientToolPrice();
//                out.print(html);
//                break;
        }

    }

    private String genToolTable(ArrayList<ToolADT> tools) {
        String html = "";
        if (tools != null && tools.size() >= 1) {
            html = "<h2>Tools</h2>";
            html += "<table class='panel panel-default'>";
            html += "<tr><b>";
            html += "<th>Name</th>";
            html += "<th>Category</th>";
            html += "<th>Description</th>";
            html += "<th>Quantity</th>";
            html += "<th>View</th>";
            html += "</tr></b>";

            for (ToolADT tool : tools) {
                html += "<tr id=" + tool.getId() + " class='tr-hover'>";
                html += "<td>" + tool.getName() + "</td>";
                html += "<td>" + tool.getCategory() + "</td>";
                html += "<td>" + tool.getDescription() + "</td>";
                html += "<td>" + tool.getQuantity() + "</td>";
                html += "<td><button type='button' id='viewBtn' class='view btn btn-info'><i class=\"fas fa-info\"></i></button>";
                html += "</tr>";
            }

        } else {
            html = "<b><h2>No results found!</h2></b>";
        }
        return html;
    }

    private String genToolDetails(ArrayList<ClientADT> clients, ToolADT tool) {
        ToolController tc = new ToolController();
        String html = "<form action='ToolServices' id='edit-form' method='POST'>";

        html += "<h3><p>" + tool.getName() + "</p>"
                + " <button class='btn btn-primary' type='button' id='edit' value='edit'>edit</button>"
                + " <button class='btn btn-default' type='button' id='save' value='save' disabled>save</button>"
                + " <button class='btn btn-danger btn-danger pull-right' type='button' id='delete' value='delete' disabled>delete</button>"
                + "</h3>";

        //Start data table
        html += "<table id='display-more-details'>";

        //Client Table
        html += "<table class='table'>";

        //Name / ID
        html += "<tr>"
                + "<td class='row-strong'>Tool</td>"
                + "<td><input class='form-control detail-input' type='text' name='tname' id='tname' value='" + tool.getName() + "' disabled></td>"
                + "<input type='text' name='tid' id='tid' value='" + tool.getId() + "' hidden>"
                + "</tr>";

        //Category 
        html += "<tr>"
                + "<td class='row-strong'>Category</td>"
                + "<td><input class='form-control detail-input' type='text' name='tcat' id='tcat' value='" + tool.getCategory() + "' disabled></td>"
                + "</tr>";

        //Description
        html += "<tr>"
                + "<td class='row-strong'>Description</td>"
                + "<td><textarea class='form-control detail-input' name='tdesc' id='tdesc' disabled>" + tool.getDescription() + "</textarea></td>"
                + "</tr>";
        
        //Quantity
        html += "<tr>"
                + "<td class='row-strong'>Quantity</td>"
                + "<td><input class='form-control detail-input' type='number' name='tq' id='tq' value='" + tool.getQuantity() + "' disabled></td>"
                + "</tr>";

        //End Tool Table
        html += "</table>";

        //Start Client table
        html += "<h3>Vendor / Supplier&nbsp;<span id=client-count class='badge badge-info'>" + clients.size() + "</span></h3>";
        html += "<table>"
                + "<tr>"
                + "<th>Vendor / Supplier</th>"
                + "<th>Price ($)</th>"
                + "</tr>";

        for (ClientADT client : clients) {
            double price = tc.getToolPrice(client.getId(), tool.getId());
            html += "<tr>"
                    + "<td>" + client.getName() + "</td>"
                    + "<td><input type='number' id='tprice' name='cprice' value='" + price + "' disabled></td>"
                    + "<input type='text' name='cid' id='cid' value='" + client.getId() + "' hidden>"
                    + "</tr>";
        }
        html += "</table></form>";

        return html;
    }

    private String genClientToolPrice() {
        VendorController vc = new VendorController();
        ArrayList<ClientADT> vClients = vc.searchType("VR");
        ArrayList<ClientADT> sClients = vc.searchType("SP");
        ArrayList<ClientADT> clients = new ArrayList();
        clients.addAll(vClients);
        clients.addAll(sClients);
        String html = "<select name='newClient' class='form-control drop-fix'>";
        
        for (ClientADT client : clients) {
            html += "<option value='" + client.getName() + "'>" + client.getName() + "</option>";
        }
        html += "<div class=\"form-group col-md-4\">\n" +
"                            <label class=\"col-form-label\">Price</label><br>\n" +
"                            <input class='form-control' type=\"number\" name=\"newPrice\" id=\"newPrice\" placeholder=\"$\">\n" +
"                        </div>";
        return html;
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
