$(document).ready(function () {
    $('#arrowScroll').click(function () {
        $.scrollTo($('#bottom-half'), 550);
    });
});


