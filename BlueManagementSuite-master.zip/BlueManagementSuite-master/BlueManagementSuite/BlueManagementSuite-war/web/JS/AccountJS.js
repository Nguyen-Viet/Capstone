/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function loadAccount(userID){
    
    //If there is valid data to search
    if(userID >= 1 && userID !== null){
        
        searchAccountSelected(userID);
        setAccount(userID);
    
    //If there is no data to search
    } else if(userID === -1){
        
        searchAccount();
    
    //Data is invalid
    } else {
        
    }
}


function toggle(){
   
    var client = document.getElementById('clientOp');
    var employee = document.getElementById('employeeOp');

    console.log(client);
    
    client.classList.toggle('hide');
    employee.classList.toggle('hide');
    
    searchAccount();
}

function toggleRadioClient(clicked_id){
    
    var list = ["allc_l", "IN_l", "CO_l", "VR_l", "SP_l"];
    
    for(var i = 0; i < list.length; i++){
        
        var thisButton = document.getElementById(list[i]);
        
        console.log(thisButton);
        
        if(list[i] === clicked_id){
            
            thisButton.classList.remove("btn-default");
            thisButton.classList.add("btn-primary");
                
        } else {
            
            thisButton.classList.remove("btn-primary");
            thisButton.classList.add("btn-default");
        }   
    }    
}

function toggleRadioEmployee(clicked_id){
    
    var list = ["alle_l", "AD_l", "MA_l", "WR_l", "BK_l"];
    
    for(var i = 0; i < list.length; i++){
        
        var thisButton = document.getElementById(list[i]);
        
        console.log(thisButton);
        
        if(list[i] === clicked_id){
            
            thisButton.classList.remove("btn-default");
            thisButton.classList.add("btn-primary");
                
        } else {
            
            thisButton.classList.remove("btn-primary");
            thisButton.classList.add("btn-default");
        }   
    }    
}

function searchAccount() {

    var toggle = document.getElementById('toggleBox').checked;

    var $radio = $('input[name=client]:checked');
    var clientType = $radio.attr('id');

    var $radio = $('input[name=emp]:checked');
    var employeeType = $radio.attr('id');

    var search = $("#search").val();

    var operation = "searchClient";

    if(toggle === false){

        operation = "searchEmployee";
    }

    // AJAX call
    $.ajax({
        type: "POST",
        data: {search: search,
            clientType: clientType,
            employeeType: employeeType,
            operation: operation},
        url: "AccountServices",
        success: function (result){

            $("#searchList").html(result);
            //console.log("the result is: " + result);
        }
    });
}

function searchAccountSelected(selected) {

    var toggle = document.getElementById('toggleBox').checked;

    var $radio = $('input[name=client]:checked');
    var clientType = $radio.attr('id');

    var $radio = $('input[name=emp]:checked');
    var employeeType = $radio.attr('id');

    var search = $("#search").val();

    var operation = "searchClient";

    if(toggle === false){

        operation = "searchEmployee";
    }

    // AJAX call
    $.ajax({
        type: "POST",
        data: {search: search,
            clientType: clientType,
            employeeType: employeeType,
            selected: selected,
            operation: operation},
        url: "AccountServices",
        success: function (result){

            $("#searchList").html(result);
            ///console.log("the result is: " + result);
        }
    });
}

function getAccount(clickedID){

    var clickedItem = document.getElementById(clickedID);
    var itemID = clickedItem.id;

    searchAccountSelected(itemID);
    setAccount(itemID);
}

function setAccount(itemID){

    //get the toggle
    var toggle = document.getElementById('toggleBox').checked;

    //Toggle the operation
    var operation = "displayClient";

    if(toggle === false){

        operation = "displayEmployee";
    }

    // AJAX call
    $.ajax({
        type: "POST",
        data: {itemID: itemID, operation: operation},
        url: "AccountServices",
        success: function (result){

            $("#accDisplay").html(result);
            ///console.log("the result is: " + result);
        }
    });   
}

function save(){
    
    if (confirm("Save these account details?\nThis cannot be undone.")) {

        var itemID = document.getElementById('editID').value;
        var username = document.getElementById('username').value;
        var password = document.getElementById('password').value;
        var locked = document.getElementById('lockedStat').checked;    
        
        console.log(locked);
        
        if(locked === true){
            
            locked = "true";
            
        } else {
            
            locked = "false";
        }

        console.log(locked);

        //get the toggle
        var toggle = document.getElementById('toggleBox').checked;

        //Toggle the operation
        var operation = "saveClient";

        if(toggle === false){

            operation = "saveEmployee";
        }


        // AJAX call
        $.ajax({
            type: "POST",
            data: {itemID: itemID, 
                username: username,
                password: password,
                locked: locked,
                operation: operation},
            url: "AccountServices",
            success: function (result){

                if(result === "true"){
                    
                    searchAccountSelected(itemID);
                    
                } else {
                    
                    alert("Update could not be completed.");
                }
            }
        });
    }
}