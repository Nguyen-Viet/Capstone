$(document).ready(function () {
    setUp();

    $("#search").on("keyup", function () {
        searchTool();
    });

    $("#scroll-area").on("click", "#viewBtn", function () {
        var id = $(this).closest("tr").prop("id");
        viewTool(id);
    });

    $("#categorySelect").on("change", function () {
        searchTool();
    });

    $("#searchType").on("change", function () {
        searchTool();
    });

    $("#right-bar").on("click", "#edit", function () {
        $('#tname, #tcat, #tdesc, #tprice, #save, #delete, #tq').prop("disabled", false);
        $('#edit').prop("disabled", true);
    });

    $("#right-bar").on("click", "#save", function () {
        if (confirm('Do you want to save this tool?')) {
            updateTool($('#edit-form').serializeArray());
            $('#tname, #tcat, #tdesc, #tprice, #save, #delete, #tq').prop("disabled", true);
            $('#edit').prop("disabled", false);
        }
    });
    
    $("#right-bar").on("click", "#delete", function () {
        if (confirm('Do you want to delete this tool?')) {
            deleteTool($('#edit-form').serializeArray());
        }
    });
    
    $("#save").on("click", function() {
        var input = $("#modal-form").serializeArray();
        addTool(input);
    });
//    
//    $("#append").on("click", function() {
//        appendClientTool();
//    });
    
    function setUp() {
        var mySlider = $("#slider").slider({
            min: 0,
            max: 1000,
            value: [5, 125],
            scale: "logarithmic",
            step: 5,
            orientation: "vertical",
            tooltip_position: "left"
        });

        var sliderValues = $('#slider').slider('getValue');
        console.log(sliderValues);
        var min = $('#min-price').val(sliderValues[0]);
        var max = $('#max-price').val(sliderValues[1]);
        
        autosize($(document).find('#modal-desc'));

        //WHEN SLIDER GETS SLID IT UPDATES THE MIN/MAX PRICE VALUE
        $('#slider').on("slide", function (slideEvt) {
            $('#min-price').val(slideEvt.value[0]);
            $('#max-price').val(slideEvt.value[1]);
        });

        //
        var prices = $('#min-price, #max-price').on('change', function () {
            var minMaxPrice = [parseInt(prices[0].value), parseInt(prices[1].value)];
            mySlider.slider('setValue', minMaxPrice);
        });

        searchTool(null, null, "all", min.val(), max.val());
    }

    function searchTool() {
        var searchString = $("#search").val();
        var searchType = $("#searchType").val();
        var category = $("#categorySelect").val();
        var minPrice = $("#min-price").val();
        var maxPrice = $("#max-price").val();

        $.ajax({
            type: "POST",
            data: {searchString: searchString, searchType: searchType, category: category, minPrice: minPrice, maxPrice: maxPrice, operation: "search"},
            url: "ToolServices",
            success: function (result)
            {
                $("#scroll-area").html(result);
            },
            error: function (xhr, textStatus, errorThrown) {
                console.log(xhr + "\n" + textStatus + "\n" + errorThrown);
            }
        });
    }

    function viewTool(toolID) {
        $.ajax({
            type: "POST",
            data: {toolID: toolID, operation: "view"},
            url: "ToolServices",
            success: function (result)
            {
                $("#right-bar").html(result);
                autosize($(document).find('textarea'));
            },
            error: function (xhr, textStatus, errorThrown) {
                console.log(xhr + "\n" + textStatus + "\n" + errorThrown);
                $("#right-bar").html("<p>Error getting details of this tool!!!</p>");
            }
        });
    }
    
    function updateTool(input){
        $.ajax({
            type: "POST",
            data: {id: input[0].value, name: input[1].value, cat: input[2].value, quantity: input[4].value, desc: input[3].value, price: input[6].value, cid: input[5].value, operation: "update"},
            url: "ToolServices",
            success: function (result)
            {
                if(result === "passpass"){
                    searchTool();
                }
                else{
                    console.log(result);
                    alert("Update could not be completed.");
                }
            },
            error: function (xhr, textStatus, errorThrown) {
                console.log(xhr + "\n" + textStatus + "\n" + errorThrown);
                $("#right-bar").html("<p>Error getting details of this tool</p>");
            }
        });
    }
    
    function addTool(input){
        $.ajax({
            type: "POST",
            data: {name: input[0].value, cat: input[1].value, desc: input[2].value, cName: input[3].value, price: input[4].value, operation: "add"},
            url: "ToolServices",
            success: function (result)
            {
                if(result === "pass"){
                    searchTool();
                    alert("Tool added");
                }
                else{
                    console.log(result);
                    alert("Tool could not be added")
                }
            },
            error: function (xhr, textStatus, errorThrown) {
                console.log(xhr + "\n" + textStatus + "\n" + errorThrown);
                $("#right-bar").html("<p>Error adding this tool</p>");
            }
        });
    }
    
    function deleteTool(input){
            $.ajax({
            type: "POST",
            data: {tid: input[0].value, cid: input[5].value, operation: "delete"},
            url: "ToolServices",
            success: function (result)
            {
                if(result === "passpass"){
                    searchTool();
                }
                else{
//                    console.log(result);
//                    alert("Tool could not be deleted.");
                }
            },
            error: function (xhr, textStatus, errorThrown) {
                console.log(xhr + "\n" + textStatus + "\n" + errorThrown);
                $("#right-bar").html("<p>Error deleting this tool</p>");
            }
        });
    
    }
//    function appendClientTool(){
//        $.ajax({
//            type: "POST",
//            data: {operation: "append"},
//            url: "ToolServices",
//            success: function (result)
//            {
//               $("#newClientTool").append(result);
//            },
//            error: function (xhr, textStatus, errorThrown) {
//                console.log(xhr + "\n" + textStatus + "\n" + errorThrown);
//                $("#right-bar").html("<p>Error getting details of this tool</p>");
//            }
//        });
//    }
});
