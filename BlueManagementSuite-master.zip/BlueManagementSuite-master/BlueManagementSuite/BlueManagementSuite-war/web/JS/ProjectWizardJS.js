/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

// Step 1 going to step 2
$("#go-tab2").click(function () {
    $(".bootstrapWizard").find(".active").next().addClass("active");
    $(".bootstrapWizard").find(".active").prev().removeClass("active");
    getAllClient();
    $("#tab1").removeClass("active");
    $("#tab2").addClass("active");

});

// View more detail about this client
$("#client-list").on("click", ".view", function () {
    var clientId = $(this).closest("tr").find(".myid").text();
    var clientName = $(this).closest("tr").find(".my-name").text();

    var htmlString = "<div class='alert alert-success alert-dismissible fade show' role='alert'>" +
            "<strong>Added </strong><span id='selected-client'>" + clientName + "</span>" +
            " <button type='button' class='close' data-dismiss='alert' aria-label='Close'>" +
            " <span aria-hidden='true'>&times;</span>" +
            " </button></div>";

    $("#added-clients").append(htmlString);
});

function getAllClient()
{
    var type = "ALL";
    var operation = "listClients";

    // AJAX call
    $.ajax({
        type: "POST",
        data: {clientType: type,
            operation: operation},
        url: "ClientServices",
        success: function (result)
        {
            $("#client-list").html(result);
            console.log(result);
        },
        error: function (xhr, textstatus, error)
        {
            console.log("hey");
            console.log("xhr: " + xhr);
            console.log("status: " + textstatus);
            console.log("Error: " + error);
        }

    });
}

function done(){
    
    alert("Project Finished");
}