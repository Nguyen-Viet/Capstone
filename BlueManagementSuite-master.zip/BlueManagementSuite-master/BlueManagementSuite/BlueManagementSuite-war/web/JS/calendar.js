$(function() {
  
  $('#calendar').fullCalendar({
      //put your options and callbacks here
      defaultView: 'month',
      height: 500,
      contentHeight: 500,
      showNonCurrentDates: false,
      fixedWeekCount: false,
      events: [
          {
              title: 'Power shortage issue',
              start: '2018-03-28',
              end: '2018-03-30',
              color: 'green',
              textColor: 'white'
          },
          {
              title: 'Loose connections',
              start: '2018-03-09',
              end: '2018-03-12',
              color: 'green',
              textColor: 'white'
          },
          {
              title: 'Circuit breaker fixed',
              start: '2018-04-04',
              end: '2018-04-08',
              color: 'green',
              textColor: 'white'
          },
          {
              title: 'Faulty wiring',
              start: '2018-04-14',
              end: '2018-04-18',
              color: 'red',
              textColor: 'white'
          },
          {
              title: 'Light fixture fitings',
              start: '2018-04-16',
              end: '2018-04-21',
              color: 'yellow',
              textColor: 'black'
          }
      ]
      
  });
  
});