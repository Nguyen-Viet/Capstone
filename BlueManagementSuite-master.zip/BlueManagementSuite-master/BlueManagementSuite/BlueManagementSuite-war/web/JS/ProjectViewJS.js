/* 
 * Author: Graham Ermter
 */
function toggleRadio(clicked_id) {

    var list = ["ALL_l", "QJ_l", "SC_l", "DR_l", "MC_l"];

    for (var i = 0; i < list.length; i++) {

        var thisButton = document.getElementById(list[i]);

        console.log(thisButton);

        if (list[i] === clicked_id) {

            thisButton.classList.remove("btn-default");
            thisButton.classList.add("btn-primary");

        } else {

            thisButton.classList.remove("btn-primary");
            thisButton.classList.add("btn-default");
        }
    }
}

function search() {

    var $radio = $('input[name=pType]:checked');
    var type = $radio.attr('id');

    var e = document.getElementById("projectStatus");
    var status = e.options[e.selectedIndex].value;

    var search = $("#search").val();
    
    var operation = "search";
    
    console.log(type);
    console.log(status);
    console.log(search);

    // AJAX call
    $.ajax({
        type: "POST",
        data: {search: search,
               type: type,
               status: status,
               operation: operation},
        url: "projectViewServices",
        success: function (result) {

            $("#cardArea").html(result);
            //console.log("the result is: " + result);
        }
    });
}