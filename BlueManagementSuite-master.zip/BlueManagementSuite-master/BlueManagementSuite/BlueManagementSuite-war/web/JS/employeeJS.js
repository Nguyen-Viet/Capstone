/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function () {

    // Search for client when user enter characters into the search field
    $("#employeeSearch").on("keypress", function () {
        var searchString = $("#employeeSearch").val();
        var employeeType = $("input[name='employeeType']:checked").val();

        searchEmployee(searchString, employeeType);
    });


    // ADD NEW CONTACT 
    $('#display-more-details').on('click', '#addContact', function () {

    });

    /* Changing the search field placeholder
    $("input[name='employeeType']").change(function () {
        var item = $(this).val();
        console.log(item);
        var text = "";

        if (item === "ALL") {
            text = new String("everyone");
        } else if (item === "AD") {
            text = new String("administrator");
        } else if (item === "BK") {
            text = new String("book keeper");
        } else if (item === "MA") {
            text = new String("manager");
        } else if (item === "WR") {
            text = new String("worker");
        }

        $("#employeeSearch").val("");
        $("#employeeSearch").attr("placeholder", "Search " + text);
    });
*/

    // List all the clients by type
    $("input[name='employeeType']").change(function () {
        var item = $(this).val();
        var operation = "listEmployees";
        var url = "EmployeeServices";

        // AJAX call
        $.ajax({
            type: "POST",
            data: {employeeType: item,
                operation: operation},
            url: url,
            success: function (result)
            {
                $("#testEmployee").html(result);

            }
        });
    });


    // View more details about this client
    $("#testEmployee").on("click", ".view", function () {
        var employeeId = $(this).val();
        var employeeType = $(this).text();

        $(conModalEmpID).val(employeeId);

        console.log($(conModalEmpID).val());

        moreDetail(employeeId, employeeType);
    });

    // Make Input Field Editable 
    $("#display-more-details").on("click", "#edit", function () {
        var employeeName = $("#display-more-details input[type=text]").prop("disabled", false);
        $("#display-more-details input[type=text][name=cId]").prop("disabled", true);
        $("#display-more-details input[type=text][name=hire-date]").prop("disabled", true);
        $("#display-more-details button[id=save]").prop("disabled", false);

        var item = $("#display-more-details input[type=text]").each(function () {
        });

    });


//TRYING TO DO POPOVER
    //$('[data-toggle="popover"]').popover(); 
//    $("#display-more-details").on("click", ".yes", function()
//    {
//        
//    });

//    $("#display-more-details [data-toggle=popover]").popover({
//        html: true,
//        placement: "right",
//        title: "popover",
//        content: function () {
//            return $('#display-more-details .popover-content').html();
//            
//        }
//    });



    // Save Client and Contact Details Call
    $("#display-more-details").on("click", "#save", function () {
        var list = [];
        var contactCount = $("#display-more-details #contact-count").text();

        $("#display-more-details input[type=text]").each(function () {

            list.push($(this).val());
        });

        $("#display-more-details button[id=save]").prop("disabled", true);

        saveInfo(list, contactCount);
        searchLoad("");
        searchLoad("");
        searchLoad("");
        searchLoad("");
                searchLoad("");
        searchLoad("");
        searchLoad("");
        searchLoad("");
                searchLoad("");
        searchLoad("");
        searchLoad("");
        searchLoad("");
                searchLoad("");
        searchLoad("");
        searchLoad("");
        searchLoad("");
    });

    // Delete Client Call
    $("#testEmployee").on("click", ".delete", function () {
        var employeeId = $(this).closest("tr").find(".myid").text();
        var employeeType = $(this).closest("tr").find(".mytype").text();

        deleteEmployee(employeeId, employeeType);
    });


    function deleteEmployee(employeeId, employeeType)
    {
        var operation = "delete";
        var url = "EmployeeServices";

        // AJAX call
        $.ajax({
            type: "POST",
            data: {employeeID: employeeId,
                employeeType: employeeType,
                operation: operation},
            url: url,
            success: function (result)
            {
                $("#testEmployee").html(result);
                alert("Employee has been deleted");
            }
        });
    }

    function searchEmployee(searchString, employeeType) {
        var operation = "listEmployees";
        var url = "EmployeeServices";

        // AJAX call
        $.ajax({
            type: "POST",
            data: {employeeSearch: searchString,
                employeeType: employeeType,
                operation: operation},
            url: url,
            success: function (result)
            {
                $("#testEmployee").html(result);

            }
        });
    }


    function moreDetail(employeeId, employeeType)
    {

        var operation = "moreDetails";
        var url = "EmployeeServices";

        // AJAX call
        $.ajax({
            type: "POST",
            data: {employeeID: employeeId,
                employeeType: employeeType,
                operation: operation},
            url: url,
            success: function (result)
            {
                $("#display-more-details").html(result);
            }
        });

    }


    function saveInfo(dataList, contactCount)
    {
        var operation = "saveEmp";
        var indicator = "employee";
        var url = "SpecialOps";

        // AJAX call
        $.ajax({
            type: "POST",
            data: {list: dataList,
                contactCount: contactCount,
                indicator: indicator,
                operation: operation},
            url: url,
            success: function (result)
            {
                $("#display-more-details input[type=text]").prop("disabled", true);
            }
        });
    }
}); //end document

function searchLoad(searchString) {
    var operation = "listEmployees";
    var url = "EmployeeServices";
    var employeeType = $("input[name='employeeType']:checked").val();

    // AJAX call
    $.ajax({
        type: "POST",
        data: {employeeSearch: searchString,
            employeeType: employeeType,
            operation: operation},
        url: url,
        success: function (result)
        {
            $("#testEmployee").html(result);
        }
    });
}

function deleteEmployeeSimple(employeeId)
{
    var operation = "delete";
    var url = "EmployeeServices";
    var employeeType = $("input[name='employeeType']:checked").val();

    // AJAX call
    $.ajax({
        type: "POST",
        data: {employeeID: employeeId,
            employeeType: employeeType,
            operation: operation},
        url: url,
        success: function (result)
        {
            $("#testEmployee").html(result);
            alert("Employee has been deleted");
        }
    });
}

function toggleRadioEmployee(clicked_id){
    
    var list = ["ALL_l", "AD_l", "MA_l", "WR_l", "BK_l"];
    
    for(var i = 0; i < list.length; i++){
        
        var thisButton = document.getElementById(list[i]);
        
        if(list[i] === clicked_id){
            
            thisButton.classList.remove("btn-default");
            thisButton.classList.add("btn-primary");
                
        } else {
            
            thisButton.classList.remove("btn-primary");
            thisButton.classList.add("btn-default");
        }   
    }    
}
