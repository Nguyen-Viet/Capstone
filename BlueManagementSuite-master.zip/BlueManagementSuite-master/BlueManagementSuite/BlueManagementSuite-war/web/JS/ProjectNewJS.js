/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//Initialize tooltips

$(document).ready(function () {
    console.log("ready!");

    // Step 1 going to step 2
    $("#go-tab2").click(function () {
        $(".bootstrapWizard").find(".active").next().addClass("active");
        $(".bootstrapWizard").find(".active").prev().removeClass("active");
        getAllClient();
        $("#tab1").removeClass("active");
        $("#tab2").addClass("active");
        
    });

    // View more detail about this client
    $("#client-list").on("click", ".view", function () {
        var clientId = $(this).closest("tr").find(".myid").text();
        var clientName = $(this).closest("tr").find(".my-name").text();

        var htmlString = "<div class='alert alert-success alert-dismissible fade show' role='alert'>" +
                "<strong>Added </strong><span id='selected-client'>" + clientName + "</span>" +
                " <button type='button' class='close' data-dismiss='alert' aria-label='Close'>" +
                " <span aria-hidden='true'>&times;</span>" +
                " </button></div>";

        $("#added-clients").append(htmlString);
    });

    function getAllClient()
    {
        var type = "ALL";
        var operation = "listClients";
        
        // AJAX call
        $.ajax({
            type: "POST",
            data: {clientType: type,
                       operation: operation},
            url: "ClientServices",
            success: function (result)
            {
                $("#client-list").html(result);
                console.log(result);
            },
           error: function(xhr, textstatus, error)
           {
               console.log("hey");
               console.log("xhr: "+xhr);
               console.log("status: "+textstatus);
               console.log("Error: "+error);
           }

        });
    }



    // Step 2 going back to step 1
    $("#back-tab1").click(function () {
        $(".bootstrapWizard").find(".active").prev().addClass("active");
        $(".bootstrapWizard").find(".active").next().removeClass("active");

        $("#tab2").removeClass("active");
        $("#tab1").addClass("active");

    });

    // Step 2 going to step 3
    $("#go-tab3").click(function () {
        $(".bootstrapWizard").find(".active").next().addClass("active");
        $(".bootstrapWizard").find(".active").prev().removeClass("active");
        $("#tab2").removeClass("active");
        $("#tab3").addClass("active");
    });

    // Step 3 going back to step 2
    $("#back-tab2").click(function () {
        $(".bootstrapWizard").find(".active").prev().addClass("active");
        $(".bootstrapWizard").find(".active").next().removeClass("active");
        $("#tab3").removeClass("active");
        $("#tab2").addClass("active");
    });

    // Step 3 going to step 4
    $("#go-tab4").click(function () {
        $(".bootstrapWizard").find(".active").next().addClass("active");
        $(".bootstrapWizard").find(".active").prev().removeClass("active");
        $("#tab3").removeClass("active");
        $("#tab4").addClass("active");
    });

    // Step 4 going back to step 3
    $("#back-tab3").click(function () {
        $(".bootstrapWizard").find(".active").prev().addClass("active");
        $(".bootstrapWizard").find(".active").next().removeClass("active");
        $("#tab4").removeClass("active");
        $("#tab3").addClass("active");
    });

    // Step 4 going to step 5
    $("#go-tab5").click(function () {
        $(".bootstrapWizard").find(".active").next().addClass("active");
        $(".bootstrapWizard").find(".active").prev().removeClass("active");
        $("#tab4").removeClass("active");
        $("#tab5").addClass("active");
    });

    // Step 5 going back to step 4
    $("#back-tab4").click(function () {
        $(".bootstrapWizard").find(".active").prev().addClass("active");
        $(".bootstrapWizard").find(".active").next().removeClass("active");
        $("#tab5").removeClass("active");
        $("#tab4").addClass("active");
    });

    // Step 5 going to step 6
    $("#go-tab6").click(function () {
        $(".bootstrapWizard").find(".active").next().addClass("active");
        $(".bootstrapWizard").find(".active").prev().removeClass("active");
        $("#tab5").removeClass("active");
        $("#tab6").addClass("active");
    });

    // Step 6 going back to step5
    $("#back-tab5").click(function () {
        $(".bootstrapWizard").find(".active").prev().addClass("active");
        $(".bootstrapWizard").find(".active").next().removeClass("active");
        $("#tab6").removeClass("active");
        $("#tab5").addClass("active");

    });



});