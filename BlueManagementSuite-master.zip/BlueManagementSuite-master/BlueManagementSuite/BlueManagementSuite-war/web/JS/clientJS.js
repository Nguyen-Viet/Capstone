/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function () {

    // Search for client when user enter characters into the search field
    $("#clientSearch").on("keypress", function () {
        var searchString = $("#clientSearch").val();

        searchClient(searchString);
    });

    // List all the clients
    $("input[name='clientType']").change(function () {
        var item = $(this).val();
        var operation = "listClients";

        // AJAX call
        $.ajax({
            type: "POST",
            data: {clientType: item,
                operation: operation},
            url: "ClientServices",
            success: function (result)
            {
                $("#testClient").html(result);

            }
        });
    });


    // View more detail about this client
    $("#testClient").on("click", ".view", function () {
        var clientId = $(this).closest("tr").find(".myid").text();
        var clientType = $(this).closest("tr").find(".mytype").text();
        
        moreDetail(clientId, clientType);
    });

    // Make Input Field Editable 
    $("#display-more-details").on("click", "#edit", function () {
        var clientName = $("#display-more-details input[type=text]").prop("disabled", false);
        $("#display-more-details input[type=text][name=cId]").prop("disabled", true);
        $("#display-more-details button[id=save]").prop("disabled", false);

        var item = $("#display-more-details input[type=text]").each(function () {

        });

    });


    // Save Client and Contact Details Call
    $("#display-more-details").on("click", "#save", function () {
        var list = [];
        var contactCount = $("#display-more-details #contact-count").text();
        
        $("#display-more-details input[type=text]").each(function () {
            list.push($(this).val());
        });
        
        $("#display-more-details button[id=save]").prop("disabled", true);
        
        saveInfo(list, contactCount);
    });

    // Delete Client Call
    $("#testClient").on("click", ".delete", function () {
        var clientId = $(this).closest("tr").find(".myid").text();
        var clientType = $(this).closest("tr").find(".mytype").text();
        
        
        
        
        
        deleteClient(clientId, clientType);
    });


    function deleteClient(clientId, clientType)
    {
        var operation = "delete";
        var url = "ClientServices";

        // AJAX call
        $.ajax({
            type: "POST",
            data: {clientID: clientId,
                clientType: clientType,
                operation: operation},
            url: url,
            success: function (result)
            {
                $("#testClient").html(result);
                alert("Client has been deleted");
                searchLoad('');
            }
        });
    }

    function searchClient(searchString) {
        var operation = "listClients";
        var url = "ClientServices";
        var clientType = $("input[name='clientType']:checked").val();

        // AJAX call
        $.ajax({
            type: "POST",
            data: {clientSearch: searchString,
                       clientType: clientType,
                       operation: operation},
            url: url,
            success: function (result)
            {
                $("#testClient").html(result);

            }
        });
    }


    function moreDetail(clientId, clientType)
    {


        var operation = "moreDetails";
        var url = "ClientServices";

        // AJAX call
        $.ajax({
            type: "POST",
            data: {clientID: clientId,
                clientType: clientType,
                operation: operation},
            url: url,
            success: function (result)
            {
                $("#display-more-details").html(result);
            }
        });

    }


    function saveInfo(dataList, contactCount)
    {
        var operation = "saveClient";
        var url = "SpecialOps";

        // AJAX call
        $.ajax({
            type: "POST",
            data: {list: dataList,
                      contactCount: contactCount,
                      operation: operation},
            url: url,
            success: function (result)
            {
                $("#display-more-details input[type=text]").prop("disabled", true);
                searchLoad('');
            }
        });
    }
}); 

//end document

function toggleRadioClient(clicked_id){
    
    var list = ["ALL_l", "IN_l", "CO_l", "VR_l", "SP_l"];
    
    for(var i = 0; i < list.length; i++){
        
        var thisButton = document.getElementById(list[i]);
        
        if(list[i] === clicked_id){
            
            thisButton.classList.remove("btn-default");
            thisButton.classList.add("btn-primary");
                
        } else {
            
            thisButton.classList.remove("btn-primary");
            thisButton.classList.add("btn-default");
        }   
    }    
}


function searchLoad(searchString) {
    var operation = "listClients";
    var url = "ClientServices";
    var clientType = $("input[name='clientType']:checked").val();

    // AJAX call
    $.ajax({
        type: "POST",
        data: {clientSearch: searchString,
                   clientType: clientType,
                   operation: operation},
        url: url,
        success: function (result)
        {
            $("#testClient").html(result);

        }
    });
}

    function deleteClientSimple(clientId)
    {
        var operation = "delete";
        var url = "ClientServices";
        var clientType = $("input[name='clientType']:checked").val();

        // AJAX call
        $.ajax({
            type: "POST",
            data: {clientID: clientId,
                clientType: clientType,
                operation: operation},
            url: url,
            success: function (result)
            {
                $("#testClient").html(result);
                alert("Client has been deleted");
            }
        });
        
        searchLoad('');
        searchLoad('');
        searchLoad('');
        searchLoad('');
        searchLoad('');
    }